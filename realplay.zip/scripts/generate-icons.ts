import fs from 'node:fs';
import zlib from 'node:zlib';

function createSolidPNG(width: number, height: number, r: number, g: number, b: number, a = 255): Buffer {
  const bytesPerPixel = 4;
  const stride = 1 + width * bytesPerPixel;
  const rawData = Buffer.alloc(stride * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * stride;
    rawData[rowOffset] = 0; // Filter type 0 (None)
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * bytesPerPixel;
      // create a circular badge effect
      const dx = x - width / 2;
      const dy = y - height / 2;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const radius = width * 0.45;
      const ringInner = width * 0.35;
      const ringOuter = width * 0.42;

      let pr = 16, pg = 18, pb = 20, pa = 255; // #101214
      if (dist >= ringInner && dist <= ringOuter) {
        pr = 198; pg = 243; pb = 106; // #C6F36A (electric lime)
      } else if (dist < ringInner && x >= width * 0.42 && x <= width * 0.65 && Math.abs(dy) <= (x - width * 0.38) * 0.7) {
        pr = 198; pg = 243; pb = 106; // center arrow
      }

      rawData[pxOffset] = pr;
      rawData[pxOffset + 1] = pg;
      rawData[pxOffset + 2] = pb;
      rawData[pxOffset + 3] = pa;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // Bit depth: 8
  ihdrData[9] = 6; // Color type: RGBA
  ihdrData[10] = 0; // Compression
  ihdrData[11] = 0; // Filter
  ihdrData[12] = 0; // Interlace

  const ihdrChunk = createChunk('IHDR', ihdrData);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function crc32(buf: Buffer): number {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) {
    crc = crc ^ buf[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ (-(crc & 1) & 0xedb88320);
    }
  }
  return (crc ^ -1) >>> 0;
}

function createChunk(type: string, data: Buffer): Buffer {
  const typeBuf = Buffer.from(type, 'ascii');
  const length = data.length;
  const chunk = Buffer.alloc(8 + length + 4);
  chunk.writeUInt32BE(length, 0);
  typeBuf.copy(chunk, 4);
  data.copy(chunk, 8);
  const crcVal = crc32(Buffer.concat([typeBuf, data]));
  chunk.writeUInt32BE(crcVal, 8 + length);
  return chunk;
}

import path from 'node:path';

const publicDir = path.join(process.cwd(), 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Generate files
const sizes = [
  { file: path.join(publicDir, 'pwa-192x192.png'), size: 192 },
  { file: path.join(publicDir, 'pwa-512x512.png'), size: 512 },
  { file: path.join(publicDir, 'pwa-maskable-512x512.png'), size: 512 },
  { file: path.join(publicDir, 'apple-touch-icon.png'), size: 180 },
  { file: path.join(publicDir, 'favicon.ico'), size: 64 },
];

for (const { file, size } of sizes) {
  const buf = createSolidPNG(size, size, 198, 243, 106);
  fs.writeFileSync(file, buf);
  console.log(`Generated ${file} (${size}x${size})`);
}
