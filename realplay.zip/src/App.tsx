import React, { useState, useEffect, useCallback } from 'react';
import { db, DEFAULT_USER_SETTINGS } from './services/db';
import {
  Wheel,
  WorkoutSession,
  Challenge,
  CompletionRecord,
  UserGoal,
  Achievement,
  UserSettings,
} from './types/index';
import { Header } from './components/common/Header';
import { Navigation, TabKey } from './components/common/Navigation';
import { OfflineIndicator } from './components/common/OfflineIndicator';
import { ActiveSessionBar } from './components/workout/ActiveSessionBar';
import { WarmupModal } from './components/workout/WarmupModal';
import { WorkoutTimerModal } from './components/timer/WorkoutTimerModal';
import { QueueManager } from './components/workout/QueueManager';
import { WheelEditorModal } from './features/wheels/WheelEditorModal';
import { PlayView } from './features/play/PlayView';
import { WheelsView } from './features/wheels/WheelsView';
import { HistoryView } from './features/history/HistoryView';
import { StatsView } from './features/stats/StatsView';
import { SettingsView } from './features/settings/SettingsView';
import { soundService } from './services/audio';
import { decodeWheelFromShareUrl } from './services/backup';
import { Zap } from 'lucide-react';

export default function App() {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<TabKey>('play');

  // Application Data States
  const [wheels, setWheels] = useState<Wheel[]>([]);
  const [activeWheelId, setActiveWheelId] = useState<string | null>(null);
  const [activeSession, setActiveSession] = useState<WorkoutSession | null>(null);
  const [queue, setQueue] = useState<Challenge[]>([]);
  const [sessionCompletions, setSessionCompletions] = useState<CompletionRecord[]>([]);
  const [allCompletions, setAllCompletions] = useState<CompletionRecord[]>([]);
  const [goals, setGoals] = useState<UserGoal[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_USER_SETTINGS);

  // Global Modals
  const [showWarmupModal, setShowWarmupModal] = useState<boolean>(false);
  const [showTimerModal, setShowTimerModal] = useState<boolean>(false);
  const [showQueueModal, setShowQueueModal] = useState<boolean>(false);
  const [editingWheel, setEditingWheel] = useState<Wheel | null>(null);
  const [isWheelEditorOpen, setIsWheelEditorOpen] = useState<boolean>(false);

  // Refresh all state from Dexie IndexedDB
  const refreshData = useCallback(async () => {
    try {
      const [allWh, sess, comps, g, ach, sett] = await Promise.all([
        db.getAllWheels(),
        db.getActiveSession(),
        db.completions.toArray(),
        db.goals.toArray(),
        db.achievements.toArray(),
        db.getUserSettings(),
      ]);

      setWheels(allWh);
      if (!activeWheelId && allWh.length > 0) {
        setActiveWheelId(allWh[0].id);
      }

      setActiveSession(sess);

      if (sess) {
        const q = await db.getActiveQueue(sess.id);
        setQueue(q);
        const sessComps = comps.filter((c) => c.sessionId === sess.id);
        setSessionCompletions(sessComps);
      } else {
        setQueue([]);
        setSessionCompletions([]);
      }

      setAllCompletions(comps.sort((a, b) => b.completedAt - a.completedAt));
      setGoals(g);
      setAchievements(ach);
      setSettings(sett);
      soundService.setPreferences(sett.soundEnabled, sett.vibrationEnabled);
    } catch (err) {
      console.error('Error loading data from IndexedDB:', err);
    }
  }, [activeWheelId]);

  // Initial load
  useEffect(() => {
    let mounted = true;

    async function init() {
      try {
        await db.initializeDefaults();
        if (mounted) {
          await refreshData();

          // Check URL for shared wheel import: ?import_wheel=...
          if (typeof window !== 'undefined') {
            const urlParams = new URLSearchParams(window.location.search);
            const importData = urlParams.get('import_wheel');
            if (importData) {
              const decoded = decodeWheelFromShareUrl(importData);
              if (decoded) {
                const newWheel: Wheel = {
                  ...decoded,
                  id: `shared-${Date.now()}`,
                  source: 'custom',
                };
                await db.saveWheel(newWheel);
                await refreshData();
                setActiveWheelId(newWheel.id);
                // clean URL without reloading
                window.history.replaceState({}, document.title, window.location.pathname);
              }
            }
          }
        }
      } catch (err) {
        console.error('Initialization error:', err);
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    }

    init();
    return () => {
      mounted = false;
    };
  }, [refreshData]);

  // Finish active session
  const handleFinishSession = async () => {
    if (!activeSession) return;
    await db.finishSession(activeSession.id);
    await refreshData();
  };

  // Toggle audio
  const handleToggleSound = async () => {
    const updated = await db.updateUserSettings({ soundEnabled: !settings.soundEnabled });
    setSettings(updated);
    soundService.setPreferences(updated.soundEnabled, updated.vibrationEnabled);
  };

  // Queue actions
  const handleStartChallengeFromQueue = (challenge: Challenge) => {
    setShowQueueModal(false);
    setActiveTab('play');
  };

  const handleCompleteChallengeFromQueue = async (challenge: Challenge, actualVal: number) => {
    if (!activeSession) return;
    await db.recordChallengeCompletion({
      challengeId: challenge.id,
      sessionId: activeSession.id,
      activityNameSnapshot: challenge.labelSnapshot,
      category: challenge.category,
      targetValue: challenge.targetValue,
      actualValue: actualVal,
      unit: challenge.unit,
      isWorkout: challenge.isWorkout,
      source: 'queue',
    });
    await refreshData();
  };

  const handleRemoveChallengeFromQueue = async (challengeId: string) => {
    await db.removeChallengeFromQueue(challengeId);
    await refreshData();
  };

  const handleReorderQueue = (newQueue: Challenge[]) => {
    setQueue(newQueue);
  };

  const handleClearQueue = async () => {
    if (!activeSession) return;
    for (const c of queue) {
      await db.removeChallengeFromQueue(c.id);
    }
    await refreshData();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#101214] flex flex-col items-center justify-center p-4">
        <div className="w-14 h-14 rounded-2xl bg-[#C6F36A] flex items-center justify-center text-[#101214] shadow-xl shadow-[#C6F36A]/20 animate-bounce">
          <Zap className="w-8 h-8 fill-current" />
        </div>
        <h1 className="mt-4 text-xl font-black tracking-widest text-[#F4F6F8]">REALPLAY</h1>
        <p className="text-xs text-[#9AA5B1] mt-1">Menyiapkan permainan olahraga & tantangan fisik...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#101214] text-[#F4F6F8] flex flex-col font-sans">
      {/* Top Header */}
      <Header
        userXp={settings.userXp || 0}
        soundEnabled={settings.soundEnabled}
        onToggleSound={handleToggleSound}
        onOpenTimer={() => setShowTimerModal(true)}
      />

      {/* Desktop Tabs */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        queueCount={queue.length}
      />

      {/* Active Workout Session Banner */}
      <ActiveSessionBar
        session={activeSession}
        queue={queue}
        sessionCompletionsCount={sessionCompletions.length}
        onFinishSession={handleFinishSession}
        onOpenWarmup={() => setShowWarmupModal(true)}
        onOpenQueue={() => setShowQueueModal(true)}
      />

      {/* Main View Router */}
      <main className="flex-1 flex flex-col pb-20 md:pb-8">
        {activeTab === 'play' && (
          <PlayView
            wheels={wheels}
            activeWheelId={activeWheelId}
            onSelectWheel={(id) => setActiveWheelId(id)}
            onEditWheel={(wheel) => {
              setEditingWheel(wheel);
              setIsWheelEditorOpen(true);
            }}
            onCreateWheel={() => {
              setEditingWheel(null);
              setIsWheelEditorOpen(true);
            }}
            onViewQueue={() => setShowQueueModal(true)}
            activeSession={activeSession}
            sessionCompletions={sessionCompletions}
            queue={queue}
            onRefreshData={refreshData}
            reducedMotion={settings.reducedMotion}
          />
        )}

        {activeTab === 'wheels' && (
          <WheelsView
            wheels={wheels}
            activeWheelId={activeWheelId}
            onSelectAndPlay={(id) => {
              setActiveWheelId(id);
              setActiveTab('play');
            }}
            onRefreshData={refreshData}
          />
        )}

        {activeTab === 'queue' && (
          <div className="flex-1 max-w-2xl mx-auto w-full px-4 py-6">
            <h2 className="text-2xl font-black text-[#F4F6F8] mb-4">Antrean Latihan Aktif</h2>
            <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4">
              <QueueManager
                queue={queue}
                onStartChallenge={handleStartChallengeFromQueue}
                onCompleteChallenge={handleCompleteChallengeFromQueue}
                onRemoveChallenge={handleRemoveChallengeFromQueue}
                onReorderQueue={handleReorderQueue}
                onClearQueue={handleClearQueue}
                onClose={() => setActiveTab('play')}
              />
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <HistoryView completions={allCompletions} onRefreshData={refreshData} />
        )}

        {activeTab === 'stats' && (
          <StatsView
            completions={allCompletions}
            goals={goals}
            achievements={achievements}
            settings={settings}
            onRefreshData={refreshData}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView settings={settings} onRefreshData={refreshData} />
        )}
      </main>

      {/* Queue Modal (if opened via top bar while in another tab) */}
      {showQueueModal && activeTab !== 'queue' && (
        <QueueManager
          queue={queue}
          onStartChallenge={handleStartChallengeFromQueue}
          onCompleteChallenge={handleCompleteChallengeFromQueue}
          onRemoveChallenge={handleRemoveChallengeFromQueue}
          onReorderQueue={handleReorderQueue}
          onClearQueue={handleClearQueue}
          onClose={() => setShowQueueModal(false)}
        />
      )}

      {/* Global Warmup Modal */}
      {showWarmupModal && (
        <WarmupModal
          onStartWorkout={async () => {
            if (!activeSession) {
              await db.startNewSession();
              await refreshData();
            }
            setShowWarmupModal(false);
          }}
          onClose={() => setShowWarmupModal(false)}
        />
      )}

      {/* Global Workout Timer Modal */}
      {showTimerModal && (
        <WorkoutTimerModal
          initialDurationSec={60}
          activityLabel="Timer & Stopwatch REALPLAY"
          onClose={() => setShowTimerModal(false)}
        />
      )}

      {/* Global Wheel Editor Modal */}
      {isWheelEditorOpen && (
        <WheelEditorModal
          wheel={editingWheel}
          onSave={async (saved) => {
            await db.saveWheel(saved);
            setIsWheelEditorOpen(false);
            setActiveWheelId(saved.id);
            await refreshData();
          }}
          onClose={() => setIsWheelEditorOpen(false)}
        />
      )}

      {/* Non-intrusive Offline Connectivity Indicator */}
      <OfflineIndicator />
    </div>
  );
}
