import React from 'react';
import { Volume2, VolumeX, Timer, Zap } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { calculateLevelFromXP } from '../../domain/gamification';

interface HeaderProps {
  userXp: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenTimer: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  userXp,
  soundEnabled,
  onToggleSound,
  onOpenTimer,
}) => {
  const { level, currentLevelXP, nextLevelXP, progressPercent } = calculateLevelFromXP(userXp);

  return (
    <header className="sticky top-0 z-30 w-full bg-[#101214]/90 backdrop-blur-md border-b border-[#232B32]">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#C6F36A] flex items-center justify-center text-[#101214] font-black shadow-md shadow-[#C6F36A]/20">
            <Zap className="w-5 h-5 fill-current" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-lg tracking-wider text-[#F4F6F8]">REALPLAY</span>
              <span className="hidden sm:inline-block text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#C6F36A]/10 text-[#C6F36A] border border-[#C6F36A]/30 uppercase tracking-wide">
                FITNESS GAME
              </span>
            </div>
            <p className="hidden md:block text-[10px] font-medium text-[#9AA5B1] -mt-1 tracking-tight">
              Spin. Move. Track.
            </p>
          </div>
        </div>

        {/* Right Action Tools: XP, Timer, Sound, Install */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* User Level & XP Pill */}
          <div
            className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-[#191D21] border border-[#2D3844] shadow-sm"
            title={`Level ${level} • ${currentLevelXP} / ${nextLevelXP} XP menuju level berikutnya (${progressPercent}%)`}
          >
            <div className="w-5 h-5 rounded-md bg-[#C6F36A]/20 text-[#C6F36A] font-black text-[11px] flex items-center justify-center">
              {level}
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1">
                <span className="text-[11px] font-bold text-[#F4F6F8]">Lv.{level}</span>
                <span className="text-[10px] text-[#C6F36A] font-semibold">{userXp} XP</span>
              </div>
              <div className="w-16 h-1 bg-[#121518] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#C6F36A] rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Quick Timer Launcher */}
          <button
            onClick={onOpenTimer}
            className="p-2 rounded-xl bg-[#191D21] hover:bg-[#22282E] text-[#9AA5B1] hover:text-[#2DD4BF] border border-[#2D3844] transition"
            title="Buka Timer & Stopwatch"
            aria-label="Buka Timer & Stopwatch"
          >
            <Timer className="w-4 h-4" />
          </button>

          {/* Audio Toggle */}
          <button
            onClick={onToggleSound}
            className={`p-2 rounded-xl border transition ${
              soundEnabled
                ? 'bg-[#191D21] hover:bg-[#22282E] text-[#C6F36A] border-[#2D3844]'
                : 'bg-[#191D21] text-[#9AA5B1] border-[#2D3844]'
            }`}
            title={soundEnabled ? 'Matikan Suara' : 'Nyalakan Suara'}
            aria-label={soundEnabled ? 'Matikan Suara' : 'Nyalakan Suara'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* In-App PWA Install */}
          <PWAInstallButton />
        </div>
      </div>
    </header>
  );
};
