import React from 'react';
import { Disc, Layers, ListOrdered, Calendar, Trophy, Settings } from 'lucide-react';

export type TabKey = 'play' | 'wheels' | 'queue' | 'history' | 'stats' | 'settings';

interface NavigationProps {
  activeTab: TabKey;
  onSelectTab: (tab: TabKey) => void;
  queueCount?: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  queueCount = 0,
}) => {
  const tabs = [
    { key: 'play' as TabKey, label: 'Play', icon: Disc },
    { key: 'wheels' as TabKey, label: 'Roda Saya', icon: Layers },
    { key: 'queue' as TabKey, label: 'Antrean', icon: ListOrdered, badge: queueCount },
    { key: 'history' as TabKey, label: 'Riwayat', icon: Calendar },
    { key: 'stats' as TabKey, label: 'Statistik', icon: Trophy },
    { key: 'settings' as TabKey, label: 'Pengaturan', icon: Settings },
  ];

  return (
    <>
      {/* Desktop Header Secondary Nav */}
      <nav aria-label="Navigasi Utama Desktop" className="hidden md:block w-full bg-[#14181C] border-b border-[#232B32]">
        <div className="max-w-6xl mx-auto px-4 flex items-center gap-1">
          {tabs.map((t) => {
            const Icon = t.icon;
            const isActive = activeTab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => onSelectTab(t.key)}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-bold transition border-b-2 relative ${
                  isActive
                    ? 'border-[#C6F36A] text-[#C6F36A] bg-[#191D21]'
                    : 'border-transparent text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#191D21]/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{t.label}</span>
                {typeof t.badge === 'number' && t.badge > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-[#0EA5E9] text-white">
                    {t.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile Bottom Fixed Bar */}
      <nav
        aria-label="Navigasi Utama Mobile"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#14181C]/95 backdrop-blur-lg border-t border-[#232B32] pb-safe"
      >
        <div className="grid grid-cols-6 h-14">
          {tabs.map((t) => {
            const Icon = t.icon;
            const isActive = activeTab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => onSelectTab(t.key)}
                className={`flex flex-col items-center justify-center relative py-1 text-[10px] font-medium transition ${
                  isActive ? 'text-[#C6F36A]' : 'text-[#9AA5B1] hover:text-[#F4F6F8]'
                }`}
              >
                <div className="relative">
                  <Icon className="w-4 h-4" />
                  {typeof t.badge === 'number' && t.badge > 0 && (
                    <span className="absolute -top-1.5 -right-2 px-1 py-0.2 rounded-full text-[9px] font-mono bg-[#0EA5E9] text-white">
                      {t.badge}
                    </span>
                  )}
                </div>
                <span className="mt-1 truncate max-w-[54px]">{t.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 w-8 h-0.5 rounded-full bg-[#C6F36A]" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
