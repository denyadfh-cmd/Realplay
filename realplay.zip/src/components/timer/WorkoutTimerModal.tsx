import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Check, X, Bell, Clock, Timer as TimerIcon } from 'lucide-react';
import { DriftProofTimer, DriftProofStopwatch, TimerState } from '../../services/timer';
import { soundService } from '../../services/audio';

interface WorkoutTimerModalProps {
  initialDurationSec?: number;
  activityLabel?: string;
  onApplyTime?: (elapsedOrTargetSeconds: number) => void;
  onClose: () => void;
}

export const WorkoutTimerModal: React.FC<WorkoutTimerModalProps> = ({
  initialDurationSec = 30,
  activityLabel = 'Latihan Berdurasi',
  onApplyTime,
  onClose,
}) => {
  const [mode, setMode] = useState<'timer' | 'stopwatch'>('timer');

  // Timer state
  const [timerInstance] = useState(() => new DriftProofTimer());
  const [timerRemaining, setTimerRemaining] = useState<number>(initialDurationSec);
  const [timerProgress, setTimerProgress] = useState<number>(0);
  const [timerState, setTimerState] = useState<TimerState>('idle');

  // Stopwatch state
  const [stopwatchInstance] = useState(() => new DriftProofStopwatch());
  const [stopwatchElapsed, setStopwatchElapsed] = useState<number>(0);
  const [stopwatchState, setStopwatchState] = useState<TimerState>('idle');

  // Initialize timer with initial duration
  useEffect(() => {
    timerInstance.setDuration(initialDurationSec);
    const unsubTimer = timerInstance.subscribe((rem, ratio, st) => {
      setTimerRemaining(rem);
      setTimerProgress(ratio);
      setTimerState(st);
    });

    const unsubStopwatch = stopwatchInstance.subscribe((sec, st) => {
      setStopwatchElapsed(sec);
      setStopwatchState(st);
    });

    return () => {
      unsubTimer();
      unsubStopwatch();
      timerInstance.reset();
      stopwatchInstance.reset();
    };
  }, [initialDurationSec, timerInstance, stopwatchInstance]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleApply = () => {
    const timeToApply = mode === 'timer' ? initialDurationSec - timerRemaining : stopwatchElapsed;
    if (onApplyTime) {
      onApplyTime(Math.max(1, timeToApply));
    }
    onClose();
  };

  const presets = [15, 30, 45, 60, 90, 120, 180];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="timer-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
    >
      <div className="w-full max-w-sm bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 shadow-2xl relative text-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
          aria-label="Tutup Timer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Mode Toggle */}
        <div className="inline-flex p-1 bg-[#121518] rounded-xl border border-[#242C35] mb-5">
          <button
            onClick={() => setMode('timer')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              mode === 'timer'
                ? 'bg-[#C6F36A] text-[#101214] shadow-sm'
                : 'text-[#9AA5B1] hover:text-[#F4F6F8]'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Hitung Mundur
          </button>
          <button
            onClick={() => setMode('stopwatch')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              mode === 'stopwatch'
                ? 'bg-[#C6F36A] text-[#101214] shadow-sm'
                : 'text-[#9AA5B1] hover:text-[#F4F6F8]'
            }`}
          >
            <TimerIcon className="w-3.5 h-3.5" />
            Stopwatch
          </button>
        </div>

        <h3 id="timer-modal-title" className="text-sm font-semibold text-[#9AA5B1] mb-1">
          {activityLabel}
        </h3>

        {/* Display Digits */}
        {mode === 'timer' ? (
          <div>
            <div className="my-6">
              <span className="font-mono text-5xl sm:text-6xl font-black text-[#F4F6F8] tracking-wider">
                {formatTime(timerRemaining)}
              </span>
            </div>

            {/* Circular or Bar Progress */}
            <div className="w-full bg-[#121518] h-2.5 rounded-full overflow-hidden border border-[#232B33] mb-6">
              <div
                className="h-full bg-gradient-to-r from-[#C6F36A] to-[#2DD4BF] transition-all duration-150"
                style={{ width: `${timerProgress * 100}%` }}
              />
            </div>

            {/* Quick Presets */}
            {timerState === 'idle' && (
              <div className="flex flex-wrap items-center justify-center gap-1.5 mb-6">
                {presets.map((sec) => (
                  <button
                    key={sec}
                    onClick={() => timerInstance.setDuration(sec)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition ${
                      timerRemaining === sec
                        ? 'border-[#C6F36A] bg-[#C6F36A]/10 text-[#C6F36A]'
                        : 'border-[#2D3844] bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8]'
                    }`}
                  >
                    {sec < 60 ? `${sec}s` : `${sec / 60}m`}
                  </button>
                ))}
              </div>
            )}

            {/* Controls */}
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => timerInstance.reset()}
                className="p-3 bg-[#22282E] hover:bg-[#2C353D] text-[#9AA5B1] hover:text-[#F4F6F8] rounded-xl transition"
                title="Reset Timer"
              >
                <RotateCcw className="w-5 h-5" />
              </button>

              {timerState === 'running' ? (
                <button
                  onClick={() => timerInstance.pause()}
                  className="px-6 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#101214] font-extrabold rounded-xl flex items-center gap-2 transition"
                >
                  <Pause className="w-5 h-5" />
                  Jeda
                </button>
              ) : (
                <button
                  onClick={() => timerInstance.start()}
                  className="px-6 py-3 bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] font-extrabold rounded-xl flex items-center gap-2 shadow-lg shadow-[#C6F36A]/20 transition"
                >
                  <Play className="w-5 h-5 fill-current" />
                  {timerState === 'paused' ? 'Lanjutkan' : 'Mulai'}
                </button>
              )}
            </div>
          </div>
        ) : (
          <div>
            <div className="my-6">
              <span className="font-mono text-5xl sm:text-6xl font-black text-[#F4F6F8] tracking-wider">
                {formatTime(stopwatchElapsed)}
              </span>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-3 mt-8">
              <button
                onClick={() => stopwatchInstance.reset()}
                className="p-3 bg-[#22282E] hover:bg-[#2C353D] text-[#9AA5B1] hover:text-[#F4F6F8] rounded-xl transition"
                title="Reset Stopwatch"
              >
                <RotateCcw className="w-5 h-5" />
              </button>

              {stopwatchState === 'running' ? (
                <button
                  onClick={() => stopwatchInstance.pause()}
                  className="px-6 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#101214] font-extrabold rounded-xl flex items-center gap-2 transition"
                >
                  <Pause className="w-5 h-5" />
                  Jeda
                </button>
              ) : (
                <button
                  onClick={() => stopwatchInstance.start()}
                  className="px-6 py-3 bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] font-extrabold rounded-xl flex items-center gap-2 shadow-lg shadow-[#C6F36A]/20 transition"
                >
                  <Play className="w-5 h-5 fill-current" />
                  {stopwatchState === 'paused' ? 'Lanjutkan' : 'Mulai'}
                </button>
              )}
            </div>
          </div>
        )}

        {/* Apply Button */}
        {onApplyTime && (
          <div className="mt-6 pt-4 border-t border-[#232B33]">
            <button
              onClick={handleApply}
              className="w-full py-2.5 px-4 bg-[#22282E] hover:bg-[#2C353D] text-[#C6F36A] font-bold text-sm rounded-xl flex items-center justify-center gap-2 transition border border-[#2D3844]"
            >
              <Check className="w-4 h-4" />
              Gunakan Waktu Ini untuk Tantangan
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
