import React, { useState } from 'react';
import { WheelItem } from '../../types/index';
import confetti from 'canvas-confetti';
import {
  Flame,
  Clock,
  CheckCircle2,
  PlusCircle,
  RotateCcw,
  SkipForward,
  Edit3,
  HeartPulse,
  Info,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { soundService } from '../../services/audio';

interface ChallengeResultCardProps {
  item: WheelItem;
  onStart: (actualVal: number) => void;
  onComplete: (actualVal: number, durationSec?: number) => void;
  onAddToQueue: (actualVal: number) => void;
  onSkip: () => void;
  onClose: () => void;
}

export const ChallengeResultCard: React.FC<ChallengeResultCardProps> = ({
  item,
  onStart,
  onComplete,
  onAddToQueue,
  onSkip,
  onClose,
}) => {
  const isRest = item.type === 'rest' || !item.isWorkout;
  const hasNumericValue = typeof item.value === 'number' && !isNaN(item.value);
  const initialValue = hasNumericValue ? (item.value as number) : 1;

  const [actualValue, setActualValue] = useState<number>(initialValue);
  const [isEditingValue, setIsEditingValue] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const validateInput = (): boolean => {
    if (hasNumericValue) {
      if (isNaN(actualValue) || !Number.isFinite(actualValue) || actualValue < 0) {
        setValidationError('Nilai aktual harus berupa angka positif.');
        return false;
      }
      if (item.type === 'repetition' && !Number.isInteger(actualValue)) {
        setValidationError('Jumlah repetisi harus berupa bilangan bulat.');
        return false;
      }
      if (actualValue > 10000) {
        setValidationError('Nilai aktual melebihi batas wajar.');
        return false;
      }
    }
    setValidationError(null);
    return true;
  };

  const handleCompleteClick = () => {
    if (isSubmitting) return;
    if (!validateInput()) return;

    setIsSubmitting(true);

    // Only play celebratory fanfare and confetti for actual physical workouts
    if (!isRest) {
      soundService.playCompletionFanfare();
      confetti({
        particleCount: 45,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#C6F36A', '#2DD4BF', '#F59E0B', '#FFFFFF'],
      });
    } else {
      // Gentle calm tone for recovery
      soundService.playTick();
    }

    onComplete(actualValue);
  };

  const getCategoryLabel = (cat?: string) => {
    switch (cat) {
      case 'upper_body': return 'Tubuh Atas';
      case 'lower_body': return 'Tubuh Bawah';
      case 'core': return 'Otot Inti (Core)';
      case 'cardio': return 'Kardio';
      case 'mobility_rest': return 'Pemulihan & Istirahat';
      default: return 'Aktivitas Umum';
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="challenge-result-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="w-full max-w-md bg-[#191D21] border border-[#2D3844] rounded-2xl shadow-2xl p-5 sm:p-6 overflow-hidden relative">
        {/* Top accent line */}
        <div
          className="absolute top-0 left-0 right-0 h-1.5"
          style={{ backgroundColor: isRest ? '#2DD4BF' : item.color || '#C6F36A' }}
        />

        {/* Header Badges */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full border ${
            isRest
              ? 'bg-[#2DD4BF]/10 text-[#2DD4BF] border-[#2DD4BF]/30'
              : 'bg-[#22282E] text-[#9AA5B1] border-[#2C353D]'
          }`}>
            {isRest ? <HeartPulse className="w-3.5 h-3.5 text-[#2DD4BF]" /> : <Flame className="w-3.5 h-3.5 text-[#C6F36A]" />}
            {isRest ? 'WAKTU PEMULIHAN' : getCategoryLabel(item.category)}
          </span>
          <span className="text-xs text-[#9AA5B1] font-mono">
            {isRest ? 'RECOVERY' : item.trackingMode.toUpperCase()}
          </span>
        </div>

        {/* Challenge Title */}
        <div className="text-center my-3">
          <p className="text-xs font-medium text-[#9AA5B1] uppercase tracking-wider mb-1">
            {isRest ? 'Istirahat & Pemulihan' : 'Hasil Putaran Roda'}
          </p>
          <h2 id="challenge-result-title" className="text-2xl sm:text-3xl font-extrabold text-[#F4F6F8] tracking-tight leading-snug">
            {item.label}
          </h2>
          {item.description ? (
            <p className="text-sm text-[#9AA5B1] mt-1">{item.description}</p>
          ) : isRest ? (
            <p className="text-xs text-[#9AA5B1] mt-1">
              Bernapas tenang, minum air, atau lakukan peregangan santai sejenak.
            </p>
          ) : null}
        </div>

        {/* Target and Value Editor */}
        {hasNumericValue && (
          <div className="bg-[#121518] rounded-xl p-4 my-3 border border-[#242C35]">
            <div className="flex items-center justify-between">
              <span className="text-xs sm:text-sm text-[#9AA5B1]">
                {isRest ? 'Target Istirahat' : 'Target Latihan'}
              </span>
              <div className="flex items-center gap-2">
                <span className={`text-base sm:text-lg font-bold ${isRest ? 'text-[#2DD4BF]' : 'text-[#C6F36A]'}`}>
                  {actualValue} {item.unit || (item.type === 'repetition' ? 'reps' : '')}
                </span>
                <button
                  type="button"
                  onClick={() => setIsEditingValue(!isEditingValue)}
                  className="p-1 rounded text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
                  title="Sesuaikan nilai aktual yang kamu lakukan"
                  aria-label="Edit nilai aktual"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {isEditingValue && (
              <div className="mt-3 pt-3 border-t border-[#22282E] flex items-center justify-between gap-3 animate-in fade-in duration-150">
                <span className="text-xs text-[#9AA5B1]">Koreksi Aktual:</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActualValue(Math.max(1, actualValue - 1))}
                    className="w-8 h-8 rounded-lg bg-[#22282E] text-[#F4F6F8] font-bold hover:bg-[#2C353D] active:scale-95 transition"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    max="5000"
                    value={actualValue}
                    onChange={(e) => {
                      const val = parseInt(e.target.value, 10);
                      setActualValue(isNaN(val) ? 1 : Math.max(1, val));
                    }}
                    className="w-16 text-center font-bold bg-[#191D21] border border-[#374350] rounded-lg py-1 text-sm text-[#F4F6F8]"
                  />
                  <button
                    type="button"
                    onClick={() => setActualValue(actualValue + 1)}
                    className="w-8 h-8 rounded-lg bg-[#22282E] text-[#F4F6F8] font-bold hover:bg-[#2C353D] active:scale-95 transition"
                  >
                    +
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center gap-1.5 mt-2 text-xs text-[#9AA5B1]">
              <Info className="w-3.5 h-3.5 flex-shrink-0 text-[#2DD4BF]" />
              <span>
                {isRest
                  ? 'Pemulihan dicatat terpisah dan tidak menambah repetisi olahraga.'
                  : 'Boleh menurunkan repetisi jika lelah. Setiap gerakan tetap dicatat!'}
              </span>
            </div>
          </div>
        )}

        {/* Validation error message */}
        {validationError && (
          <div className="flex items-center gap-1.5 text-xs text-[#E11D48] bg-[#E11D48]/10 p-2 rounded-lg mb-3 border border-[#E11D48]/30">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Action Buttons tailored by item type */}
        <div className="flex flex-col gap-2.5 mt-4">
          {/* Main completion / rest button */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={handleCompleteClick}
            className={`w-full py-3.5 px-4 font-black rounded-xl flex items-center justify-center gap-2 shadow-lg transition cursor-pointer disabled:opacity-50 ${
              isRest
                ? 'bg-[#2DD4BF] hover:bg-[#14B8A6] text-[#101214] shadow-[#2DD4BF]/20'
                : 'bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] shadow-[#C6F36A]/20'
            }`}
          >
            <CheckCircle2 className="w-5 h-5" />
            {isRest ? 'Selesaikan Istirahat Sekarang' : 'Tandai Selesai Sekarang'}
          </button>

          {/* Quick Actions Grid */}
          <div className="grid grid-cols-2 gap-2">
            {item.type === 'duration' || item.type === 'rest' ? (
              <button
                type="button"
                onClick={() => onStart(actualValue)}
                className="py-2.5 px-3 bg-[#22282E] hover:bg-[#2A323B] text-[#F4F6F8] text-xs sm:text-sm font-semibold rounded-xl flex items-center justify-center gap-1.5 transition border border-[#2D3844]"
              >
                <Clock className="w-4 h-4 text-[#2DD4BF]" />
                {isRest ? 'Mulai Timer Istirahat' : 'Mulai Timer'}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onStart(actualValue)}
                className="py-2.5 px-3 bg-[#22282E] hover:bg-[#2A323B] text-[#F4F6F8] text-xs sm:text-sm font-semibold rounded-xl flex items-center justify-center gap-1.5 transition border border-[#2D3844]"
              >
                <Sparkles className="w-4 h-4 text-[#C6F36A]" />
                Mulai Tantangan
              </button>
            )}

            <button
              type="button"
              onClick={() => onAddToQueue(actualValue)}
              className="py-2.5 px-3 bg-[#22282E] hover:bg-[#2A323B] text-[#F4F6F8] text-xs sm:text-sm font-semibold rounded-xl flex items-center justify-center gap-1.5 transition border border-[#2D3844]"
            >
              <PlusCircle className="w-4 h-4 text-[#0EA5E9]" />
              Masuk Antrean
            </button>
          </div>

          {/* Skip / Close */}
          <div className="flex items-center justify-between pt-1">
            <button
              type="button"
              onClick={onSkip}
              className="text-xs text-[#9AA5B1] hover:text-[#F4F6F8] flex items-center gap-1 py-1 px-2 rounded transition"
            >
              <SkipForward className="w-3.5 h-3.5" />
              Lewati Tantangan
            </button>
            <button
              type="button"
              onClick={onClose}
              className="text-xs text-[#9AA5B1] hover:text-[#F4F6F8] flex items-center gap-1 py-1 px-2 rounded transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Tutup & Putar Ulang
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
