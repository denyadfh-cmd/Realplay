import React, { useEffect, useRef, useState, useId } from 'react';
import { WheelItem } from '../../types/index';
import { computeSegmentAngles, calculateTargetRotation, resolveItemIndexAtRotation } from '../../domain/random';
import { soundService } from '../../services/audio';

export interface SpinWheelProps {
  items: WheelItem[];
  selectionMode?: 'equal' | 'weighted';
  isSpinning: boolean;
  spinId?: string | null;
  targetIndex: number | null;
  onSpinFinish: () => void;
  reducedMotion?: boolean;
}

export const SpinWheel: React.FC<SpinWheelProps> = ({
  items,
  selectionMode = 'equal',
  isSpinning,
  spinId = null,
  targetIndex,
  onSpinFinish,
  reducedMotion = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentRotation, setCurrentRotation] = useState<number>(0);
  const rotationRef = useRef<number>(0);
  const lastTickAngleRef = useRef<number>(0);
  const animationFrameRef = useRef<number | null>(null);
  const activeSpinIdRef = useRef<string | null>(null);
  const isAnimatingRef = useRef<boolean>(false);
  const announcementId = useId();
  const [announcement, setAnnouncement] = useState<string>('');

  // Slices computation
  const segments = computeSegmentAngles(items, selectionMode);
  const numItems = items.length;

  // Wheel dimensions
  const size = 420;
  const radius = size / 2;
  const center = radius;
  const hubRadius = 48;

  // Polar to Cartesian conversion where 0° is 12 o'clock, increasing clockwise
  const polarToCartesian = (centerX: number, centerY: number, r: number, angleInDegrees: number) => {
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
    return {
      x: centerX + r * Math.cos(angleInRadians),
      y: centerY + r * Math.sin(angleInRadians),
    };
  };

  // Clockwise wedge path
  const describeArc = (x: number, y: number, r: number, startAngle: number, endAngle: number) => {
    const span = endAngle - startAngle;
    if (span >= 359.99) {
      return `M ${x} ${y - r} A ${r} ${r} 0 1 1 ${x} ${y + r} A ${r} ${r} 0 1 1 ${x} ${y - r} Z`;
    }
    const start = polarToCartesian(x, y, r, startAngle);
    const end = polarToCartesian(x, y, r, endAngle);
    const largeArcFlag = span > 180 ? 1 : 0;
    return `M ${x} ${y} L ${start.x} ${start.y} A ${r} ${r} 0 ${largeArcFlag} 1 ${end.x} ${end.y} Z`;
  };

  // Trigger animation ONLY when a new spin is started (identified by spinId)
  useEffect(() => {
    // If not spinning or no valid target, do nothing
    if (!isSpinning || targetIndex === null || targetIndex < 0 || numItems === 0) {
      return;
    }

    // P0-02 FIX: If this exact spinId is already running, DO NOT restart the animation!
    if (spinId && activeSpinIdRef.current === spinId && isAnimatingRef.current) {
      return;
    }

    activeSpinIdRef.current = spinId;
    isAnimatingRef.current = true;

    // Snapshot frozen items for this specific spin to prevent mid-spin mutation
    const frozenItems = [...items];
    const frozenMode = selectionMode;

    const { targetRotation } = calculateTargetRotation(
      rotationRef.current,
      targetIndex,
      frozenItems,
      frozenMode,
      reducedMotion ? 2 : 6,
      reducedMotion ? 3 : 8
    );

    // Verify consistency: resolveItemIndexAtRotation MUST equal targetIndex
    const resolvedIndex = resolveItemIndexAtRotation(targetRotation, frozenItems, frozenMode);
    if (resolvedIndex !== targetIndex) {
      console.warn(`[SpinWheel] Segment resolver alignment check: expected ${targetIndex}, got ${resolvedIndex}`);
    }

    const startRot = rotationRef.current;
    const deltaRot = targetRotation - startRot;
    const durationMs = reducedMotion ? 800 : 4000;
    const startTime = performance.now();
    lastTickAngleRef.current = startRot;

    // Smooth physics ease-out cubic
    const easeOutCubic = (t: number): number => {
      const f = t - 1;
      return f * f * f + 1;
    };

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(1, elapsed / durationMs);
      const easedProgress = easeOutCubic(progress);
      const newRotation = startRot + deltaRot * easedProgress;

      rotationRef.current = newRotation;
      setCurrentRotation(newRotation);

      // Play tick sound every slice increment
      const sliceDeg = 360 / Math.max(1, numItems);
      if (Math.abs(newRotation - lastTickAngleRef.current) >= sliceDeg) {
        soundService.playTick();
        lastTickAngleRef.current = newRotation;
      }

      if (progress < 1) {
        animationFrameRef.current = requestAnimationFrame(animate);
      } else {
        // Complete the spin cleanly
        rotationRef.current = targetRotation;
        setCurrentRotation(targetRotation);
        isAnimatingRef.current = false;

        const winningItem = frozenItems[targetIndex];
        if (winningItem) {
          setAnnouncement(`Roda berhenti tepat pada: ${winningItem.label}`);
          // Sound: only play cheerful chime for workouts; gentle tone for rest
          if (winningItem.isWorkout && winningItem.type !== 'rest') {
            soundService.playWinChime();
          } else {
            soundService.playTick();
          }
        }

        onSpinFinish();
      }
    };

    animationFrameRef.current = requestAnimationFrame(animate);

    return () => {
      // Cleanup only on unmount or if spin explicitly stopped
      if (!isSpinning && animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        isAnimatingRef.current = false;
      }
    };
  }, [isSpinning, spinId, targetIndex, reducedMotion, onSpinFinish, numItems]);

  // Adaptive font sizing
  const getFontSize = () => {
    if (numItems <= 4) return 15;
    if (numItems <= 8) return 13;
    if (numItems <= 14) return 11;
    if (numItems <= 20) return 9.5;
    return 8;
  };

  const getTextColor = (bgColor?: string) => {
    if (!bgColor) return '#101214';
    const lower = bgColor.toLowerCase();
    if (lower === '#c6f36a' || lower === '#f59e0b' || lower === '#d9f99d' || lower === '#a3e635') {
      return '#0A0C0E';
    }
    return '#FFFFFF';
  };

  return (
    <div className="relative flex flex-col items-center justify-center p-2 select-none" ref={containerRef}>
      {/* Screen reader live region */}
      <div id={announcementId} className="sr-only" aria-live="polite" aria-atomic="true">
        {announcement}
      </div>

      {/* Needle Pointer at 12 o'clock (0°) */}
      <div
        className="absolute top-1 z-20 flex flex-col items-center drop-shadow-[0_4px_14px_rgba(0,0,0,0.9)] pointer-events-none"
        aria-hidden="true"
      >
        <svg width="34" height="42" viewBox="0 0 34 42" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Outer high-contrast needle body */}
          <path
            d="M17 40L6 4C6 2.5 7.5 1 9.5 1H24.5C26.5 1 28 2.5 28 4L17 40Z"
            fill="#C6F36A"
            stroke="#101214"
            strokeWidth="2.5"
          />
          {/* Inner needle contrast accent */}
          <polygon points="17,32 11,6 23,6" fill="#101214" />
          <circle cx="17" cy="10" r="3.5" fill="#C6F36A" />
        </svg>
      </div>

      {/* Main Wheel Container */}
      <div
        className="relative rounded-full shadow-[0_12px_45px_rgba(0,0,0,0.7)] p-1.5 sm:p-2 bg-gradient-to-b from-[#242C34] to-[#121518] border border-[#2D3844] flex items-center justify-center aspect-square"
        style={{ width: 'min(68vw, 420px)', height: 'min(68vw, 420px)' }}
      >
        <svg
          viewBox={`0 0 ${size} ${size}`}
          className="rounded-full w-full h-full"
          style={{
            transform: `rotate(${currentRotation}deg)`,
            transformOrigin: 'center center',
            transition: isSpinning ? 'none' : 'transform 0.1s ease-out',
          }}
        >
          <defs>
            <filter id="wheelShadow" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="0" dy="2" stdDeviation="4" floodColor="#000000" floodOpacity="0.4" />
            </filter>
          </defs>

          {/* Outer Rim */}
          <circle cx={center} cy={center} r={radius - 2} fill="#14181D" stroke="#374350" strokeWidth="4" />

          {/* Slices / Segments */}
          {segments.map((seg) => {
            const item = items[seg.index];
            const pathData = describeArc(center, center, radius - 6, seg.startAngle, seg.endAngle);
            const midAngle = seg.centerAngle;

            // Text placement: along radius
            const textRadius = radius * 0.63;
            const textPos = polarToCartesian(center, center, textRadius, midAngle);
            const textColor = getTextColor(item?.color);
            const fontSize = getFontSize();

            // Upright readability logic:
            // Text reads outward on right side (0..180) and inward on left side (180..360)
            const isRightSide = midAngle <= 180;
            const textRotation = isRightSide ? midAngle - 90 : midAngle + 90;

            const rawLabel = item?.label || '';
            const maxChars = numItems > 14 ? 9 : numItems > 8 ? 13 : 18;
            const displayLabel = rawLabel.length > maxChars ? `${rawLabel.slice(0, maxChars - 1)}..` : rawLabel;

            return (
              <g key={`slice-${item?.id || seg.index}`}>
                <path
                  d={pathData}
                  fill={item?.color || '#3B82F6'}
                  stroke="#161B20"
                  strokeWidth="2"
                  className="transition-colors"
                />
                {/* Text Label aligned for optimal legibility */}
                <g transform={`translate(${textPos.x}, ${textPos.y}) rotate(${textRotation})`}>
                  <text
                    x="0"
                    y="0"
                    fill={textColor}
                    fontSize={fontSize}
                    fontWeight="700"
                    fontFamily="ui-sans-serif, system-ui, sans-serif"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    style={{
                      letterSpacing: '-0.02em',
                      textShadow: textColor === '#FFFFFF' ? '0 1px 3px rgba(0,0,0,0.85)' : 'none',
                    }}
                  >
                    {displayLabel}
                  </text>
                </g>
              </g>
            );
          })}

          {/* Pegs / Rim Studs */}
          {segments.map((seg) => {
            const pegPos = polarToCartesian(center, center, radius - 8, seg.startAngle);
            return (
              <circle
                key={`peg-${seg.index}`}
                cx={pegPos.x}
                cy={pegPos.y}
                r="3.5"
                fill="#F4F6F8"
                stroke="#1E252D"
                strokeWidth="1.5"
              />
            );
          })}

          {/* Central Hub Ring */}
          <circle
            cx={center}
            cy={center}
            r={hubRadius + 6}
            fill="#12161A"
            stroke="#C6F36A"
            strokeWidth="3"
            filter="url(#wheelShadow)"
          />
          <circle cx={center} cy={center} r={hubRadius} fill="#181D23" />
          <circle cx={center} cy={center} r={hubRadius - 12} fill="#101214" stroke="#2C3742" strokeWidth="2" />

          {/* Center REALPLAY Hub Text */}
          <text
            x={center}
            y={center - 7}
            fill="#C6F36A"
            fontSize="10"
            fontWeight="900"
            textAnchor="middle"
            dominantBaseline="middle"
            letterSpacing="0.1em"
          >
            REALPLAY
          </text>
          <text
            x={center}
            y={center + 8}
            fill="#9AA5B1"
            fontSize="8"
            fontWeight="600"
            textAnchor="middle"
            dominantBaseline="middle"
            letterSpacing="0.05em"
          >
            FITNESS
          </text>
        </svg>
      </div>
    </div>
  );
};
