import React from 'react';
import { WorkoutSession, Challenge } from '../../types/index';
import { Play, CheckCircle2, ListOrdered, Flame, HeartPulse } from 'lucide-react';

interface ActiveSessionBarProps {
  session: WorkoutSession | null;
  queue: Challenge[];
  sessionCompletionsCount: number;
  onFinishSession: () => void;
  onOpenWarmup: () => void;
  onOpenQueue: () => void;
}

export const ActiveSessionBar: React.FC<ActiveSessionBarProps> = ({
  session,
  queue,
  sessionCompletionsCount,
  onFinishSession,
  onOpenWarmup,
  onOpenQueue,
}) => {
  if (!session) return null;

  return (
    <div className="w-full bg-[#191D21] border-b border-[#2A323B] px-4 py-2.5">
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Session Info */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C6F36A] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#C6F36A]"></span>
            </span>
            <span className="text-xs font-bold text-[#F4F6F8] tracking-wide">
              {session.name}
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-[#9AA5B1]">
            <span className="px-2 py-0.5 rounded bg-[#22282E] font-medium text-[#C6F36A] border border-[#2D3844]">
              {sessionCompletionsCount} selesai
            </span>
            {queue.length > 0 && (
              <span className="px-2 py-0.5 rounded bg-[#22282E] font-medium text-[#0EA5E9] border border-[#2D3844]">
                {queue.length} di antrean
              </span>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenWarmup}
            className="px-2.5 py-1 text-xs font-medium text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] rounded-lg transition border border-transparent hover:border-[#2D3844]"
          >
            Pemanasan
          </button>

          <button
            type="button"
            onClick={onOpenQueue}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg bg-[#22282E] hover:bg-[#2C353D] text-[#F4F6F8] border border-[#2D3844] transition"
          >
            <ListOrdered className="w-3.5 h-3.5 text-[#0EA5E9]" />
            Antrean ({queue.length})
          </button>

          <button
            type="button"
            onClick={onFinishSession}
            className="px-3 py-1 text-xs font-bold rounded-lg bg-[#22282E] hover:bg-[#E11D48]/20 text-[#E11D48] hover:text-[#F43F5E] border border-[#E11D48]/30 transition"
          >
            Selesai Sesi
          </button>
        </div>
      </div>
    </div>
  );
};
