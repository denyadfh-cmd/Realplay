import React, { useState } from 'react';
import { Challenge } from '../../types/index';
import {
  ListOrdered,
  ArrowUp,
  ArrowDown,
  Trash2,
  Play,
  CheckCircle2,
  Clock,
  X,
  AlertCircle,
} from 'lucide-react';

interface QueueManagerProps {
  queue: Challenge[];
  onStartChallenge: (challenge: Challenge) => void;
  onCompleteChallenge: (challenge: Challenge, actualVal: number) => void;
  onRemoveChallenge: (challengeId: string) => void;
  onReorderQueue: (newQueue: Challenge[]) => void;
  onClearQueue: () => void;
  onClose: () => void;
}

export const QueueManager: React.FC<QueueManagerProps> = ({
  queue,
  onStartChallenge,
  onCompleteChallenge,
  onRemoveChallenge,
  onReorderQueue,
  onClearQueue,
  onClose,
}) => {
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [completingId, setCompletingId] = useState<string | null>(null);
  const [actualInput, setActualInput] = useState<number>(1);

  const moveItem = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= queue.length) return;

    const updated = [...queue];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;
    onReorderQueue(updated);
  };

  const handleOpenCompleteModal = (c: Challenge) => {
    setCompletingId(c.id);
    setActualInput(c.targetValue || 1);
  };

  const submitComplete = (c: Challenge) => {
    onCompleteChallenge(c, actualInput);
    setCompletingId(null);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="queue-manager-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="w-full max-w-lg bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 shadow-2xl flex flex-col max-h-[85vh] relative">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#242C35]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#0EA5E9]/10 border border-[#0EA5E9]/30 flex items-center justify-center text-[#0EA5E9]">
              <ListOrdered className="w-4 h-4" />
            </div>
            <div>
              <h3 id="queue-manager-title" className="text-lg font-bold text-[#F4F6F8]">
                Antrean Latihan Aktif
              </h3>
              <p className="text-xs text-[#9AA5B1]">
                {queue.length} tantangan tersisa dalam sesi ini
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
            aria-label="Tutup Antrean"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto py-4 space-y-2.5">
          {queue.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-12 h-12 mx-auto rounded-full bg-[#22282E] flex items-center justify-center text-[#9AA5B1] mb-3">
                <ListOrdered className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-semibold text-[#F4F6F8]">Antrean Kosong</h4>
              <p className="text-xs text-[#9AA5B1] mt-1 max-w-xs mx-auto">
                Putar roda lalu pilih "Masuk Antrean" untuk menyusun rangkaian latihan sebelum memulai.
              </p>
            </div>
          ) : (
            queue.map((ch, idx) => (
              <div
                key={ch.id}
                className="bg-[#121518] border border-[#242C35] rounded-xl p-3 flex items-center justify-between gap-3 hover:border-[#374350] transition"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="w-6 text-center font-mono text-xs font-bold text-[#9AA5B1]">
                    {idx + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-[#F4F6F8] truncate">
                      {ch.labelSnapshot}
                    </p>
                    <p className="text-xs text-[#C6F36A] font-semibold">
                      Target: {ch.targetValue || 1} {ch.unit || 'reps'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {/* Reorder controls */}
                  <button
                    disabled={idx === 0}
                    onClick={() => moveItem(idx, 'up')}
                    className="p-1 rounded text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] disabled:opacity-30 disabled:pointer-events-none transition"
                    title="Geser ke Atas"
                    aria-label={`Geser item ${idx + 1} ke atas`}
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    disabled={idx === queue.length - 1}
                    onClick={() => moveItem(idx, 'down')}
                    className="p-1 rounded text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] disabled:opacity-30 disabled:pointer-events-none transition"
                    title="Geser ke Bawah"
                    aria-label={`Geser item ${idx + 1} ke bawah`}
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>

                  {/* Start or mark done */}
                  <button
                    onClick={() => onStartChallenge(ch)}
                    className="p-1.5 rounded-lg bg-[#22282E] text-[#0EA5E9] hover:bg-[#0EA5E9]/20 transition"
                    title="Mulai Latihan Ini"
                    aria-label={`Mulai ${ch.labelSnapshot}`}
                  >
                    <Play className="w-4 h-4 fill-current" />
                  </button>
                  <button
                    onClick={() => handleOpenCompleteModal(ch)}
                    className="p-1.5 rounded-lg bg-[#22282E] text-[#C6F36A] hover:bg-[#C6F36A]/20 transition"
                    title="Tandai Selesai"
                    aria-label={`Tandai selesai ${ch.labelSnapshot}`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onRemoveChallenge(ch.id)}
                    className="p-1.5 rounded-lg bg-[#22282E] text-[#E11D48] hover:bg-[#E11D48]/20 transition"
                    title="Hapus dari antrean"
                    aria-label={`Hapus ${ch.labelSnapshot}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Actions */}
        {queue.length > 0 && (
          <div className="pt-3 border-t border-[#242C35] flex items-center justify-between">
            <button
              onClick={() => setShowClearConfirm(true)}
              className="text-xs text-[#E11D48] hover:underline flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Bersihkan Antrean
            </button>
            <button
              onClick={() => onStartChallenge(queue[0])}
              className="px-4 py-2 bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Mulai Tantangan Pertama
            </button>
          </div>
        )}

        {/* Clear Confirmation Dialog */}
        {showClearConfirm && (
          <div className="absolute inset-0 bg-[#191D21]/95 rounded-2xl flex flex-col items-center justify-center p-6 text-center z-10 animate-in fade-in">
            <AlertCircle className="w-10 h-10 text-[#E11D48] mb-2" />
            <h4 className="text-base font-bold text-[#F4F6F8]">Kosongkan Antrean?</h4>
            <p className="text-xs text-[#9AA5B1] mt-1 mb-5 max-w-xs">
              Semua {queue.length} tantangan di antrean ini akan dibatalkan. Riwayat latihan yang telah selesai tidak akan terhapus.
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#22282E] text-[#F4F6F8]"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  onClearQueue();
                  setShowClearConfirm(false);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#E11D48] hover:bg-[#BE123C] text-white"
              >
                Ya, Bersihkan
              </button>
            </div>
          </div>
        )}

        {/* Quick Complete Value Input Modal */}
        {completingId && (
          <div className="absolute inset-0 bg-[#191D21]/95 rounded-2xl flex flex-col items-center justify-center p-6 text-center z-10 animate-in fade-in">
            <CheckCircle2 className="w-10 h-10 text-[#C6F36A] mb-2" />
            <h4 className="text-base font-bold text-[#F4F6F8]">Catat Penyelesaian</h4>
            <p className="text-xs text-[#9AA5B1] mt-1 mb-3">
              Berapa repetisi atau durasi aktual yang kamu lakukan?
            </p>
            <div className="flex items-center gap-2 mb-5">
              <button
                onClick={() => setActualInput(Math.max(1, actualInput - 1))}
                className="w-9 h-9 rounded-lg bg-[#22282E] text-[#F4F6F8] font-bold"
              >
                -
              </button>
              <input
                type="number"
                min="1"
                max="5000"
                value={actualInput}
                onChange={(e) => setActualInput(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-20 text-center font-bold bg-[#121518] border border-[#374350] rounded-lg py-1.5 text-base text-[#F4F6F8]"
              />
              <button
                onClick={() => setActualInput(actualInput + 1)}
                className="w-9 h-9 rounded-lg bg-[#22282E] text-[#F4F6F8] font-bold"
              >
                +
              </button>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCompletingId(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#22282E] text-[#F4F6F8]"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  const targetCh = queue.find((c) => c.id === completingId);
                  if (targetCh) submitComplete(targetCh);
                }}
                className="px-4 py-2 rounded-xl text-xs font-extrabold bg-[#C6F36A] text-[#101214]"
              >
                Simpan & Selesai
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
