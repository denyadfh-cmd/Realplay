import React from 'react';
import { ShieldCheck, HeartPulse, AlertTriangle, Check, X, Sparkles } from 'lucide-react';

interface WarmupModalProps {
  onStartWorkout: () => void;
  onClose: () => void;
}

export const WarmupModal: React.FC<WarmupModalProps> = ({ onStartWorkout, onClose }) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="warmup-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="w-full max-w-lg bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
          aria-label="Tutup Panduan"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-[#C6F36A]/10 border border-[#C6F36A]/30 flex items-center justify-center text-[#C6F36A]">
            <HeartPulse className="w-6 h-6" />
          </div>
          <div>
            <h3 id="warmup-modal-title" className="text-xl font-bold text-[#F4F6F8]">
              Pemanasan & Panduan Keselamatan
            </h3>
            <p className="text-xs text-[#9AA5B1]">Jaga tubuh tetap aman dan siap sebelum berolahraga</p>
          </div>
        </div>

        {/* Warmup Checklist */}
        <div className="space-y-3 my-5">
          <div className="p-3.5 bg-[#121518] rounded-xl border border-[#242C35] flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-[#C6F36A] flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-[#F4F6F8]">1. Putar Sendi & Leher (1–2 Menit)</h4>
              <p className="text-xs text-[#9AA5B1] mt-0.5">
                Lakukan putaran leher perlahan, putaran bahu ke depan dan belakang, serta putaran pergelangan tangan dan kaki.
              </p>
            </div>
          </div>

          <div className="p-3.5 bg-[#121518] rounded-xl border border-[#242C35] flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-[#2DD4BF] flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-[#F4F6F8]">2. Gerakan Dinamis Ringan (2 Menit)</h4>
              <p className="text-xs text-[#9AA5B1] mt-0.5">
                Jalan di tempat, arm swings ke depan-belakang, dan butt kicks ringan untuk mengalirkan darah ke otot besar.
              </p>
            </div>
          </div>

          <div className="p-3.5 bg-[#121518] rounded-xl border border-[#242C35] flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-[#F59E0B] flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-[#F59E0B]">3. Prinsip Keselamatan REALPLAY</h4>
              <p className="text-xs text-[#9AA5B1] mt-0.5">
                Segera berhenti jika timbul rasa nyeri tajam, pusing, atau sesak napas. Kamu selalu berhak melewati tantangan atau menurunkan target repetisi tanpa penalti apapun.
              </p>
            </div>
          </div>
        </div>

        {/* Safety Disclaimer */}
        <p className="text-[11px] text-[#9AA5B1] leading-relaxed mb-6">
          * REALPLAY adalah alat permainan dan motivasi gerak. Bukan pengganti nasihat medis. Dengarkan tubuhmu dan lakukan sesuai batas kemampuanmu saat ini.
        </p>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-sm font-semibold text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
          >
            Nanti Saja
          </button>
          <button
            type="button"
            onClick={onStartWorkout}
            className="px-5 py-2.5 rounded-xl text-sm font-extrabold bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] flex items-center gap-2 shadow-lg shadow-[#C6F36A]/20 transition"
          >
            <Check className="w-4 h-4" />
            Saya Siap, Mulai Latihan!
          </button>
        </div>
      </div>
    </div>
  );
};
