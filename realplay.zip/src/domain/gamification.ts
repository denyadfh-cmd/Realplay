import { Achievement, CompletionRecord, UserSettings } from '../types/index';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach-first-spin',
    code: 'first_spin',
    title: 'First Spin',
    description: 'Melakukan putaran roda keberuntungan pertama di REALPLAY.',
    icon: 'Disc',
    progress: 0,
    maxProgress: 1,
    xpReward: 25,
  },
  {
    id: 'ach-first-move',
    code: 'first_move',
    title: 'First Move',
    description: 'Menyelesaikan tantangan fisik nyata pertama kali.',
    icon: 'Flame',
    progress: 0,
    maxProgress: 1,
    xpReward: 50,
  },
  {
    id: 'ach-consistency-starter',
    code: 'consistency_starter',
    title: 'Consistency Starter',
    description: 'Berolahraga secara konsisten pada 3 hari yang berbeda.',
    icon: 'CalendarCheck',
    progress: 0,
    maxProgress: 3,
    xpReward: 100,
  },
  {
    id: 'ach-wheel-creator',
    code: 'wheel_creator',
    title: 'Wheel Creator',
    description: 'Membuat roda latihan custom milikmu sendiri.',
    icon: 'Wrench',
    progress: 0,
    maxProgress: 1,
    xpReward: 40,
  },
  {
    id: 'ach-variety-explorer',
    code: 'variety_explorer',
    title: 'Variety Explorer',
    description: 'Menyelesaikan latihan dari 3 kategori aktivitas yang berbeda.',
    icon: 'Compass',
    progress: 0,
    maxProgress: 3,
    xpReward: 75,
  },
  {
    id: 'ach-century-reps',
    code: 'century_reps',
    title: 'Centurion',
    description: 'Mengumpulkan total 100 repetisi latihan fisik yang tercatat.',
    icon: 'Award',
    progress: 0,
    maxProgress: 100,
    xpReward: 150,
  },
  {
    id: 'ach-iron-core',
    code: 'iron_core',
    title: 'Iron Core',
    description: 'Menyelesaikan 5 latihan kategori core (plank, sit-up, dsb).',
    icon: 'Shield',
    progress: 0,
    maxProgress: 5,
    xpReward: 80,
  },
  {
    id: 'ach-smart-recovery',
    code: 'smart_recovery',
    title: 'Smart Recovery',
    description: 'Mengambil waktu istirahat atau peregangan untuk pemulihan tubuh.',
    icon: 'HeartPulse',
    progress: 0,
    maxProgress: 1,
    xpReward: 30,
  },
];

/**
 * Calculates XP earned from a completed record.
 * Spin alone does NOT grant XP. Only completed actions count.
 */
export function calculateCompletionXP(record: {
  isWorkout: boolean;
  actualValue?: number;
  unit?: string;
  durationSeconds?: number;
}): number {
  let xp = 15; // base completion XP

  if (record.isWorkout) {
    if (record.unit === 'reps' || record.unit === 'kali') {
      const reps = Math.max(0, record.actualValue || 0);
      xp += reps * 3;
    } else if (record.unit === 'detik' || record.unit === 'menit') {
      const durSec = record.unit === 'menit' ? (record.actualValue || 0) * 60 : (record.actualValue || 0);
      xp += Math.floor(Math.max(0, durSec) / 4);
    } else if (record.unit === 'meter' || record.unit === 'km') {
      const meters = record.unit === 'km' ? (record.actualValue || 0) * 1000 : (record.actualValue || 0);
      xp += Math.floor(Math.max(0, meters) / 50);
    } else {
      xp += 10;
    }
  } else {
    // Rest or recovery item
    xp = 10;
  }

  return Math.min(xp, 500); // capped safely per challenge
}

/**
 * Determines user level based on total XP using a progressive curve.
 * Level N requires (N - 1) * 150 + (N - 1)^2 * 25 XP.
 */
export function calculateLevelFromXP(totalXP: number): {
  level: number;
  currentLevelXP: number;
  nextLevelXP: number;
  progressPercent: number;
} {
  if (totalXP <= 0) {
    return { level: 1, currentLevelXP: 0, nextLevelXP: 100, progressPercent: 0 };
  }

  let level = 1;
  let xpAccumulated = 0;

  while (true) {
    const xpNeededForThisLevel = 100 + (level - 1) * 75;
    if (totalXP < xpAccumulated + xpNeededForThisLevel) {
      const currentLevelXP = totalXP - xpAccumulated;
      const progressPercent = Math.min(100, Math.round((currentLevelXP / xpNeededForThisLevel) * 100));
      return {
        level,
        currentLevelXP,
        nextLevelXP: xpNeededForThisLevel,
        progressPercent,
      };
    }
    xpAccumulated += xpNeededForThisLevel;
    level++;
  }
}

/**
 * Evaluates achievements based on completion records and activity history.
 * Returns newly unlocked achievements to avoid duplicate awards.
 */
export function evaluateAchievements(
  currentAchievements: Achievement[],
  allCompletions: CompletionRecord[],
  hasCustomWheel: boolean,
  hasSpunOnce: boolean
): { updatedAchievements: Achievement[]; newlyUnlocked: Achievement[]; totalXpGained: number } {
  let totalXpGained = 0;
  const newlyUnlocked: Achievement[] = [];

  // Group days of activity
  const activeDaysSet = new Set<string>();
  let totalReps = 0;
  let coreCount = 0;
  const categoriesSet = new Set<string>();
  let hasRestRecovery = false;

  for (const c of allCompletions) {
    const dateStr = new Date(c.completedAt).toISOString().split('T')[0];
    activeDaysSet.add(dateStr);

    if (c.isWorkout && (c.unit === 'reps' || c.unit === 'kali')) {
      totalReps += c.actualValue || 0;
    }
    if (c.category === 'core') {
      coreCount++;
    }
    if (c.category) {
      categoriesSet.add(c.category);
    }
    if (!c.isWorkout || c.category === 'mobility_rest') {
      hasRestRecovery = true;
    }
  }

  const updatedAchievements = currentAchievements.map((ach) => {
    // Already unlocked
    if (ach.unlockedAt) {
      return ach;
    }

    let progress = ach.progress;
    let shouldUnlock = false;

    switch (ach.code) {
      case 'first_spin':
        progress = hasSpunOnce ? 1 : 0;
        shouldUnlock = progress >= ach.maxProgress;
        break;

      case 'first_move':
        progress = allCompletions.filter((c) => c.isWorkout).length > 0 ? 1 : 0;
        shouldUnlock = progress >= ach.maxProgress;
        break;

      case 'consistency_starter':
        progress = Math.min(ach.maxProgress, activeDaysSet.size);
        shouldUnlock = progress >= ach.maxProgress;
        break;

      case 'wheel_creator':
        progress = hasCustomWheel ? 1 : 0;
        shouldUnlock = progress >= ach.maxProgress;
        break;

      case 'variety_explorer':
        progress = Math.min(ach.maxProgress, categoriesSet.size);
        shouldUnlock = progress >= ach.maxProgress;
        break;

      case 'century_reps':
        progress = Math.min(ach.maxProgress, totalReps);
        shouldUnlock = progress >= ach.maxProgress;
        break;

      case 'iron_core':
        progress = Math.min(ach.maxProgress, coreCount);
        shouldUnlock = progress >= ach.maxProgress;
        break;

      case 'smart_recovery':
        progress = hasRestRecovery ? 1 : 0;
        shouldUnlock = progress >= ach.maxProgress;
        break;

      default:
        break;
    }

    if (shouldUnlock && !ach.unlockedAt) {
      const unlockedAch: Achievement = {
        ...ach,
        progress: ach.maxProgress,
        unlockedAt: Date.now(),
      };
      newlyUnlocked.push(unlockedAch);
      totalXpGained += ach.xpReward;
      return unlockedAch;
    }

    return { ...ach, progress };
  });

  return { updatedAchievements, newlyUnlocked, totalXpGained };
}
