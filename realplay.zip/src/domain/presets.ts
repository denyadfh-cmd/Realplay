import { Wheel } from '../types/index';

// High-contrast, colorblind-friendly athletic sport palette
export const SPORT_PALETTE = [
  '#C6F36A', // Electric Lime
  '#0EA5E9', // Sky Blue
  '#F59E0B', // Warm Amber
  '#EC4899', // Pink Fuchsia
  '#10B981', // Emerald
  '#8B5CF6', // Purple
  '#F97316', // Orange
  '#14B8A6', // Teal
  '#6366F1', // Indigo
  '#E11D48', // Crimson Rose
];

export const BUILTIN_PRESETS: Wheel[] = [
  {
    id: 'preset-number-challenge',
    name: 'Number Challenge (1–10)',
    description: 'Angka acak 1 sampai 10 untuk menentukan jumlah repetisi latihan.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'num-1', label: '1 Repetisi', type: 'number', value: 1, unit: 'reps', color: SPORT_PALETTE[0], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-2', label: '2 Repetisi', type: 'number', value: 2, unit: 'reps', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-3', label: '3 Repetisi', type: 'number', value: 3, unit: 'reps', color: SPORT_PALETTE[2], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-4', label: '4 Repetisi', type: 'number', value: 4, unit: 'reps', color: SPORT_PALETTE[3], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-5', label: '5 Repetisi', type: 'number', value: 5, unit: 'reps', color: SPORT_PALETTE[4], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-6', label: '6 Repetisi', type: 'number', value: 6, unit: 'reps', color: SPORT_PALETTE[5], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-7', label: '7 Repetisi', type: 'number', value: 7, unit: 'reps', color: SPORT_PALETTE[6], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-8', label: '8 Repetisi', type: 'number', value: 8, unit: 'reps', color: SPORT_PALETTE[7], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-9', label: '9 Repetisi', type: 'number', value: 9, unit: 'reps', color: SPORT_PALETTE[8], trackingMode: 'repetition', isWorkout: true },
      { id: 'num-10', label: '10 Repetisi', type: 'number', value: 10, unit: 'reps', color: SPORT_PALETTE[9], trackingMode: 'repetition', isWorkout: true },
    ],
  },
  {
    id: 'preset-upper-body',
    name: 'Upper Body Power',
    description: 'Tantangan otot dada, bahu, lengan, dan trisep.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'ub-1', label: 'Push-up × 10', type: 'repetition', value: 10, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[0], trackingMode: 'repetition', isWorkout: true },
      { id: 'ub-2', label: 'Pike Push-up × 8', type: 'repetition', value: 8, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'ub-3', label: 'Tricep Dips × 12', type: 'repetition', value: 12, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[2], trackingMode: 'repetition', isWorkout: true },
      { id: 'ub-4', label: 'Diamond Push-up × 6', type: 'repetition', value: 6, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[3], trackingMode: 'repetition', isWorkout: true },
      { id: 'ub-5', label: 'Arm Circles 30s', type: 'duration', value: 30, unit: 'detik', category: 'upper_body', color: SPORT_PALETTE[4], trackingMode: 'duration', isWorkout: true },
      { id: 'ub-6', label: 'Istirahat 30s', type: 'rest', value: 30, unit: 'detik', category: 'mobility_rest', color: '#4B5563', trackingMode: 'duration', isWorkout: false },
    ],
  },
  {
    id: 'preset-lower-body',
    name: 'Lower Body Burn',
    description: 'Tantangan paha, betis, dan bokong untuk kekuatan kaki.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'lb-1', label: 'Squats × 15', type: 'repetition', value: 15, unit: 'reps', category: 'lower_body', color: SPORT_PALETTE[0], trackingMode: 'repetition', isWorkout: true },
      { id: 'lb-2', label: 'Walking Lunges × 12', type: 'repetition', value: 12, unit: 'reps', category: 'lower_body', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'lb-3', label: 'Calf Raises × 20', type: 'repetition', value: 20, unit: 'reps', category: 'lower_body', color: SPORT_PALETTE[2], trackingMode: 'repetition', isWorkout: true },
      { id: 'lb-4', label: 'Wall Sit 30s', type: 'duration', value: 30, unit: 'detik', category: 'lower_body', color: SPORT_PALETTE[3], trackingMode: 'duration', isWorkout: true },
      { id: 'lb-5', label: 'Glute Bridges × 15', type: 'repetition', value: 15, unit: 'reps', category: 'lower_body', color: SPORT_PALETTE[4], trackingMode: 'repetition', isWorkout: true },
      { id: 'lb-6', label: 'Istirahat 45s', type: 'rest', value: 45, unit: 'detik', category: 'mobility_rest', color: '#4B5563', trackingMode: 'duration', isWorkout: false },
    ],
  },
  {
    id: 'preset-full-body',
    name: 'Full Body Blitz',
    description: 'Latihan menyeluruh intensif untuk stamina dan seluruh kelompok otot.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'fb-1', label: 'Burpees × 6', type: 'repetition', value: 6, unit: 'reps', category: 'general', color: SPORT_PALETTE[0], trackingMode: 'repetition', isWorkout: true },
      { id: 'fb-2', label: 'Mountain Climbers × 20', type: 'repetition', value: 20, unit: 'reps', category: 'core', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'fb-3', label: 'Squats × 12', type: 'repetition', value: 12, unit: 'reps', category: 'lower_body', color: SPORT_PALETTE[2], trackingMode: 'repetition', isWorkout: true },
      { id: 'fb-4', label: 'Push-up × 10', type: 'repetition', value: 10, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[3], trackingMode: 'repetition', isWorkout: true },
      { id: 'fb-5', label: 'Plank 30s', type: 'duration', value: 30, unit: 'detik', category: 'core', color: SPORT_PALETTE[4], trackingMode: 'duration', isWorkout: true },
      { id: 'fb-6', label: 'High Knees 30s', type: 'duration', value: 30, unit: 'detik', category: 'cardio', color: SPORT_PALETTE[5], trackingMode: 'duration', isWorkout: true },
      { id: 'fb-7', label: 'Istirahat 45s', type: 'rest', value: 45, unit: 'detik', category: 'mobility_rest', color: '#4B5563', trackingMode: 'duration', isWorkout: false },
    ],
  },
  {
    id: 'preset-core',
    name: 'Core Crusher',
    description: 'Fokus pada kekuatan perut, stabilitas panggul, dan postur.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'cc-1', label: 'Plank 30s', type: 'duration', value: 30, unit: 'detik', category: 'core', color: SPORT_PALETTE[0], trackingMode: 'duration', isWorkout: true },
      { id: 'cc-2', label: 'Sit-up × 15', type: 'repetition', value: 15, unit: 'reps', category: 'core', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'cc-3', label: 'Bicycle Crunch × 20', type: 'repetition', value: 20, unit: 'reps', category: 'core', color: SPORT_PALETTE[2], trackingMode: 'repetition', isWorkout: true },
      { id: 'cc-4', label: 'Leg Raises × 12', type: 'repetition', value: 12, unit: 'reps', category: 'core', color: SPORT_PALETTE[3], trackingMode: 'repetition', isWorkout: true },
      { id: 'cc-5', label: 'Russian Twist × 20', type: 'repetition', value: 20, unit: 'reps', category: 'core', color: SPORT_PALETTE[4], trackingMode: 'repetition', isWorkout: true },
      { id: 'cc-6', label: 'Istirahat 30s', type: 'rest', value: 30, unit: 'detik', category: 'mobility_rest', color: '#4B5563', trackingMode: 'duration', isWorkout: false },
    ],
  },
  {
    id: 'preset-cardio',
    name: 'Cardio Blast',
    description: 'Meningkatkan denyut jantung, membakar kalori, dan melatih daya tahan.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'cb-1', label: 'Skipping 50 kali', type: 'repetition', value: 50, unit: 'kali', category: 'cardio', color: SPORT_PALETTE[0], trackingMode: 'repetition', isWorkout: true },
      { id: 'cb-2', label: 'Jumping Jacks × 30', type: 'repetition', value: 30, unit: 'reps', category: 'cardio', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'cb-3', label: 'High Knees 30s', type: 'duration', value: 30, unit: 'detik', category: 'cardio', color: SPORT_PALETTE[2], trackingMode: 'duration', isWorkout: true },
      { id: 'cb-4', label: 'Shadow Boxing 1m', type: 'duration', value: 60, unit: 'detik', category: 'cardio', color: SPORT_PALETTE[3], trackingMode: 'duration', isWorkout: true },
      { id: 'cb-5', label: 'Jalan Kaki 200m', type: 'distance', value: 200, unit: 'meter', category: 'cardio', color: SPORT_PALETTE[4], trackingMode: 'distance', isWorkout: true },
      { id: 'cb-6', label: 'Istirahat 45s', type: 'rest', value: 45, unit: 'detik', category: 'mobility_rest', color: '#4B5563', trackingMode: 'duration', isWorkout: false },
    ],
  },
  {
    id: 'preset-recovery',
    name: 'Recovery & Mobility',
    description: 'Peregangan santai untuk meredakan kekakuan otot dan pemulihan tubuh.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'rm-1', label: 'Peregangan Leher & Bahu 30s', type: 'duration', value: 30, unit: 'detik', category: 'mobility_rest', color: SPORT_PALETTE[7], trackingMode: 'duration', isWorkout: true },
      { id: 'rm-2', label: 'Forward Fold Stretch 30s', type: 'duration', value: 30, unit: 'detik', category: 'mobility_rest', color: SPORT_PALETTE[1], trackingMode: 'duration', isWorkout: true },
      { id: 'rm-3', label: 'Cat-Cow Pose 45s', type: 'duration', value: 45, unit: 'detik', category: 'mobility_rest', color: SPORT_PALETTE[4], trackingMode: 'duration', isWorkout: true },
      { id: 'rm-4', label: 'Child’s Pose 45s', type: 'duration', value: 45, unit: 'detik', category: 'mobility_rest', color: SPORT_PALETTE[5], trackingMode: 'duration', isWorkout: true },
      { id: 'rm-5', label: 'Deep Breathing 1m', type: 'duration', value: 60, unit: 'detik', category: 'mobility_rest', color: SPORT_PALETTE[0], trackingMode: 'duration', isWorkout: false },
      { id: 'rm-6', label: 'Minum Air Segar', type: 'custom', category: 'mobility_rest', color: '#38BDF8', trackingMode: 'completion', isWorkout: false },
    ],
  },
  {
    id: 'preset-handgrip',
    name: 'Handgrip & Forearms',
    description: 'Latihan kekuatan cengkeraman tangan dan lengan bawah.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'hg-1', label: 'Handgrip Kanan × 15', type: 'repetition', value: 15, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[0], trackingMode: 'repetition', isWorkout: true },
      { id: 'hg-2', label: 'Handgrip Kiri × 15', type: 'repetition', value: 15, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'hg-3', label: 'Wrist Curls × 15', type: 'repetition', value: 15, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[2], trackingMode: 'repetition', isWorkout: true },
      { id: 'hg-4', label: 'Finger Extensions 30s', type: 'duration', value: 30, unit: 'detik', category: 'upper_body', color: SPORT_PALETTE[3], trackingMode: 'duration', isWorkout: true },
      { id: 'hg-5', label: 'Istirahat 30s', type: 'rest', value: 30, unit: 'detik', category: 'mobility_rest', color: '#4B5563', trackingMode: 'duration', isWorkout: false },
    ],
  },
  {
    id: 'preset-beginner',
    name: 'Beginner Starter',
    description: 'Pilihan latihan ramah pemula yang aman, ringan, dan membangun kebiasaan.',
    source: 'builtin',
    selectionMode: 'equal',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    schemaVersion: 1,
    items: [
      { id: 'bg-1', label: 'Wall Push-up × 8', type: 'repetition', value: 8, unit: 'reps', category: 'upper_body', color: SPORT_PALETTE[0], trackingMode: 'repetition', isWorkout: true },
      { id: 'bg-2', label: 'Chair Squat × 10', type: 'repetition', value: 10, unit: 'reps', category: 'lower_body', color: SPORT_PALETTE[1], trackingMode: 'repetition', isWorkout: true },
      { id: 'bg-3', label: 'Standing Knee Raises × 12', type: 'repetition', value: 12, unit: 'reps', category: 'lower_body', color: SPORT_PALETTE[2], trackingMode: 'repetition', isWorkout: true },
      { id: 'bg-4', label: 'Jalan di Tempat 1m', type: 'duration', value: 60, unit: 'detik', category: 'cardio', color: SPORT_PALETTE[4], trackingMode: 'duration', isWorkout: true },
      { id: 'bg-5', label: 'Arm Swings 30s', type: 'duration', value: 30, unit: 'detik', category: 'upper_body', color: SPORT_PALETTE[7], trackingMode: 'duration', isWorkout: true },
      { id: 'bg-6', label: 'Istirahat & Minum 30s', type: 'rest', value: 30, unit: 'detik', category: 'mobility_rest', color: '#4B5563', trackingMode: 'duration', isWorkout: false },
    ],
  },
];
