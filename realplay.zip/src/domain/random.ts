import { WheelItem } from '../types/index';

/**
 * Generates an unbiased random integer in [0, maxExclusive) using rejection sampling
 * with Web Crypto API if available, falling back safely.
 */
export function getCryptoRandomInt(maxExclusive: number): number {
  if (maxExclusive <= 0) return 0;
  if (maxExclusive === 1) return 0;

  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const maxUint32 = 0xffffffff;
    // Limit to largest multiple of maxExclusive <= maxUint32 to eliminate modulo bias
    const limit = maxUint32 - (maxUint32 % maxExclusive);
    const buffer = new Uint32Array(1);

    while (true) {
      crypto.getRandomValues(buffer);
      const val = buffer[0];
      if (val < limit) {
        return val % maxExclusive;
      }
    }
  }

  // Fallback if crypto is not available
  return Math.floor(Math.random() * maxExclusive);
}

/**
 * Generates a crypto-grounded float in [0, 1)
 */
export function getCryptoRandomFloat(): number {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const buffer = new Uint32Array(1);
    crypto.getRandomValues(buffer);
    return buffer[0] / (0xffffffff + 1);
  }
  return Math.random();
}

/**
 * Equal-weight selection: uniformly selects one item
 */
export function selectEqualWeightItem(items: WheelItem[]): { item: WheelItem; index: number } | null {
  if (!items || items.length === 0) return null;
  const index = getCryptoRandomInt(items.length);
  return { item: items[index], index };
}

/**
 * Helper to sanitize item weights consistently across selection and slice geometry
 */
export function getSanitizedWeights(items: WheelItem[]): number[] {
  return items.map((item) => {
    const w = typeof item.weight === 'number' && Number.isFinite(item.weight) && item.weight > 0 ? item.weight : 1;
    return w;
  });
}

/**
 * Weighted selection: selects one item based on positive weights using uniform random in [0, totalWeight)
 */
export function selectWeightedItem(items: WheelItem[]): { item: WheelItem; index: number } | null {
  if (!items || items.length === 0) return null;

  const validWeights = getSanitizedWeights(items);
  const totalWeight = validWeights.reduce((acc, curr) => acc + curr, 0);

  if (totalWeight <= 0 || !Number.isFinite(totalWeight)) {
    return selectEqualWeightItem(items);
  }

  // Uniform random float in [0, totalWeight)
  const randomVal = getCryptoRandomFloat() * totalWeight;
  let runningSum = 0;

  for (let i = 0; i < items.length; i++) {
    runningSum += validWeights[i];
    if (randomVal < runningSum || i === items.length - 1) {
      return { item: items[i], index: i };
    }
  }

  return { item: items[items.length - 1], index: items.length - 1 };
}

/**
 * Selects an item based on the wheel's selectionMode
 */
export function selectWinningItem(
  items: WheelItem[],
  mode: 'equal' | 'weighted' = 'equal'
): { item: WheelItem; index: number } | null {
  if (!items || items.length === 0) return null;
  if (mode === 'weighted') {
    return selectWeightedItem(items);
  }
  return selectEqualWeightItem(items);
}

export interface SegmentAngle {
  index: number;
  startAngle: number; // degrees [0, 360) clockwise from 12 o'clock (0°)
  endAngle: number;   // degrees [0, 360) clockwise from 12 o'clock (0°)
  centerAngle: number;// degrees [0, 360)
}

/**
 * Computes segment boundaries in degrees [0, 360) for a list of items.
 * Standard Coordinate System across entire app:
 * - 0° is strictly at 12 o'clock (TOP).
 * - Angles increase clockwise: 90° is 3 o'clock (RIGHT), 180° is 6 o'clock (BOTTOM), 270° is 9 o'clock (LEFT).
 */
export function computeSegmentAngles(
  items: WheelItem[],
  mode: 'equal' | 'weighted' = 'equal'
): SegmentAngle[] {
  const n = items.length;
  if (n === 0) return [];

  const angles: SegmentAngle[] = [];

  if (mode === 'equal') {
    const sliceAngle = 360 / n;
    for (let i = 0; i < n; i++) {
      const start = i * sliceAngle;
      const end = (i + 1) * sliceAngle;
      angles.push({
        index: i,
        startAngle: start,
        endAngle: end,
        centerAngle: (start + end) / 2,
      });
    }
  } else {
    const weights = getSanitizedWeights(items);
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    let currentAngle = 0;

    for (let i = 0; i < n; i++) {
      const span = (weights[i] / totalWeight) * 360;
      const start = currentAngle;
      const end = i === n - 1 ? 360 : currentAngle + span;
      angles.push({
        index: i,
        startAngle: start,
        endAngle: end,
        centerAngle: (start + end) / 2,
      });
      currentAngle = end;
    }
  }

  return angles;
}

/**
 * Calculates the target wheel rotation (in degrees) so that when the wheel stops,
 * the top fixed pointer (at 12 o'clock / local 0°) points precisely at the selected segment.
 *
 * Geometry Proof:
 * - Fixed pointer is at 12 o'clock (screen angle = 0°).
 * - When wheel rotates clockwise by R degrees, a point on the wheel at local angle theta moves to screen angle (theta + R) mod 360.
 * - For this segment point to be under the pointer at 0°:
 *     (theta + R) = 0 mod 360 => R = (360 - theta) mod 360.
 *
 * To make a realistic spin animation, we add minFullSpins..maxFullSpins * 360 full turns.
 * Jitter is kept safely within the central 40% of the slice span [-span * 0.2, +span * 0.2]
 * to guarantee that the pointer never stops on the slice boundary.
 */
export function calculateTargetRotation(
  currentRotation: number,
  targetIndex: number,
  items: WheelItem[],
  mode: 'equal' | 'weighted' = 'equal',
  minFullSpins = 6,
  maxFullSpins = 8
): { targetRotation: number; finalAngleNormalized: number } {
  const segments = computeSegmentAngles(items, mode);
  const targetSegment = segments[targetIndex] || segments[0];

  const span = targetSegment.endAngle - targetSegment.startAngle;
  // Jitter within safe central 40% of the slice span (never touches boundaries!)
  const maxJitter = span * 0.2;
  const jitter = (getCryptoRandomFloat() * 2 - 1) * maxJitter;
  const targetAngleInWheel = targetSegment.centerAngle + jitter;

  // The pointer is at 12 o'clock (0 degrees).
  // Target rotation modulo 360 needed to bring targetAngleInWheel to 0 degrees:
  let targetAngleMod = (360 - (targetAngleInWheel % 360)) % 360;
  if (targetAngleMod < 0) targetAngleMod += 360;

  // Current rotation modulo 360
  const currentAngleMod = ((currentRotation % 360) + 360) % 360;
  let delta = (targetAngleMod - currentAngleMod) % 360;
  if (delta < 0) delta += 360;

  // Add full rotations
  const spins = minFullSpins + getCryptoRandomInt(maxFullSpins - minFullSpins + 1);
  const totalDelta = spins * 360 + delta;

  const targetRotation = currentRotation + totalDelta;
  const finalAngleNormalized = targetAngleMod;

  return { targetRotation, finalAngleNormalized };
}

/**
 * Resolves which item index the pointer (at 12 o'clock / 0°) is pointing to,
 * given the wheel's clockwise rotation in degrees.
 *
 * When wheel rotates clockwise by R degrees:
 * The wheel point under the top pointer (0°) is:
 *   localAngle = (360 - (R mod 360)) mod 360.
 */
export function resolveItemIndexAtRotation(
  rotationDegrees: number,
  items: WheelItem[],
  mode: 'equal' | 'weighted' = 'equal'
): number {
  const segments = computeSegmentAngles(items, mode);
  if (segments.length === 0) return 0;

  const rotMod = ((rotationDegrees % 360) + 360) % 360;
  const wheelAngle = ((360 - rotMod) % 360 + 360) % 360;

  for (const seg of segments) {
    // Check if wheelAngle falls inside [startAngle, endAngle)
    if (wheelAngle >= seg.startAngle && wheelAngle < seg.endAngle) {
      return seg.index;
    }
  }

  // Handle boundary at exactly 360 / 0
  if (wheelAngle === 0 || Math.abs(wheelAngle - 360) < 1e-6) {
    return 0;
  }

  return segments.length - 1;
}
