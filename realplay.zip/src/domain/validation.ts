import { Wheel, WheelItem, WheelExportFormat, FullBackupFormat } from '../types/index';
import { SPORT_PALETTE } from './presets';

export interface ValidationError {
  field: string;
  message: string;
}

/**
 * Validates a single WheelItem
 */
export function validateWheelItem(item: Partial<WheelItem>, index?: number): string | null {
  const prefix = typeof index === 'number' ? `Item #${index + 1}: ` : '';

  if (!item.label || item.label.trim().length === 0) {
    return `${prefix}Nama item wajib diisi.`;
  }

  if (item.label.trim().length > 60) {
    return `${prefix}Nama item maksimal 60 karakter.`;
  }

  if (typeof item.value !== 'undefined') {
    if (isNaN(item.value) || !isFinite(item.value) || item.value < 0) {
      return `${prefix}Nilai numerik harus berupa angka positif yang valid.`;
    }
    if (item.value > 10000) {
      return `${prefix}Nilai numerik melebihi batas wajar (maks 10.000).`;
    }
  }

  if (typeof item.weight !== 'undefined') {
    if (isNaN(item.weight) || !isFinite(item.weight) || item.weight <= 0) {
      return `${prefix}Bobot peluang (weight) harus berupa angka positif lebih dari 0.`;
    }
  }

  return null;
}

/**
 * Validates a complete Wheel before saving
 */
export function validateWheel(wheel: Partial<Wheel>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!wheel.name || wheel.name.trim().length === 0) {
    errors.push({ field: 'name', message: 'Nama roda wajib diisi.' });
  } else if (wheel.name.trim().length > 50) {
    errors.push({ field: 'name', message: 'Nama roda maksimal 50 karakter.' });
  }

  if (!wheel.items || wheel.items.length < 2) {
    errors.push({ field: 'items', message: 'Roda harus memiliki minimal 2 item agar dapat diputar.' });
  } else if (wheel.items.length > 50) {
    errors.push({ field: 'items', message: 'Roda maksimal memiliki 50 item.' });
  } else {
    for (let i = 0; i < wheel.items.length; i++) {
      const itemErr = validateWheelItem(wheel.items[i], i);
      if (itemErr) {
        errors.push({ field: `items[${i}]`, message: itemErr });
      }
    }
  }

  return errors;
}

/**
 * Parses multiline text into WheelItem objects.
 * Supports patterns like:
 * "Push-up x 10"
 * "Plank 30s"
 * "Jalan kaki 500m"
 * "Istirahat 30 detik"
 * "1"
 * "Squat"
 */
export function parseMultilineItems(text: string, startIndex = 0): WheelItem[] {
  const lines = text
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  return lines.map((line, idx) => {
    const id = `item-${Date.now()}-${startIndex + idx}-${Math.random().toString(36).slice(2, 7)}`;
    const color = SPORT_PALETTE[(startIndex + idx) % SPORT_PALETTE.length];

    // Non-workout / recovery detection
    const isRestOrRecovery = /^(istirahat|rest|break|jeda|santai|napas|peregangan ringan)/i.test(line);
    const isNonWorkout = isRestOrRecovery || /^(baca|membaca|minum|meditasi|jurnal|refleksi|tidur)/i.test(line);

    // Pattern 1: Pure number (e.g., "10", "5")
    if (/^\d+$/.test(line)) {
      const val = parseInt(line, 10);
      return {
        id,
        label: `${val} Reps`,
        type: 'number',
        value: val,
        unit: 'reps',
        category: 'general',
        color,
        trackingMode: 'repetition',
        isWorkout: true,
      };
    }

    // Pattern 2: Rest / Istirahat
    if (isRestOrRecovery) {
      const secMatch = line.match(/(\d+)\s*(s|dtk|detik|sec|menit|min|m)?/i);
      let val = 30;
      let unit = 'detik';
      if (secMatch) {
        val = parseInt(secMatch[1], 10);
        if (secMatch[2] && /menit|min/i.test(secMatch[2])) {
          unit = 'menit';
        }
      }
      return {
        id,
        label: line,
        type: 'rest',
        value: val,
        unit,
        category: 'mobility_rest',
        color: '#4B5563',
        trackingMode: 'duration',
        isWorkout: false,
      };
    }

    // Pattern 3: Duration with seconds or minutes (e.g. "Plank 30s", "Jalan 5 menit", "Meditasi 10 menit")
    const durationMatch = line.match(/(.+?)\s*(\d+)\s*(s|dtk|detik|sec|menit|m|min)\b/i);
    if (durationMatch) {
      const unitRaw = durationMatch[3].toLowerCase();
      const isMinutes = unitRaw === 'menit' || unitRaw === 'min' || unitRaw === 'm';
      const unit = isMinutes ? 'menit' : 'detik';
      const val = parseInt(durationMatch[2], 10);
      return {
        id,
        label: line,
        type: 'duration',
        value: val,
        unit,
        category: isNonWorkout ? 'mobility_rest' : 'core',
        color: isNonWorkout ? '#4B5563' : color,
        trackingMode: 'duration',
        isWorkout: !isNonWorkout,
      };
    }

    // Pattern 4: Distance (e.g. "Lari 500m", "Sepeda 2 km")
    const distanceMatch = line.match(/(.+?)\s*(\d+(?:\.\d+)?)\s*(meter|m|km)\b/i);
    if (distanceMatch) {
      const unit = distanceMatch[3].toLowerCase() === 'km' ? 'km' : 'meter';
      const val = parseFloat(distanceMatch[2]);
      return {
        id,
        label: line,
        type: 'distance',
        value: val,
        unit,
        category: 'cardio',
        color,
        trackingMode: 'distance',
        isWorkout: true,
      };
    }

    // Pattern 5: Repetition with multiplier (e.g. "Push-up x 10" or "Squat 15x")
    const repMatch = line.match(/(.+?)\s*(?:[x×]\s*(\d+)|(\d+)\s*(?:[x×]|reps?|kali))/i);
    if (repMatch) {
      const reps = parseInt(repMatch[2] || repMatch[3], 10);
      return {
        id,
        label: line,
        type: 'repetition',
        value: reps,
        unit: 'reps',
        category: 'general',
        color,
        trackingMode: 'repetition',
        isWorkout: true,
      };
    }

    // Pattern 6: Non-workout with quantity (e.g. "Baca 5 halaman", "Minum 1 gelas")
    const quantityMatch = line.match(/(.+?)\s*(\d+)\s*([a-zA-Z]+)/i);
    if (isNonWorkout && quantityMatch) {
      return {
        id,
        label: line,
        type: 'activity',
        value: parseInt(quantityMatch[2], 10),
        unit: quantityMatch[3].toLowerCase(),
        category: 'mobility_rest',
        color: '#4B5563',
        trackingMode: 'completion',
        isWorkout: false,
      };
    }

    // Default: General activity
    return {
      id,
      label: line,
      type: 'activity',
      category: isNonWorkout ? 'mobility_rest' : 'general',
      color: isNonWorkout ? '#4B5563' : color,
      trackingMode: 'completion',
      isWorkout: !isNonWorkout,
    };
  });
}

/**
 * Validates imported JSON wheel configuration
 */
export function validateImportedWheelConfig(data: unknown): {
  valid: boolean;
  wheel?: Omit<Wheel, 'id' | 'source'>;
  error?: string;
} {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'Data JSON tidak valid atau bukan objek.' };
  }

  const exportObj = data as Partial<WheelExportFormat>;
  const rawWheel = exportObj.wheel || (data as Partial<Wheel>);

  if (!rawWheel.name || typeof rawWheel.name !== 'string') {
    return { valid: false, error: 'Format konfigurasi roda tidak memiliki nama valid.' };
  }

  if (!Array.isArray(rawWheel.items) || rawWheel.items.length < 2) {
    return { valid: false, error: 'Roda yang diimpor harus memiliki minimal 2 item.' };
  }

  const cleanItems: WheelItem[] = rawWheel.items.map((it, idx) => ({
    id: it.id && typeof it.id === 'string' ? it.id : `imp-${Date.now()}-${idx}`,
    label: typeof it.label === 'string' ? it.label.trim() : `Item ${idx + 1}`,
    description: it.description,
    type: it.type || 'activity',
    value: typeof it.value === 'number' && !isNaN(it.value) ? it.value : undefined,
    unit: it.unit,
    category: it.category || 'general',
    color: it.color || SPORT_PALETTE[idx % SPORT_PALETTE.length],
    weight: typeof it.weight === 'number' && it.weight > 0 ? it.weight : 1,
    trackingMode: it.trackingMode || 'completion',
    isWorkout: it.isWorkout !== false,
  }));

  const wheel: Omit<Wheel, 'id' | 'source'> = {
    name: rawWheel.name.trim(),
    description: rawWheel.description || '',
    selectionMode: rawWheel.selectionMode === 'weighted' ? 'weighted' : 'equal',
    items: cleanItems,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    schemaVersion: 1,
  };

  return { valid: true, wheel };
}

/**
 * Validates full backup JSON before restore
 */
export function validateFullBackup(data: unknown): {
  valid: boolean;
  backup?: FullBackupFormat;
  error?: string;
} {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'Format file cadangan tidak valid.' };
  }

  const b = data as Partial<FullBackupFormat>;
  if (!b.schemaVersion || typeof b.schemaVersion !== 'number') {
    return { valid: false, error: 'Versi skema backup tidak dikenali.' };
  }

  if (!Array.isArray(b.wheels) || !Array.isArray(b.completions)) {
    return { valid: false, error: 'Struktur data cadangan tidak lengkap.' };
  }

  return { valid: true, backup: b as FullBackupFormat };
}
