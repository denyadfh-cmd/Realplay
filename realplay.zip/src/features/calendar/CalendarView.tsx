import React, { useState } from 'react';
import { CompletionRecord } from '../../types/index';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, CheckCircle2 } from 'lucide-react';

interface CalendarViewProps {
  completions: CompletionRecord[];
  onSelectDate: (dateStr: string) => void;
  selectedDate: string | null;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  completions,
  onSelectDate,
  selectedDate,
}) => {
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth(); // 0-indexed

  // Month navigation
  const prevMonth = () => {
    setCurrentMonth(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentMonth(new Date(year, month + 1, 1));
  };

  // Group completions by local YYYY-MM-DD
  const completionsByDate = new Map<string, CompletionRecord[]>();
  completions.forEach((c) => {
    const d = new Date(c.completedAt);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate()
    ).padStart(2, '0')}`;
    const list = completionsByDate.get(dateStr) || [];
    list.push(c);
    completionsByDate.set(dateStr, list);
  });

  // Calculate days in month
  const firstDayOfWeek = new Date(year, month, 1).getDay(); // 0: Sun, 1: Mon, ...
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Days array
  const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
  const calendarDays: Array<{ dayNumber: number; dateStr: string; isCurrentMonth: boolean }> = [];

  // Previous month padding
  const prevMonthDays = new Date(year, month, 0).getDate();
  for (let i = firstDayOfWeek - 1; i >= 0; i--) {
    const dNum = prevMonthDays - i;
    const prevDate = new Date(year, month - 1, dNum);
    const dateStr = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}-${String(
      prevDate.getDate()
    ).padStart(2, '0')}`;
    calendarDays.push({ dayNumber: dNum, dateStr, isCurrentMonth: false });
  }

  // Current month days
  for (let i = 1; i <= daysInMonth; i++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
    calendarDays.push({ dayNumber: i, dateStr, isCurrentMonth: true });
  }

  const monthLabel = currentMonth.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });

  return (
    <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4 sm:p-5">
      {/* Month Header Navigation */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#242C35]">
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-4 h-4 text-[#C6F36A]" />
          <h3 className="text-sm sm:text-base font-bold text-[#F4F6F8] capitalize">
            {monthLabel}
          </h3>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={prevMonth}
            className="p-1.5 rounded-lg text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
            aria-label="Bulan sebelumnya"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={nextMonth}
            className="p-1.5 rounded-lg text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
            aria-label="Bulan berikutnya"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Day of Week Headers */}
      <div className="grid grid-cols-7 gap-1 text-center mb-1">
        {dayNames.map((name) => (
          <span key={name} className="text-[11px] font-bold text-[#9AA5B1] py-1">
            {name}
          </span>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
        {calendarDays.map((d, idx) => {
          const list = completionsByDate.get(d.dateStr) || [];
          const count = list.length;
          const isSelected = selectedDate === d.dateStr;
          const isToday =
            new Date().toISOString().split('T')[0] === d.dateStr && d.isCurrentMonth;

          return (
            <button
              key={`${d.dateStr}-${idx}`}
              onClick={() => onSelectDate(isSelected ? '' : d.dateStr)}
              className={`min-h-[52px] sm:min-h-[64px] rounded-xl p-1 sm:p-1.5 flex flex-col justify-between items-center transition border ${
                !d.isCurrentMonth
                  ? 'opacity-30 border-transparent bg-[#121518]'
                  : isSelected
                  ? 'border-[#C6F36A] bg-[#C6F36A]/10 text-[#C6F36A]'
                  : count > 0
                  ? 'border-[#2D3844] bg-[#22282E] text-[#F4F6F8] hover:border-[#C6F36A]/50'
                  : 'border-transparent bg-[#14181C] text-[#9AA5B1] hover:bg-[#1A2026]'
              }`}
            >
              <div className="w-full flex items-center justify-between text-[11px] sm:text-xs">
                <span className={`font-semibold ${isToday ? 'text-[#C6F36A] font-black underline' : ''}`}>
                  {d.dayNumber}
                </span>
                {isToday && (
                  <span className="hidden sm:inline text-[9px] uppercase font-bold text-[#C6F36A]">
                    Hari Ini
                  </span>
                )}
              </div>

              {count > 0 && d.isCurrentMonth && (
                <div className="w-full flex items-center justify-center gap-1 mt-1">
                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-[#C6F36A] text-[#101214]">
                    <CheckCircle2 className="w-2.5 h-2.5" />
                    {count}
                  </span>
                </div>
              )}
            </button>
          );
        })}
      </div>

      <div className="flex items-center justify-between text-[11px] text-[#9AA5B1] mt-4 pt-3 border-t border-[#242C35]">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-[#C6F36A]" />
          <span>Hari dengan latihan selesai</span>
        </div>
        <span>Klik tanggal untuk memfilter riwayat</span>
      </div>
    </div>
  );
};
