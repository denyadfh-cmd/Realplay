import React, { useState, useMemo } from 'react';
import { CompletionRecord } from '../../types/index';
import { CalendarView } from '../calendar/CalendarView';
import { db } from '../../services/db';
import {
  Calendar as CalendarIcon,
  Filter,
  Search,
  Undo2,
  Trash2,
  Edit2,
  Clock,
  Flame,
  CheckCircle2,
  X,
  Layers,
  HeartPulse,
} from 'lucide-react';

interface HistoryViewProps {
  completions: CompletionRecord[];
  onRefreshData: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ completions, onRefreshData }) => {
  const [activeSubTab, setActiveSubTab] = useState<'list' | 'calendar'>('list');
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [timeFilter, setTimeFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');

  // Edit / Undo modal states
  const [undoRecordId, setUndoRecordId] = useState<string | null>(null);
  const [editingRecord, setEditingRecord] = useState<CompletionRecord | null>(null);
  const [editActualVal, setEditActualVal] = useState<number>(1);

  // Filter completions
  const filteredCompletions = useMemo(() => {
    return completions.filter((c) => {
      // 1. Calendar selected date filter
      if (selectedDate) {
        const d = new Date(c.completedAt);
        const itemDateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
          d.getDate()
        ).padStart(2, '0')}`;
        if (itemDateStr !== selectedDate) return false;
      }

      // 2. Time filter
      if (timeFilter !== 'all') {
        const now = Date.now();
        const diffMs = now - c.completedAt;
        if (timeFilter === 'today' && diffMs > 24 * 60 * 60 * 1000) return false;
        if (timeFilter === 'week' && diffMs > 7 * 24 * 60 * 60 * 1000) return false;
        if (timeFilter === 'month' && diffMs > 30 * 24 * 60 * 60 * 1000) return false;
      }

      // 3. Category filter
      if (selectedCategory !== 'all' && c.category !== selectedCategory) {
        return false;
      }

      // 4. Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        if (!c.activityNameSnapshot.toLowerCase().includes(q)) return false;
      }

      return true;
    });
  }, [completions, selectedDate, timeFilter, selectedCategory, searchQuery]);

  // Handle undo record
  const handleConfirmUndo = async (id: string) => {
    await db.undoCompletionRecord(id);
    setUndoRecordId(null);
    onRefreshData();
  };

  // Handle edit record value
  const handleSaveEdit = async () => {
    if (!editingRecord) return;
    await db.completions.update(editingRecord.id, {
      actualValue: editActualVal,
    });
    setEditingRecord(null);
    onRefreshData();
  };

  const getCategoryBadge = (cat?: string) => {
    switch (cat) {
      case 'upper_body':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#38BDF8]/10 text-[#38BDF8]">Tubuh Atas</span>;
      case 'lower_body':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#C6F36A]/10 text-[#C6F36A]">Tubuh Bawah</span>;
      case 'core':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#F59E0B]/10 text-[#F59E0B]">Core</span>;
      case 'cardio':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#EC4899]/10 text-[#EC4899]">Kardio</span>;
      case 'mobility_rest':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#2DD4BF]/10 text-[#2DD4BF]">Pemulihan</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#9AA5B1]/10 text-[#9AA5B1]">Umum</span>;
    }
  };

  return (
    <div className="flex-1 max-w-5xl mx-auto w-full px-4 py-6">
      {/* Title & View Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-black text-[#F4F6F8] tracking-tight">Riwayat & Kalender</h2>
          <p className="text-xs text-[#9AA5B1] mt-1">
            Catatan latihan fisik nyata yang telah kamu selesaikan.
          </p>
        </div>

        {/* List / Calendar Switcher */}
        <div className="inline-flex p-1 bg-[#14181C] rounded-xl border border-[#242C35]">
          <button
            onClick={() => setActiveSubTab('list')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              activeSubTab === 'list'
                ? 'bg-[#C6F36A] text-[#101214]'
                : 'text-[#9AA5B1] hover:text-[#F4F6F8]'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            Daftar Catatan
          </button>
          <button
            onClick={() => setActiveSubTab('calendar')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              activeSubTab === 'calendar'
                ? 'bg-[#C6F36A] text-[#101214]'
                : 'text-[#9AA5B1] hover:text-[#F4F6F8]'
            }`}
          >
            <CalendarIcon className="w-3.5 h-3.5" />
            Tampilan Kalender
          </button>
        </div>
      </div>

      {/* Calendar Component if selected */}
      {activeSubTab === 'calendar' && (
        <div className="mb-6">
          <CalendarView
            completions={completions}
            selectedDate={selectedDate}
            onSelectDate={(d) => setSelectedDate(d || null)}
          />
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4 mb-6 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#9AA5B1] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama aktivitas..."
              className="w-full bg-[#121518] border border-[#2D3844] rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-[#F4F6F8] focus:border-[#C6F36A] focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9AA5B1] hover:text-[#F4F6F8]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Time range */}
          <div className="flex items-center gap-1">
            {(['all', 'today', 'week', 'month'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTimeFilter(t)}
                className={`px-2.5 py-2 rounded-xl text-xs font-semibold capitalize border transition ${
                  timeFilter === t
                    ? 'border-[#C6F36A] bg-[#C6F36A]/10 text-[#C6F36A]'
                    : 'border-[#2D3844] bg-[#121518] text-[#9AA5B1] hover:text-[#F4F6F8]'
                }`}
              >
                {t === 'all' ? 'Semua' : t === 'today' ? 'Hari Ini' : t === 'week' ? '7 Hari' : '30 Hari'}
              </button>
            ))}
          </div>

          {/* Category Dropdown */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8] focus:border-[#C6F36A] focus:outline-none"
          >
            <option value="all">Semua Kategori</option>
            <option value="upper_body">Tubuh Atas</option>
            <option value="lower_body">Tubuh Bawah</option>
            <option value="core">Core</option>
            <option value="cardio">Kardio</option>
            <option value="mobility_rest">Pemulihan</option>
            <option value="general">Umum</option>
          </select>
        </div>

        {selectedDate && (
          <div className="flex items-center justify-between text-xs text-[#C6F36A] bg-[#C6F36A]/10 px-3 py-1.5 rounded-lg border border-[#C6F36A]/30">
            <span>Menampilkan data untuk tanggal: <strong>{selectedDate}</strong></span>
            <button
              onClick={() => setSelectedDate(null)}
              className="text-xs hover:underline flex items-center gap-1 text-[#F4F6F8]"
            >
              <X className="w-3.5 h-3.5" /> Hapus Filter Tanggal
            </button>
          </div>
        )}
      </div>

      {/* Completions List */}
      <div className="space-y-2.5">
        {filteredCompletions.length === 0 ? (
          <div className="text-center py-12 px-4 bg-[#191D21] border border-[#242C35] rounded-2xl">
            <CheckCircle2 className="w-10 h-10 text-[#9AA5B1] mx-auto mb-2 opacity-50" />
            <h4 className="text-sm font-bold text-[#F4F6F8]">Tidak Ada Catatan yang Cocok</h4>
            <p className="text-xs text-[#9AA5B1] mt-1 max-w-xs mx-auto">
              Lakukan putaran roda dan tandai tantangan fisik sebagai selesai untuk mencatat riwayat pertamamu.
            </p>
          </div>
        ) : (
          filteredCompletions.map((comp) => {
            const dateObj = new Date(comp.completedAt);
            const dateStr = dateObj.toLocaleDateString('id-ID', {
              day: 'numeric',
              month: 'short',
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={comp.id}
                className="bg-[#191D21] border border-[#242C35] rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-[#374350] transition"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-[#C6F36A]/10 border border-[#C6F36A]/30 flex items-center justify-center text-[#C6F36A] flex-shrink-0 mt-0.5">
                    {comp.isWorkout ? <Flame className="w-4 h-4" /> : <HeartPulse className="w-4 h-4 text-[#2DD4BF]" />}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-bold text-[#F4F6F8] truncate">
                        {comp.activityNameSnapshot}
                      </h4>
                      {getCategoryBadge(comp.category)}
                    </div>

                    <div className="flex items-center gap-3 text-xs text-[#9AA5B1] mt-1 flex-wrap">
                      <span className="text-[#C6F36A] font-bold">
                        Aktual: {comp.actualValue} {comp.unit || ''}
                      </span>
                      {comp.targetValue && comp.targetValue !== comp.actualValue && (
                        <span>(Target: {comp.targetValue})</span>
                      )}
                      <span>•</span>
                      <span>{dateStr}</span>
                      {comp.durationSeconds && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {comp.durationSeconds}s
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Record Action Controls: Edit & Undo */}
                <div className="flex items-center gap-1.5 self-end sm:self-center flex-shrink-0">
                  <button
                    onClick={() => {
                      setEditingRecord(comp);
                      setEditActualVal(comp.actualValue || 1);
                    }}
                    className="p-1.5 rounded-lg bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#2C353D] transition"
                    title="Koreksi nilai latihan"
                    aria-label={`Koreksi ${comp.activityNameSnapshot}`}
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setUndoRecordId(comp.id)}
                    className="p-1.5 rounded-lg bg-[#22282E] text-[#E11D48] hover:bg-[#E11D48]/20 transition"
                    title="Batalkan / Hapus catatan ini"
                    aria-label={`Batalkan catatan ${comp.activityNameSnapshot}`}
                  >
                    <Undo2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Undo Confirmation Modal */}
      {undoRecordId && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div className="w-full max-w-sm bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 text-center shadow-2xl">
            <Undo2 className="w-10 h-10 text-[#E11D48] mx-auto mb-2" />
            <h4 className="text-base font-bold text-[#F4F6F8]">Batalkan Catatan Ini?</h4>
            <p className="text-xs text-[#9AA5B1] mt-1 mb-5">
              Catatan latihan ini akan dihapus dan poin XP yang diperoleh akan disesuaikan kembali secara aman.
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setUndoRecordId(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#22282E] text-[#F4F6F8]"
              >
                Batal
              </button>
              <button
                onClick={() => handleConfirmUndo(undoRecordId)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#E11D48] text-white"
              >
                Ya, Batalkan Catatan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Actual Value Modal */}
      {editingRecord && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div className="w-full max-w-sm bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 text-center shadow-2xl">
            <Edit2 className="w-8 h-8 text-[#C6F36A] mx-auto mb-2" />
            <h4 className="text-base font-bold text-[#F4F6F8]">Koreksi Nilai Aktual</h4>
            <p className="text-xs text-[#9AA5B1] mt-1 mb-4">
              {editingRecord.activityNameSnapshot}
            </p>

            <div className="flex items-center justify-center gap-2 mb-6">
              <button
                onClick={() => setEditActualVal(Math.max(1, editActualVal - 1))}
                className="w-9 h-9 rounded-lg bg-[#22282E] text-[#F4F6F8] font-bold"
              >
                -
              </button>
              <input
                type="number"
                min="1"
                max="5000"
                value={editActualVal}
                onChange={(e) => setEditActualVal(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-20 text-center font-bold bg-[#121518] border border-[#374350] rounded-lg py-1.5 text-base text-[#F4F6F8]"
              />
              <button
                onClick={() => setEditActualVal(editActualVal + 1)}
                className="w-9 h-9 rounded-lg bg-[#22282E] text-[#F4F6F8] font-bold"
              >
                +
              </button>
            </div>

            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setEditingRecord(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#22282E] text-[#F4F6F8]"
              >
                Batal
              </button>
              <button
                onClick={handleSaveEdit}
                className="px-4 py-2 rounded-xl text-xs font-extrabold bg-[#C6F36A] text-[#101214]"
              >
                Simpan Perubahan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
