import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Wheel, WheelItem, Challenge, WorkoutSession, CompletionRecord } from '../../types/index';
import { SpinWheel } from '../../components/wheel/SpinWheel';
import { ChallengeResultCard } from '../../components/wheel/ChallengeResultCard';
import { WorkoutTimerModal } from '../../components/timer/WorkoutTimerModal';
import { selectWinningItem } from '../../domain/random';
import { db } from '../../services/db';
import {
  Play,
  RotateCw,
  Edit2,
  ChevronDown,
  Layers,
  Flame,
  CheckCircle2,
  ListOrdered,
  Plus,
  AlertTriangle,
  HeartPulse,
} from 'lucide-react';

interface PlayViewProps {
  wheels: Wheel[];
  activeWheelId: string | null;
  onSelectWheel: (wheelId: string) => void;
  onEditWheel: (wheel: Wheel) => void;
  onCreateWheel: () => void;
  onViewQueue: () => void;
  activeSession: WorkoutSession | null;
  sessionCompletions: CompletionRecord[];
  queue: Challenge[];
  onRefreshData: () => void;
  reducedMotion?: boolean;
}

interface ActiveSpinTransaction {
  spinId: string;
  wheelId: string;
  item: WheelItem;
  targetIndex: number;
}

export const PlayView: React.FC<PlayViewProps> = ({
  wheels,
  activeWheelId,
  onSelectWheel,
  onEditWheel,
  onCreateWheel,
  onViewQueue,
  activeSession,
  sessionCompletions,
  queue,
  onRefreshData,
  reducedMotion = false,
}) => {
  const [activeWheel, setActiveWheel] = useState<Wheel | null>(null);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [currentSpin, setCurrentSpin] = useState<ActiveSpinTransaction | null>(null);
  const [showResultCard, setShowResultCard] = useState<boolean>(false);
  const [showWheelDropdown, setShowWheelDropdown] = useState<boolean>(false);

  // Active workout timer modal
  const [timerModalConfig, setTimerModalConfig] = useState<{
    open: boolean;
    durationSec: number;
    activityLabel: string;
    onApply?: (sec: number) => void;
  }>({ open: false, durationSec: 30, activityLabel: '' });

  // Update active wheel when list or id changes
  useEffect(() => {
    if (wheels.length === 0) {
      setActiveWheel(null);
      return;
    }
    const found = wheels.find((w) => w.id === activeWheelId) || wheels[0];
    setActiveWheel(found);
    if (found && found.id !== activeWheelId) {
      onSelectWheel(found.id);
    }
  }, [wheels, activeWheelId, onSelectWheel]);

  // Handle spin button click
  const handleStartSpin = useCallback(() => {
    // Prevent double spin or spin without items
    if (isSpinning || !activeWheel || activeWheel.items.length < 2) return;

    // 1. Determine winner strictly BEFORE animation starts (P0-01 & P0-03)
    const selection = selectWinningItem(activeWheel.items, activeWheel.selectionMode);
    if (!selection) return;

    const newSpinTransaction: ActiveSpinTransaction = {
      spinId: `spin-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      wheelId: activeWheel.id,
      item: selection.item,
      targetIndex: selection.index,
    };

    setCurrentSpin(newSpinTransaction);
    setIsSpinning(true);
    setShowResultCard(false);

    // P0-02 FIX: DO NOT call db.checkAchievementsAfterSpin() or onRefreshData() here!
    // Refreshing data mid-spin would reconstruct the wheels array and restart the animation.
  }, [isSpinning, activeWheel]);

  // Called when wheel animation physically finishes (P0-02 & P0-03)
  const handleSpinAnimationFinish = useCallback(() => {
    setIsSpinning(false);
    setShowResultCard(true);

    // Only now, when the wheel has completely stopped, evaluate the spin achievement safely
    db.checkAchievementsAfterSpin().then(() => {
      onRefreshData();
    });
  }, [onRefreshData]);

  // Action: User completes the challenge immediately
  const handleCompleteCurrentChallenge = async (actualVal: number, durationSec?: number) => {
    if (!currentSpin?.item) return;
    const itemSnapshot = currentSpin.item;

    // Ensure we have an active session
    let currentSession = activeSession;
    if (!currentSession) {
      currentSession = await db.startNewSession();
    }

    const challengeId = `ch-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const newChallenge: Challenge = {
      id: challengeId,
      sessionId: currentSession.id,
      wheelId: activeWheel?.id,
      wheelItemId: itemSnapshot.id,
      labelSnapshot: itemSnapshot.label,
      type: itemSnapshot.type,
      category: itemSnapshot.category,
      targetValue: itemSnapshot.value,
      actualValue: actualVal,
      unit: itemSnapshot.unit,
      status: 'completed',
      createdAt: Date.now(),
      completedAt: Date.now(),
      durationSeconds: durationSec,
      isWorkout: itemSnapshot.isWorkout,
    };

    await db.addChallenge(newChallenge);
    await db.recordChallengeCompletion({
      challengeId,
      sessionId: currentSession.id,
      activityNameSnapshot: itemSnapshot.label,
      category: itemSnapshot.category,
      targetValue: itemSnapshot.value,
      actualValue: actualVal,
      unit: itemSnapshot.unit,
      durationSeconds: durationSec,
      isWorkout: itemSnapshot.isWorkout,
      source: 'spin',
    });

    setShowResultCard(false);
    onRefreshData();
  };

  // Action: Add challenge to queue
  const handleAddToQueue = async (actualVal: number) => {
    if (!currentSpin?.item) return;
    const itemSnapshot = currentSpin.item;

    let currentSession = activeSession;
    if (!currentSession) {
      currentSession = await db.startNewSession();
    }

    const challengeId = `ch-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const newChallenge: Challenge = {
      id: challengeId,
      sessionId: currentSession.id,
      wheelId: activeWheel?.id,
      wheelItemId: itemSnapshot.id,
      labelSnapshot: itemSnapshot.label,
      type: itemSnapshot.type,
      category: itemSnapshot.category,
      targetValue: actualVal || itemSnapshot.value,
      unit: itemSnapshot.unit,
      status: 'queued',
      createdAt: Date.now(),
      isWorkout: itemSnapshot.isWorkout,
    };

    await db.addChallenge(newChallenge);
    setShowResultCard(false);
    onRefreshData();
  };

  // Action: Open timer with clean unit normalization (P1-02 Fix)
  const handleStartTimer = (actualVal: number) => {
    if (!currentSpin?.item) return;
    const itemSnapshot = currentSpin.item;

    // Normalize duration: if item is 'menit', convert to seconds for timer
    const isMinutes = itemSnapshot.unit === 'menit' || itemSnapshot.unit === 'min';
    const durSec = isMinutes ? Math.round(actualVal * 60) : Math.round(actualVal);

    setTimerModalConfig({
      open: true,
      durationSec: Math.max(5, durSec),
      activityLabel: itemSnapshot.label,
      onApply: (appliedSec) => {
        // P1-02 FIX: Convert applied seconds back to the item's target unit consistently!
        let finalActualVal = appliedSec;
        if (isMinutes) {
          finalActualVal = Number((appliedSec / 60).toFixed(1));
        }
        handleCompleteCurrentChallenge(finalActualVal, appliedSec);
      },
    });
  };

  if (!activeWheel) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto">
        <div className="w-16 h-16 rounded-2xl bg-[#191D21] border border-[#2D3844] flex items-center justify-center text-[#C6F36A] mb-4">
          <Layers className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-[#F4F6F8]">Belum Ada Roda Aktif</h2>
        <p className="text-sm text-[#9AA5B1] mt-2 mb-6">
          Pilih salah satu preset olahraga atau buat roda tantangan latihan pertamamu sekarang.
        </p>
        <button
          onClick={onCreateWheel}
          className="px-6 py-3 bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-[#C6F36A]/20 transition"
        >
          <Plus className="w-5 h-5" />
          Buat Roda Pertama
        </button>
      </div>
    );
  }

  const items = activeWheel.items || [];

  return (
    <div className="flex-1 flex flex-col items-center max-w-4xl mx-auto w-full px-3 sm:px-4 py-2 sm:py-6">
      {/* Active Wheel Selector Bar */}
      <div className="w-full flex items-center justify-between gap-3 mb-2 sm:mb-4 max-w-md">
        <div className="relative flex-1">
          <button
            type="button"
            disabled={isSpinning}
            onClick={() => setShowWheelDropdown(!showWheelDropdown)}
            className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-[#191D21] hover:bg-[#22282E] border border-[#2D3844] text-left transition disabled:opacity-50"
            aria-expanded={showWheelDropdown}
            aria-haspopup="listbox"
          >
            <div className="min-w-0 pr-2">
              <span className="text-[10px] text-[#9AA5B1] block uppercase tracking-wider font-semibold">
                Roda Aktif • {activeWheel.items.length} item
              </span>
              <span className="text-sm font-bold text-[#F4F6F8] truncate block">
                {activeWheel.name}
              </span>
            </div>
            <ChevronDown className="w-4 h-4 text-[#9AA5B1] flex-shrink-0" />
          </button>

          {/* Dropdown Menu */}
          {showWheelDropdown && (
            <div className="absolute top-full left-0 right-0 mt-1.5 z-40 bg-[#191D21] border border-[#2D3844] rounded-xl shadow-2xl py-1.5 max-h-60 overflow-y-auto">
              {wheels.map((w) => (
                <button
                  key={w.id}
                  onClick={() => {
                    onSelectWheel(w.id);
                    setShowWheelDropdown(false);
                  }}
                  className={`w-full text-left px-3.5 py-2.5 text-xs flex items-center justify-between hover:bg-[#22282E] transition ${
                    w.id === activeWheel.id ? 'text-[#C6F36A] font-bold bg-[#22282E]/60' : 'text-[#F4F6F8]'
                  }`}
                >
                  <span className="truncate">{w.name}</span>
                  <span className="text-[10px] text-[#9AA5B1] ml-2">
                    {w.items.length} item
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Edit Wheel Button */}
        <button
          type="button"
          disabled={isSpinning}
          onClick={() => onEditWheel(activeWheel)}
          className="p-2.5 rounded-xl bg-[#191D21] hover:bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8] border border-[#2D3844] transition flex items-center gap-1.5 disabled:opacity-50"
          title="Edit Roda Ini"
          aria-label="Edit Roda Ini"
        >
          <Edit2 className="w-4 h-4" />
          <span className="hidden sm:inline text-xs font-semibold">Edit</span>
        </button>
      </div>

      {/* Interactive Spin Wheel Component */}
      <div className="relative my-1 sm:my-3 flex flex-col items-center">
        {items.length < 2 ? (
          <div className="p-8 text-center bg-[#191D21] border border-[#2D3844] rounded-2xl max-w-sm">
            <AlertTriangle className="w-8 h-8 text-[#F59E0B] mx-auto mb-2" />
            <p className="text-sm font-semibold text-[#F4F6F8]">Roda membutuhkan minimal 2 item</p>
            <button
              onClick={() => onEditWheel(activeWheel)}
              className="mt-3 px-4 py-2 bg-[#C6F36A] text-[#101214] font-bold text-xs rounded-lg"
            >
              Tambah Item Sekarang
            </button>
          </div>
        ) : (
          <SpinWheel
            items={items}
            selectionMode={activeWheel.selectionMode}
            isSpinning={isSpinning}
            spinId={currentSpin?.spinId}
            targetIndex={currentSpin?.targetIndex ?? null}
            onSpinFinish={handleSpinAnimationFinish}
            reducedMotion={reducedMotion}
          />
        )}
      </div>

      {/* Main Action Button "PUTAR RODA" */}
      <div className="w-full max-w-sm my-2 sm:my-4 flex flex-col items-center">
        <button
          type="button"
          disabled={isSpinning || items.length < 2}
          onClick={handleStartSpin}
          className={`w-full py-3.5 sm:py-4 px-6 rounded-2xl font-black text-sm sm:text-base md:text-lg tracking-wider flex items-center justify-center gap-2.5 transition-all shadow-xl cursor-pointer ${
            isSpinning
              ? 'bg-[#22282E] text-[#9AA5B1] cursor-not-allowed opacity-80'
              : 'bg-[#C6F36A] hover:bg-[#B8EB54] active:scale-95 text-[#101214] shadow-[#C6F36A]/25 glow-lime'
          }`}
          aria-label="Putar Roda Keberuntungan REALPLAY"
        >
          {isSpinning ? (
            <>
              <RotateCw className="w-5 h-5 animate-spin text-[#9AA5B1]" />
              <span>RODA SEDANG BERPUTAR...</span>
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-current" />
              <span>PUTAR RODA SEKARANG</span>
            </>
          )}
        </button>

        {/* User-friendly one-line guide (P1-06) */}
        <p className="text-xs text-[#9AA5B1] mt-2.5 text-center font-medium">
          Putar roda, lakukan tantangan fisik di dunia nyata, lalu catat hasilnya.
        </p>
      </div>

      {/* Session Quick Metrics Pill */}
      <div className="w-full max-w-md bg-[#191D21] border border-[#242C35] rounded-2xl p-3.5 flex items-center justify-around text-center mt-2">
        <div>
          <span className="text-[10px] uppercase font-bold text-[#9AA5B1] block">
            Selesai Sesi Ini
          </span>
          <span className="text-lg font-black text-[#C6F36A]">
            {sessionCompletions.length}
          </span>
        </div>

        <div className="w-px h-8 bg-[#242C35]" />

        <div>
          <span className="text-[10px] uppercase font-bold text-[#9AA5B1] block">
            Antrean Aktif
          </span>
          <button
            disabled={isSpinning}
            onClick={onViewQueue}
            className="text-lg font-black text-[#0EA5E9] hover:underline inline-flex items-center gap-1 disabled:opacity-50"
          >
            {queue.length}
          </button>
        </div>

        <div className="w-px h-8 bg-[#242C35]" />

        <div>
          <span className="text-[10px] uppercase font-bold text-[#9AA5B1] block">
            Mode Peluang
          </span>
          <span className="text-xs font-bold text-[#F4F6F8]">
            {activeWheel.selectionMode === 'weighted' ? 'Bobot' : 'Sama Rata'}
          </span>
        </div>
      </div>

      {/* Challenge Result Modal when spin finishes (P0-03 & P1-01) */}
      {showResultCard && currentSpin?.item && (
        <ChallengeResultCard
          item={currentSpin.item}
          onStart={handleStartTimer}
          onComplete={handleCompleteCurrentChallenge}
          onAddToQueue={handleAddToQueue}
          onSkip={() => setShowResultCard(false)}
          onClose={() => setShowResultCard(false)}
        />
      )}

      {/* Workout Timer Modal (P1-02) */}
      {timerModalConfig.open && (
        <WorkoutTimerModal
          initialDurationSec={timerModalConfig.durationSec}
          activityLabel={timerModalConfig.activityLabel}
          onApplyTime={timerModalConfig.onApply}
          onClose={() => setTimerModalConfig({ ...timerModalConfig, open: false })}
        />
      )}
    </div>
  );
};
