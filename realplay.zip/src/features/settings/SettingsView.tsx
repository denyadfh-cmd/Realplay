import React, { useState, useRef } from 'react';
import { UserSettings } from '../../types/index';
import { db } from '../../services/db';
import { exportFullBackup, restoreFullBackup } from '../../services/backup';
import { soundService } from '../../services/audio';
import {
  Settings,
  Shield,
  Volume2,
  Smartphone,
  Eye,
  Download,
  Upload,
  Trash2,
  Check,
  AlertTriangle,
  Info,
} from 'lucide-react';

interface SettingsViewProps {
  settings: UserSettings;
  onRefreshData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ settings, onRefreshData }) => {
  const [currentSettings, setCurrentSettings] = useState<UserSettings>(settings);
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleUpdate = async (updates: Partial<UserSettings>) => {
    const updated = await db.updateUserSettings(updates);
    setCurrentSettings(updated);
    soundService.setPreferences(updated.soundEnabled, updated.vibrationEnabled);
    onRefreshData();
    showToast('Pengaturan disimpan.');
  };

  // Full backup restore handler
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      const content = evt.target?.result as string;
      const res = await restoreFullBackup(content);
      showToast(res.message);
      if (res.success) {
        onRefreshData();
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleClearAll = async () => {
    await db.clearAllData();
    setShowClearConfirm(false);
    onRefreshData();
    showToast('Seluruh data lokal berhasil dibersihkan.');
  };

  return (
    <div className="flex-1 max-w-4xl mx-auto w-full px-4 py-6">
      {toastMessage && (
        <div className="fixed top-16 right-4 z-50 bg-[#C6F36A] text-[#101214] font-bold text-xs py-2 px-4 rounded-xl shadow-xl animate-in slide-in-from-top duration-200">
          {toastMessage}
        </div>
      )}

      <div className="mb-6">
        <h2 className="text-2xl font-black text-[#F4F6F8] tracking-tight">Pengaturan & Batas Aman</h2>
        <p className="text-xs text-[#9AA5B1] mt-1">
          Sesuaikan batas beban fisik, umpan balik audio, dan pencadangan data lokal.
        </p>
      </div>

      <div className="space-y-6">
        {/* Section 1: Keselamatan & Batas Latihan */}
        <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-[#C6F36A]" />
            <h3 className="text-sm font-bold text-[#F4F6F8]">Batas Latihan & Keselamatan</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-[#9AA5B1] block mb-1">
                Tingkat Kemampuan
              </label>
              <select
                value={currentSettings.difficultyLevel}
                onChange={(e) =>
                  handleUpdate({
                    difficultyLevel: e.target.value as UserSettings['difficultyLevel'],
                  })
                }
                className="w-full bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8]"
              >
                <option value="beginner">Pemula (Konservatif & Aman)</option>
                <option value="intermediate">Menengah (Standar)</option>
                <option value="advanced">Lanjutan (Volume Tinggi)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-[#9AA5B1] block mb-1">
                Batas Repetisi Maksimal per Putaran
              </label>
              <input
                type="number"
                min="1"
                max="500"
                value={currentSettings.maxRepsLimit}
                onChange={(e) =>
                  handleUpdate({ maxRepsLimit: Math.max(1, parseInt(e.target.value, 10) || 50) })
                }
                className="w-full bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8]"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-[#9AA5B1] block mb-1">
                Batas Durasi Maksimal (Detik)
              </label>
              <input
                type="number"
                min="5"
                max="3600"
                value={currentSettings.maxDurationSecondsLimit}
                onChange={(e) =>
                  handleUpdate({
                    maxDurationSecondsLimit: Math.max(5, parseInt(e.target.value, 10) || 120),
                  })
                }
                className="w-full bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8]"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-[#9AA5B1] block mb-1">
                Batas Jarak Maksimal (Meter)
              </label>
              <input
                type="number"
                min="50"
                max="50000"
                value={currentSettings.maxDistanceMetersLimit}
                onChange={(e) =>
                  handleUpdate({
                    maxDistanceMetersLimit: Math.max(50, parseInt(e.target.value, 10) || 1000),
                  })
                }
                className="w-full bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8]"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Audio & Tampilan */}
        <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Volume2 className="w-5 h-5 text-[#2DD4BF]" />
            <h3 className="text-sm font-bold text-[#F4F6F8]">Audio & Aksesibilitas</h3>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded-xl bg-[#121518] border border-[#242C35] cursor-pointer">
              <div className="flex items-center gap-3">
                <Volume2 className="w-4 h-4 text-[#C6F36A]" />
                <div>
                  <span className="text-xs font-bold text-[#F4F6F8] block">Efek Suara Sintetis</span>
                  <span className="text-[11px] text-[#9AA5B1]">
                    Bunyi detak putaran roda, bel kemenangan, dan timer offline.
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={currentSettings.soundEnabled}
                onChange={(e) => handleUpdate({ soundEnabled: e.target.checked })}
                className="w-4 h-4 accent-[#C6F36A]"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-[#121518] border border-[#242C35] cursor-pointer">
              <div className="flex items-center gap-3">
                <Smartphone className="w-4 h-4 text-[#0EA5E9]" />
                <div>
                  <span className="text-xs font-bold text-[#F4F6F8] block">Getaran Haptic (HP)</span>
                  <span className="text-[11px] text-[#9AA5B1]">
                    Umpan balik sentuhan saat roda berputar pada perangkat mobile yang mendukung.
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={currentSettings.vibrationEnabled}
                onChange={(e) => handleUpdate({ vibrationEnabled: e.target.checked })}
                className="w-4 h-4 accent-[#C6F36A]"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-[#121518] border border-[#242C35] cursor-pointer">
              <div className="flex items-center gap-3">
                <Eye className="w-4 h-4 text-[#F59E0B]" />
                <div>
                  <span className="text-xs font-bold text-[#F4F6F8] block">Kurangi Animasi (Reduced Motion)</span>
                  <span className="text-[11px] text-[#9AA5B1]">
                    Putaran roda lebih singkat dan transisi lebih tenang bagi pengguna sensitif gerak.
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={currentSettings.reducedMotion}
                onChange={(e) => handleUpdate({ reducedMotion: e.target.checked })}
                className="w-4 h-4 accent-[#C6F36A]"
              />
            </label>
          </div>
        </div>

        {/* Section 3: Cadangan Data & Pemulihan (JSON) */}
        <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <Download className="w-5 h-5 text-[#0EA5E9]" />
            <h3 className="text-sm font-bold text-[#F4F6F8]">Cadangan & Pemulihan Data</h3>
          </div>
          <p className="text-xs text-[#9AA5B1] mb-4">
            REALPLAY sepenuhnya berjalan secara offline dan menyimpan data di IndexedDB browsermu tanpa akun. Unduh cadangan berkala agar data tidak hilang saat membersihkan riwayat browser.
          </p>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleRestoreFile}
            accept=".json,application/json"
            className="hidden"
          />

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={exportFullBackup}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#22282E] hover:bg-[#2C353D] text-[#C6F36A] font-bold text-xs rounded-xl border border-[#2D3844] transition"
            >
              <Download className="w-4 h-4" />
              Unduh Cadangan Lengkap (JSON)
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#22282E] hover:bg-[#2C353D] text-[#0EA5E9] font-bold text-xs rounded-xl border border-[#2D3844] transition"
            >
              <Upload className="w-4 h-4" />
              Pulihkan dari File JSON
            </button>
          </div>
        </div>

        {/* Section 4: Zona Bahaya / Reset Data */}
        <div className="bg-[#191D21] border border-[#E11D48]/30 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-5 h-5 text-[#E11D48]" />
            <h3 className="text-sm font-bold text-[#E11D48]">Zona Hapus Data</h3>
          </div>
          <p className="text-xs text-[#9AA5B1] mb-4">
            Menghapus seluruh riwayat latihan, pencapaian, dan roda custom di browser ini. Preset bawaan akan dikembalikan ke kondisi awal.
          </p>

          <button
            onClick={() => setShowClearConfirm(true)}
            className="px-4 py-2 bg-[#E11D48]/10 hover:bg-[#E11D48]/20 text-[#E11D48] border border-[#E11D48]/40 font-bold text-xs rounded-xl transition flex items-center gap-2"
          >
            <Trash2 className="w-4 h-4" />
            Hapus Semua Data Lokal
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showClearConfirm && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
        >
          <div className="w-full max-w-sm bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 text-center shadow-2xl">
            <AlertTriangle className="w-12 h-12 text-[#E11D48] mx-auto mb-3" />
            <h4 className="text-lg font-black text-[#F4F6F8]">Konfirmasi Hapus Semua?</h4>
            <p className="text-xs text-[#9AA5B1] mt-2 mb-6 leading-relaxed">
              Tindakan ini tidak dapat dibatalkan. Pastikan kamu sudah mengunduh file cadangan jika masih membutuhkan riwayat latihanmu.
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#22282E] text-[#F4F6F8]"
              >
                Batal
              </button>
              <button
                onClick={handleClearAll}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#E11D48] text-white"
              >
                Ya, Hapus Semua
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
