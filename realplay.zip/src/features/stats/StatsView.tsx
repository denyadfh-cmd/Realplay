import React, { useState } from 'react';
import { CompletionRecord, UserGoal, Achievement, UserSettings } from '../../types/index';
import { calculateLevelFromXP } from '../../domain/gamification';
import { db } from '../../services/db';
import {
  Trophy,
  Flame,
  Clock,
  Target,
  Award,
  Calendar,
  TrendingUp,
  Plus,
  CheckCircle2,
  Lock,
  ChevronRight,
  Disc,
  Compass,
  Wrench,
  Shield,
  HeartPulse,
} from 'lucide-react';

interface StatsViewProps {
  completions: CompletionRecord[];
  goals: UserGoal[];
  achievements: Achievement[];
  settings: UserSettings;
  onRefreshData: () => void;
}

export const StatsView: React.FC<StatsViewProps> = ({
  completions,
  goals,
  achievements,
  settings,
  onRefreshData,
}) => {
  const [activeTab, setActiveTab] = useState<'metrics' | 'goals' | 'achievements'>('metrics');
  const [showGoalModal, setShowGoalModal] = useState<boolean>(false);
  const [newGoalTitle, setNewGoalTitle] = useState<string>('');
  const [newGoalTarget, setNewGoalTarget] = useState<number>(3);
  const [newGoalType, setNewGoalType] = useState<UserGoal['type']>('sessions_per_week');

  const { level, currentLevelXP, nextLevelXP, progressPercent } = calculateLevelFromXP(
    settings.userXp || 0
  );

  // Group stats strictly by unit
  const workoutCompletions = completions.filter((c) => c.isWorkout);
  const totalCompletionsCount = workoutCompletions.length;

  // Reps by activity map
  const repsByActivity: Record<string, number> = {};
  let totalDurationSeconds = 0;
  let totalMeters = 0;
  const activityFrequency: Record<string, number> = {};
  const activeDaysSet = new Set<string>();

  const now = Date.now();
  const oneWeekMs = 7 * 24 * 60 * 60 * 1000;
  let completionsThisWeek = 0;
  let completionsLastWeek = 0;

  for (const c of completions) {
    const dayStr = new Date(c.completedAt).toISOString().split('T')[0];
    activeDaysSet.add(dayStr);

    if (now - c.completedAt <= oneWeekMs) {
      completionsThisWeek++;
    } else if (now - c.completedAt <= 2 * oneWeekMs) {
      completionsLastWeek++;
    }

    if (c.isWorkout) {
      activityFrequency[c.activityNameSnapshot] = (activityFrequency[c.activityNameSnapshot] || 0) + 1;

      if (c.unit === 'reps' || c.unit === 'kali') {
        const key = c.activityNameSnapshot;
        repsByActivity[key] = (repsByActivity[key] || 0) + (c.actualValue || 0);
      } else if (c.unit === 'detik' || c.unit === 'menit') {
        const sec = c.unit === 'menit' ? (c.actualValue || 0) * 60 : (c.actualValue || 0);
        totalDurationSeconds += sec;
      } else if (c.unit === 'meter' || c.unit === 'km') {
        const m = c.unit === 'km' ? (c.actualValue || 0) * 1000 : (c.actualValue || 0);
        totalMeters += m;
      }
    }
  }

  // Top activity
  let topActivityName = '—';
  let topActivityCount = 0;
  for (const [name, count] of Object.entries(activityFrequency)) {
    if (count > topActivityCount) {
      topActivityName = name;
      topActivityCount = count;
    }
  }

  // Create Goal
  const handleSaveGoal = async () => {
    if (!newGoalTitle.trim()) return;
    const goal: UserGoal = {
      id: `goal-${Date.now()}`,
      title: newGoalTitle.trim(),
      type: newGoalType,
      target: newGoalTarget,
      current: 0,
      unit: newGoalType === 'sessions_per_week' ? 'sesi' : 'reps',
      enabled: true,
      period: 'weekly',
      createdAt: Date.now(),
    };
    await db.goals.add(goal);
    setShowGoalModal(false);
    setNewGoalTitle('');
    onRefreshData();
  };

  const getAchievementIcon = (iconName: string) => {
    switch (iconName) {
      case 'Disc': return <Disc className="w-5 h-5" />;
      case 'Flame': return <Flame className="w-5 h-5" />;
      case 'CalendarCheck': return <Calendar className="w-5 h-5" />;
      case 'Wrench': return <Wrench className="w-5 h-5" />;
      case 'Compass': return <Compass className="w-5 h-5" />;
      case 'Award': return <Award className="w-5 h-5" />;
      case 'Shield': return <Shield className="w-5 h-5" />;
      case 'HeartPulse': return <HeartPulse className="w-5 h-5" />;
      default: return <Trophy className="w-5 h-5" />;
    }
  };

  return (
    <div className="flex-1 max-w-5xl mx-auto w-full px-4 py-6">
      {/* Title & Level Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-black text-[#F4F6F8] tracking-tight">Statistik & Pencapaian</h2>
          <p className="text-xs text-[#9AA5B1] mt-1">
            Pantau konsistensi dan perkembangan olahraga harianmu.
          </p>
        </div>

        {/* Level Badge Card */}
        <div className="flex items-center gap-3 bg-[#191D21] border border-[#2D3844] rounded-2xl p-3 px-4 shadow-md">
          <div className="w-10 h-10 rounded-xl bg-[#C6F36A] text-[#101214] font-black text-base flex items-center justify-center shadow-lg shadow-[#C6F36A]/20">
            {level}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#F4F6F8]">Level Kebugaran {level}</span>
              <span className="text-xs text-[#C6F36A] font-bold">
                {settings.userXp || 0} XP
              </span>
            </div>
            <div className="w-36 h-1.5 bg-[#121518] rounded-full overflow-hidden mt-1.5">
              <div
                className="h-full bg-gradient-to-r from-[#C6F36A] to-[#2DD4BF] rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="text-[10px] text-[#9AA5B1] mt-0.5 block">
              {currentLevelXP} / {nextLevelXP} XP menuju Lv.{level + 1}
            </span>
          </div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-[#242C35] mb-6">
        <button
          onClick={() => setActiveTab('metrics')}
          className={`py-3 px-4 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
            activeTab === 'metrics'
              ? 'border-[#C6F36A] text-[#C6F36A]'
              : 'border-transparent text-[#9AA5B1] hover:text-[#F4F6F8]'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          Metrik Latihan
        </button>
        <button
          onClick={() => setActiveTab('goals')}
          className={`py-3 px-4 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
            activeTab === 'goals'
              ? 'border-[#C6F36A] text-[#C6F36A]'
              : 'border-transparent text-[#9AA5B1] hover:text-[#F4F6F8]'
          }`}
        >
          <Target className="w-4 h-4" />
          Target Saya ({goals.length})
        </button>
        <button
          onClick={() => setActiveTab('achievements')}
          className={`py-3 px-4 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
            activeTab === 'achievements'
              ? 'border-[#C6F36A] text-[#C6F36A]'
              : 'border-transparent text-[#9AA5B1] hover:text-[#F4F6F8]'
          }`}
        >
          <Trophy className="w-4 h-4" />
          Lencana & Badges ({achievements.filter((a) => a.unlockedAt).length}/{achievements.length})
        </button>
      </div>

      {/* Tab: METRICS */}
      {activeTab === 'metrics' && (
        <div className="space-y-6">
          {/* Key Numbers Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4">
              <span className="text-[10px] font-bold text-[#9AA5B1] uppercase block">
                Total Selesai
              </span>
              <p className="text-2xl sm:text-3xl font-black text-[#F4F6F8] mt-1">
                {totalCompletionsCount}
              </p>
              <span className="text-[11px] text-[#C6F36A] font-semibold mt-1 block">
                Latihan fisik
              </span>
            </div>

            <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4">
              <span className="text-[10px] font-bold text-[#9AA5B1] uppercase block">
                Hari Aktif
              </span>
              <p className="text-2xl sm:text-3xl font-black text-[#F4F6F8] mt-1">
                {activeDaysSet.size}
              </p>
              <span className="text-[11px] text-[#0EA5E9] font-semibold mt-1 block">
                Hari konsisten
              </span>
            </div>

            <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4">
              <span className="text-[10px] font-bold text-[#9AA5B1] uppercase block">
                Total Durasi
              </span>
              <p className="text-2xl sm:text-3xl font-black text-[#F4F6F8] mt-1">
                {Math.floor(totalDurationSeconds / 60)}m {totalDurationSeconds % 60}s
              </p>
              <span className="text-[11px] text-[#F59E0B] font-semibold mt-1 block">
                Waktu bergerak
              </span>
            </div>

            <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4">
              <span className="text-[10px] font-bold text-[#9AA5B1] uppercase block">
                Minggu Ini
              </span>
              <p className="text-2xl sm:text-3xl font-black text-[#F4F6F8] mt-1">
                {completionsThisWeek}
              </p>
              <span className="text-[11px] text-[#9AA5B1] font-semibold mt-1 block">
                vs {completionsLastWeek} minggu lalu
              </span>
            </div>
          </div>

          {/* Reps Breakdown Per Activity */}
          <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-5">
            <h3 className="text-sm font-bold text-[#F4F6F8] mb-1">
              Akumulasi Repetisi Berdasarkan Aktivitas
            </h3>
            <p className="text-xs text-[#9AA5B1] mb-4">
              Dihitung murni berdasarkan repetisi yang diselesaikan (tidak dicampur dengan durasi detik).
            </p>

            {Object.keys(repsByActivity).length === 0 ? (
              <p className="text-xs text-[#9AA5B1] py-4 text-center">
                Belum ada latihan repetisi yang diselesaikan.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {Object.entries(repsByActivity).map(([actName, reps]) => (
                  <div
                    key={actName}
                    className="bg-[#121518] border border-[#242C35] rounded-xl p-3 flex items-center justify-between"
                  >
                    <span className="text-xs font-semibold text-[#F4F6F8] truncate pr-2">
                      {actName}
                    </span>
                    <span className="text-sm font-black text-[#C6F36A] flex-shrink-0">
                      {reps} reps
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Favorit Activity Banner */}
          <div className="bg-[#191D21] border border-[#242C35] rounded-2xl p-5 flex items-center justify-between">
            <div>
              <span className="text-xs text-[#9AA5B1] font-semibold uppercase tracking-wider block">
                Aktivitas Paling Sering Diselesaikan
              </span>
              <p className="text-lg font-black text-[#F4F6F8] mt-1">
                {topActivityName}
              </p>
            </div>
            {topActivityCount > 0 && (
              <span className="px-3 py-1 bg-[#C6F36A]/10 text-[#C6F36A] border border-[#C6F36A]/30 font-bold text-xs rounded-xl">
                {topActivityCount} kali selesai
              </span>
            )}
          </div>
        </div>
      )}

      {/* Tab: GOALS */}
      {activeTab === 'goals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-[#9AA5B1]">
              Tetapkan target mingguan yang sehat dan realistis untuk dirimu.
            </p>
            <button
              onClick={() => setShowGoalModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#C6F36A] text-[#101214] font-bold text-xs rounded-xl transition"
            >
              <Plus className="w-3.5 h-3.5" />
              Tambah Target
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {goals.map((g) => {
              // Calculate current progress for this goal
              let currentVal = 0;
              if (g.type === 'sessions_per_week') {
                currentVal = completionsThisWeek > 0 ? 1 : 0; // or session count
              } else if (g.type === 'reps_total') {
                currentVal = Object.values(repsByActivity).reduce((a, b) => a + b, 0);
              } else if (g.type === 'active_days_per_week') {
                currentVal = activeDaysSet.size;
              }

              const pct = Math.min(100, Math.round((currentVal / g.target) * 100));

              return (
                <div
                  key={g.id}
                  className="bg-[#191D21] border border-[#242C35] rounded-2xl p-4 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-bold text-[#F4F6F8]">{g.title}</h4>
                      <span className="text-xs font-mono text-[#C6F36A] font-bold">
                        {currentVal} / {g.target} {g.unit}
                      </span>
                    </div>

                    <div className="w-full bg-[#121518] h-2 rounded-full overflow-hidden my-3">
                      <div
                        className="h-full bg-gradient-to-r from-[#C6F36A] to-[#2DD4BF] rounded-full transition-all duration-300"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-[#9AA5B1] pt-2 border-t border-[#242C35]">
                    <span>Progres: {pct}%</span>
                    <button
                      onClick={async () => {
                        await db.goals.delete(g.id);
                        onRefreshData();
                      }}
                      className="text-[#E11D48] hover:underline"
                    >
                      Hapus
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab: ACHIEVEMENTS */}
      {activeTab === 'achievements' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {achievements.map((ach) => {
            const isUnlocked = !!ach.unlockedAt;

            return (
              <div
                key={ach.id}
                className={`rounded-2xl p-4 border transition-all flex flex-col justify-between ${
                  isUnlocked
                    ? 'bg-[#191D21] border-[#C6F36A]/50 shadow-md shadow-[#C6F36A]/5'
                    : 'bg-[#15181C] border-[#22282E] opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        isUnlocked
                          ? 'bg-[#C6F36A] text-[#101214] shadow-md shadow-[#C6F36A]/20'
                          : 'bg-[#22282E] text-[#9AA5B1]'
                      }`}
                    >
                      {getAchievementIcon(ach.icon)}
                    </div>

                    {isUnlocked ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-[#C6F36A]/10 text-[#C6F36A] border border-[#C6F36A]/30">
                        <CheckCircle2 className="w-3 h-3" />
                        Terbuka
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#9AA5B1]">
                        <Lock className="w-3 h-3" />
                        Terkunci
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold text-[#F4F6F8]">{ach.title}</h4>
                  <p className="text-xs text-[#9AA5B1] mt-1 leading-relaxed">
                    {ach.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#242C35] flex items-center justify-between text-xs">
                  <span className="text-[#C6F36A] font-bold">+{ach.xpReward} XP</span>
                  <span className="text-[#9AA5B1] font-mono text-[11px]">
                    {ach.progress} / {ach.maxProgress}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Goal Modal */}
      {showGoalModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div className="w-full max-w-sm bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 shadow-2xl">
            <h4 className="text-base font-bold text-[#F4F6F8] mb-3">Tambah Target Baru</h4>
            <div className="space-y-3 mb-5">
              <div>
                <label className="text-xs text-[#9AA5B1] block mb-1">Judul Target</label>
                <input
                  type="text"
                  value={newGoalTitle}
                  onChange={(e) => setNewGoalTitle(e.target.value)}
                  placeholder="Misal: 5 Sesi Seminggu"
                  className="w-full bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8] focus:border-[#C6F36A] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-[#9AA5B1] block mb-1">Jenis Target</label>
                <select
                  value={newGoalType}
                  onChange={(e) => setNewGoalType(e.target.value as UserGoal['type'])}
                  className="w-full bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8]"
                >
                  <option value="sessions_per_week">Jumlah Sesi Per Minggu</option>
                  <option value="reps_total">Total Repetisi Per Minggu</option>
                  <option value="active_days_per_week">Hari Aktif Per Minggu</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-[#9AA5B1] block mb-1">Target Angka</label>
                <input
                  type="number"
                  min="1"
                  max="1000"
                  value={newGoalTarget}
                  onChange={(e) => setNewGoalTarget(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full bg-[#121518] border border-[#2D3844] rounded-xl px-3 py-2 text-xs text-[#F4F6F8]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setShowGoalModal(false)}
                className="px-4 py-2 text-xs font-semibold text-[#9AA5B1]"
              >
                Batal
              </button>
              <button
                onClick={handleSaveGoal}
                className="px-4 py-2 bg-[#C6F36A] text-[#101214] font-bold text-xs rounded-xl"
              >
                Simpan Target
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
