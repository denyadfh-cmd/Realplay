import React, { useState } from 'react';
import { Wheel, WheelItem, ItemType } from '../../types/index';
import { SpinWheel } from '../../components/wheel/SpinWheel';
import { SPORT_PALETTE } from '../../domain/presets';
import { validateWheel, parseMultilineItems } from '../../domain/validation';
import {
  X,
  Plus,
  Trash2,
  Copy,
  ArrowUp,
  ArrowDown,
  Save,
  FileText,
  AlertCircle,
  Eye,
  Sliders,
} from 'lucide-react';

interface WheelEditorModalProps {
  wheel: Wheel | null; // if null, creating new
  onSave: (savedWheel: Wheel) => void;
  onClose: () => void;
}

export const WheelEditorModal: React.FC<WheelEditorModalProps> = ({
  wheel,
  onSave,
  onClose,
}) => {
  const isEditing = !!wheel;
  const [name, setName] = useState<string>(wheel?.name || 'Roda Latihan Baru');
  const [description, setDescription] = useState<string>(wheel?.description || '');
  const [selectionMode, setSelectionMode] = useState<'equal' | 'weighted'>(
    wheel?.selectionMode || 'equal'
  );
  const [items, setItems] = useState<WheelItem[]>(
    wheel?.items || [
      {
        id: `item-${Date.now()}-1`,
        label: 'Push-up × 10',
        type: 'repetition',
        value: 10,
        unit: 'reps',
        category: 'upper_body',
        color: SPORT_PALETTE[0],
        weight: 1,
        trackingMode: 'repetition',
        isWorkout: true,
      },
      {
        id: `item-${Date.now()}-2`,
        label: 'Squat × 15',
        type: 'repetition',
        value: 15,
        unit: 'reps',
        category: 'lower_body',
        color: SPORT_PALETTE[1],
        weight: 1,
        trackingMode: 'repetition',
        isWorkout: true,
      },
      {
        id: `item-${Date.now()}-3`,
        label: 'Plank 30s',
        type: 'duration',
        value: 30,
        unit: 'detik',
        category: 'core',
        color: SPORT_PALETTE[2],
        weight: 1,
        trackingMode: 'duration',
        isWorkout: true,
      },
      {
        id: `item-${Date.now()}-4`,
        label: 'Istirahat 30s',
        type: 'rest',
        value: 30,
        unit: 'detik',
        category: 'mobility_rest',
        color: '#4B5563',
        weight: 1,
        trackingMode: 'duration',
        isWorkout: false,
      },
    ]
  );

  const [activeTab, setActiveTab] = useState<'items' | 'bulk' | 'preview'>('items');
  const [bulkText, setBulkText] = useState<string>('');
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  // Add a blank item
  const handleAddItem = () => {
    const newItem: WheelItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      label: `Latihan Baru ${items.length + 1}`,
      type: 'repetition',
      value: 10,
      unit: 'reps',
      category: 'general',
      color: SPORT_PALETTE[items.length % SPORT_PALETTE.length],
      weight: 1,
      trackingMode: 'repetition',
      isWorkout: true,
    };
    setItems([...items, newItem]);
  };

  // Modify item fields
  const handleUpdateItem = (id: string, updates: Partial<WheelItem>) => {
    setItems(
      items.map((it) => {
        if (it.id !== id) return it;
        const merged = { ...it, ...updates };

        // Automatically configure trackingMode, category & isWorkout if type changes
        if (updates.type) {
          if (updates.type === 'rest') {
            merged.isWorkout = false;
            merged.category = 'mobility_rest';
            merged.trackingMode = 'duration';
            merged.unit = merged.unit || 'detik';
          } else if (updates.type === 'duration') {
            merged.isWorkout = true;
            merged.trackingMode = 'duration';
            merged.unit = merged.unit || 'detik';
          } else if (updates.type === 'distance') {
            merged.isWorkout = true;
            merged.trackingMode = 'distance';
            merged.unit = merged.unit || 'meter';
          } else if (updates.type === 'repetition' || updates.type === 'number') {
            merged.isWorkout = true;
            merged.trackingMode = 'repetition';
            merged.unit = merged.unit || 'reps';
          } else {
            merged.trackingMode = 'completion';
          }
        }
        return merged;
      })
    );
  };

  // Duplicate item
  const handleDuplicateItem = (item: WheelItem) => {
    const clone: WheelItem = {
      ...item,
      id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      label: `${item.label} (Salinan)`,
      color: SPORT_PALETTE[items.length % SPORT_PALETTE.length],
    };
    setItems([...items, clone]);
  };

  // Remove item
  const handleRemoveItem = (id: string) => {
    if (items.length <= 2) {
      alert('Roda harus memiliki minimal 2 item.');
      return;
    }
    setItems(items.filter((it) => it.id !== id));
  };

  // Reorder items
  const handleMove = (index: number, dir: 'up' | 'down') => {
    const targetIdx = dir === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= items.length) return;
    const next = [...items];
    const temp = next[index];
    next[index] = next[targetIdx];
    next[targetIdx] = temp;
    setItems(next);
  };

  // Bulk parse text
  const handleApplyBulk = () => {
    if (!bulkText.trim()) return;
    const parsed = parseMultilineItems(bulkText, items.length);
    if (parsed.length > 0) {
      setItems([...items, ...parsed]);
      setBulkText('');
      setActiveTab('items');
    }
  };

  // Validate and submit save
  const handleSave = () => {
    const candidate: Wheel = {
      id: wheel?.id || `wheel-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: name.trim(),
      description: description.trim(),
      source: 'custom', // saving always creates/updates a custom wheel
      items,
      selectionMode,
      createdAt: wheel?.createdAt || Date.now(),
      updatedAt: Date.now(),
      schemaVersion: 1,
    };

    const errors = validateWheel(candidate);
    if (errors.length > 0) {
      setValidationErrors(errors.map((e) => e.message));
      return;
    }

    onSave(candidate);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="wheel-editor-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="w-full max-w-3xl bg-[#191D21] border border-[#2D3844] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#242C35]">
          <div>
            <h3 id="wheel-editor-title" className="text-lg font-bold text-[#F4F6F8]">
              {isEditing ? 'Edit Roda Latihan' : 'Buat Roda Baru'}
            </h3>
            <p className="text-xs text-[#9AA5B1]">
              Kustomisasi nama, jenis latihan, segmen warna, dan peluang putaran.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#22282E] transition"
            aria-label="Tutup Editor"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Errors list */}
        {validationErrors.length > 0 && (
          <div className="bg-[#E11D48]/10 border-l-4 border-[#E11D48] p-3 mx-4 sm:mx-5 mt-4 rounded-r-xl">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-[#E11D48] flex-shrink-0 mt-0.5" />
              <div className="text-xs text-[#F43F5E] space-y-1">
                {validationErrors.map((err, i) => (
                  <p key={i}>{err}</p>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Wheel Meta Settings */}
        <div className="p-4 sm:p-5 border-b border-[#242C35] grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#14181C]">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-[#9AA5B1] mb-1">
              Nama Roda *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Contoh: Latihan Pagi Cepat"
              className="w-full bg-[#191D21] border border-[#2D3844] rounded-xl px-3 py-2 text-sm text-[#F4F6F8] focus:border-[#C6F36A] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#9AA5B1] mb-1">
              Distribusi Peluang
            </label>
            <select
              value={selectionMode}
              onChange={(e) => setSelectionMode(e.target.value as 'equal' | 'weighted')}
              className="w-full bg-[#191D21] border border-[#2D3844] rounded-xl px-3 py-2 text-sm text-[#F4F6F8] focus:border-[#C6F36A] focus:outline-none"
            >
              <option value="equal">Sama Rata (Equal Weight)</option>
              <option value="weighted">Bobot Khusus (Weighted)</option>
            </select>
          </div>
        </div>

        {/* Tab navigation: Items, Bulk, Preview */}
        <div className="flex items-center px-4 sm:px-5 border-b border-[#242C35] bg-[#161B20]">
          <button
            onClick={() => setActiveTab('items')}
            className={`py-2.5 px-3 text-xs font-bold border-b-2 transition ${
              activeTab === 'items'
                ? 'border-[#C6F36A] text-[#C6F36A]'
                : 'border-transparent text-[#9AA5B1] hover:text-[#F4F6F8]'
            }`}
          >
            Daftar Item ({items.length})
          </button>
          <button
            onClick={() => setActiveTab('bulk')}
            className={`py-2.5 px-3 text-xs font-bold border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'bulk'
                ? 'border-[#C6F36A] text-[#C6F36A]'
                : 'border-transparent text-[#9AA5B1] hover:text-[#F4F6F8]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Impor dari Teks
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`py-2.5 px-3 text-xs font-bold border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'preview'
                ? 'border-[#C6F36A] text-[#C6F36A]'
                : 'border-transparent text-[#9AA5B1] hover:text-[#F4F6F8]'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            Pratinjau Roda
          </button>
        </div>

        {/* Body content based on active tab */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {activeTab === 'items' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-1">
                <span className="text-xs font-semibold text-[#9AA5B1]">
                  Urutan dan Konfigurasi Tantangan
                </span>
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] text-xs font-bold transition"
                >
                  <Plus className="w-4 h-4" />
                  Tambah Item
                </button>
              </div>

              {items.map((it, idx) => (
                <div
                  key={it.id}
                  className="bg-[#121518] border border-[#242C35] rounded-xl p-3 flex flex-col gap-2.5 hover:border-[#374350] transition"
                >
                  {/* Top row: Label, color, action buttons */}
                  <div className="flex items-center gap-2">
                    {/* Color dot picker */}
                    <div className="relative">
                      <input
                        type="color"
                        value={it.color || '#C6F36A'}
                        onChange={(e) => handleUpdateItem(it.id, { color: e.target.value })}
                        className="w-7 h-7 rounded-lg cursor-pointer bg-transparent border-0 p-0"
                        title="Pilih Warna Segmen"
                      />
                    </div>

                    <input
                      type="text"
                      value={it.label}
                      onChange={(e) => handleUpdateItem(it.id, { label: e.target.value })}
                      placeholder="Nama Latihan (misal: Push-up x 10)"
                      className="flex-1 bg-[#191D21] border border-[#2D3844] rounded-lg px-2.5 py-1.5 text-xs sm:text-sm font-semibold text-[#F4F6F8] focus:border-[#C6F36A] focus:outline-none"
                    />

                    {/* Controls */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => handleMove(idx, 'up')}
                        className="p-1 rounded text-[#9AA5B1] hover:text-[#F4F6F8] disabled:opacity-20"
                        title="Geser ke Atas"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={idx === items.length - 1}
                        onClick={() => handleMove(idx, 'down')}
                        className="p-1 rounded text-[#9AA5B1] hover:text-[#F4F6F8] disabled:opacity-20"
                        title="Geser ke Bawah"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDuplicateItem(it)}
                        className="p-1 rounded text-[#9AA5B1] hover:text-[#0EA5E9]"
                        title="Duplikasi Item"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={items.length <= 2}
                        onClick={() => handleRemoveItem(it.id)}
                        className="p-1 rounded text-[#9AA5B1] hover:text-[#E11D48] disabled:opacity-20"
                        title="Hapus Item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Bottom row: Type, Value, Unit, Category, Weight */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1 border-t border-[#1C2228] text-xs">
                    <div>
                      <label className="text-[10px] text-[#9AA5B1] block mb-0.5">Jenis</label>
                      <select
                        value={it.type}
                        onChange={(e) => handleUpdateItem(it.id, { type: e.target.value as ItemType })}
                        className="w-full bg-[#191D21] border border-[#2D3844] rounded px-2 py-1 text-xs text-[#F4F6F8]"
                      >
                        <option value="repetition">Repetisi</option>
                        <option value="duration">Durasi</option>
                        <option value="distance">Jarak</option>
                        <option value="activity">Aktivitas</option>
                        <option value="rest">Istirahat / Recovery</option>
                        <option value="number">Angka Saja</option>
                        <option value="custom">Kustom</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] text-[#9AA5B1] block mb-0.5">Target Nilai</label>
                      <input
                        type="number"
                        min="0"
                        max="10000"
                        value={it.value ?? ''}
                        onChange={(e) =>
                          handleUpdateItem(it.id, {
                            value: e.target.value ? parseFloat(e.target.value) : undefined,
                          })
                        }
                        placeholder="Nilai"
                        className="w-full bg-[#191D21] border border-[#2D3844] rounded px-2 py-1 text-xs text-[#F4F6F8]"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#9AA5B1] block mb-0.5">Satuan</label>
                      <input
                        type="text"
                        value={it.unit || ''}
                        onChange={(e) => handleUpdateItem(it.id, { unit: e.target.value })}
                        placeholder="reps / detik / meter"
                        className="w-full bg-[#191D21] border border-[#2D3844] rounded px-2 py-1 text-xs text-[#F4F6F8]"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#9AA5B1] block mb-0.5">Kategori</label>
                      <select
                        value={it.category || 'general'}
                        onChange={(e) => handleUpdateItem(it.id, { category: e.target.value })}
                        className="w-full bg-[#191D21] border border-[#2D3844] rounded px-2 py-1 text-xs text-[#F4F6F8]"
                      >
                        <option value="upper_body">Tubuh Atas</option>
                        <option value="lower_body">Tubuh Bawah</option>
                        <option value="core">Core (Perut)</option>
                        <option value="cardio">Kardio</option>
                        <option value="mobility_rest">Istirahat & Pulih</option>
                        <option value="general">Umum</option>
                      </select>
                    </div>

                    {selectionMode === 'weighted' && (
                      <div>
                        <label className="text-[10px] text-[#9AA5B1] block mb-0.5">Bobot (Weight)</label>
                        <input
                          type="number"
                          min="0.1"
                          step="0.5"
                          value={it.weight ?? 1}
                          onChange={(e) =>
                            handleUpdateItem(it.id, {
                              weight: Math.max(0.1, parseFloat(e.target.value) || 1),
                            })
                          }
                          className="w-full bg-[#191D21] border border-[#2D3844] rounded px-2 py-1 text-xs text-[#C6F36A] font-bold"
                        />
                      </div>
                    )}

                    <div className="flex items-center gap-1.5 pt-3 col-span-2 sm:col-span-1">
                      <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-[#9AA5B1] select-none">
                        <input
                          type="checkbox"
                          checked={it.isWorkout}
                          onChange={(e) => handleUpdateItem(it.id, { isWorkout: e.target.checked })}
                          className="rounded accent-[#C6F36A] w-3.5 h-3.5 cursor-pointer"
                        />
                        <span className={it.isWorkout ? 'text-[#C6F36A] font-medium' : 'text-[#9AA5B1]'}>
                          {it.isWorkout ? 'Latihan Fisik' : 'Pemulihan/Istirahat'}
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'bulk' && (
            <div className="space-y-3">
              <p className="text-xs text-[#9AA5B1] leading-relaxed">
                Ketik atau tempel daftar latihan kamu, satu item per baris. Sistem akan otomatis mendeteksi angka, repetisi, durasi, jarak, maupun istirahat.
              </p>
              <textarea
                rows={10}
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                placeholder={`Push-up x 10\nSquat x 15\nPlank 30s\nJalan kaki 500m\nIstirahat 30s\nHandgrip 15 kali`}
                className="w-full font-mono text-xs bg-[#121518] border border-[#2D3844] rounded-xl p-3 text-[#F4F6F8] focus:border-[#C6F36A] focus:outline-none"
              />
              <button
                type="button"
                onClick={handleApplyBulk}
                className="px-4 py-2 bg-[#0EA5E9] hover:bg-[#0284C7] text-white font-bold text-xs rounded-xl transition"
              >
                Konversi & Tambahkan ke Roda
              </button>
            </div>
          )}

          {activeTab === 'preview' && (
            <div className="flex flex-col items-center justify-center py-4">
              <SpinWheel
                items={items}
                selectionMode={selectionMode}
                isSpinning={false}
                targetIndex={null}
                onSpinFinish={() => {}}
              />
              <p className="text-xs text-[#9AA5B1] mt-3">
                Pratinjau visual langsung dari {items.length} segmen.
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-[#242C35] flex items-center justify-between bg-[#14181C]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#191D21] rounded-xl transition"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-6 py-2.5 bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] font-black text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-lg shadow-[#C6F36A]/20 transition"
          >
            <Save className="w-4 h-4" />
            Simpan Roda
          </button>
        </div>
      </div>
    </div>
  );
};
