import React, { useState, useRef } from 'react';
import { Wheel } from '../../types/index';
import { WheelEditorModal } from './WheelEditorModal';
import { db } from '../../services/db';
import { exportSingleWheel, shareWheel } from '../../services/backup';
import { validateImportedWheelConfig } from '../../domain/validation';
import {
  Plus,
  Play,
  Edit2,
  Copy,
  Trash2,
  Share2,
  Download,
  Upload,
  Check,
  Sparkles,
  Layers,
  AlertCircle,
} from 'lucide-react';

interface WheelsViewProps {
  wheels: Wheel[];
  activeWheelId: string | null;
  onSelectAndPlay: (wheelId: string) => void;
  onRefreshData: () => void;
}

export const WheelsView: React.FC<WheelsViewProps> = ({
  wheels,
  activeWheelId,
  onSelectAndPlay,
  onRefreshData,
}) => {
  const [editingWheel, setEditingWheel] = useState<Wheel | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deletingWheelId, setDeletingWheelId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const customWheels = wheels.filter((w) => w.source === 'custom');
  const builtinWheels = wheels.filter((w) => w.source === 'builtin');

  // Create new wheel
  const handleOpenCreate = () => {
    setEditingWheel(null);
    setIsEditorOpen(true);
  };

  // Edit existing wheel
  const handleOpenEdit = (w: Wheel) => {
    if (w.source === 'builtin') {
      // Duplicating built-in preset to custom for safe editing
      const clone: Wheel = {
        ...w,
        id: `wheel-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: `${w.name} (Kustom)`,
        source: 'custom',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      setEditingWheel(clone);
      setIsEditorOpen(true);
    } else {
      setEditingWheel(w);
      setIsEditorOpen(true);
    }
  };

  // Duplicate wheel
  const handleDuplicate = async (w: Wheel) => {
    const clone: Wheel = {
      ...w,
      id: `wheel-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: `${w.name} (Salinan)`,
      source: 'custom',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    await db.saveWheel(clone);
    onRefreshData();
    showToast(`Roda "${clone.name}" berhasil dibuat!`);
  };

  // Delete wheel
  const handleDelete = async (wheelId: string) => {
    await db.deleteWheel(wheelId);
    setDeletingWheelId(null);
    onRefreshData();
    showToast('Roda custom berhasil dihapus.');
  };

  // Save wheel from editor
  const handleSaveWheel = async (saved: Wheel) => {
    await db.saveWheel(saved);
    setIsEditorOpen(false);
    onRefreshData();
    showToast(`Roda "${saved.name}" berhasil disimpan!`);
  };

  // Share wheel
  const handleShare = async (w: Wheel) => {
    const res = await shareWheel(w);
    showToast(res.message);
  };

  // Import JSON file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const text = evt.target?.result as string;
        const parsed = JSON.parse(text);
        const validated = validateImportedWheelConfig(parsed);

        if (!validated.valid || !validated.wheel) {
          showToast(validated.error || 'Format file roda tidak valid.');
          return;
        }

        const newWheel: Wheel = {
          ...validated.wheel,
          id: `wheel-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          source: 'custom',
        };

        await db.saveWheel(newWheel);
        onRefreshData();
        showToast(`Roda "${newWheel.name}" berhasil diimpor!`);
      } catch {
        showToast('Gagal membaca file JSON. Pastikan format valid.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="flex-1 max-w-6xl mx-auto w-full px-4 py-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-16 right-4 z-50 bg-[#C6F36A] text-[#101214] font-bold text-xs py-2 px-4 rounded-xl shadow-xl animate-in slide-in-from-top duration-200">
          {toastMessage}
        </div>
      )}

      {/* Top Banner & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-[#232B32]">
        <div>
          <h2 className="text-2xl font-black text-[#F4F6F8] tracking-tight">Koleksi Roda Latihan</h2>
          <p className="text-xs text-[#9AA5B1] mt-1">
            Gunakan preset siap pakai atau rancang kombinasi latihan sesuai target kebugaranmu.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Hidden JSON file input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".json,application/json"
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#191D21] hover:bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8] border border-[#2D3844] text-xs font-bold transition"
            title="Impor Roda dari File JSON"
          >
            <Upload className="w-4 h-4 text-[#0EA5E9]" />
            <span>Impor JSON</span>
          </button>

          <button
            type="button"
            onClick={handleOpenCreate}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] text-xs font-black shadow-md shadow-[#C6F36A]/20 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Buat Roda Baru</span>
          </button>
        </div>
      </div>

      {/* Section 1: Custom Wheels */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#C6F36A]" />
            <h3 className="text-base font-bold text-[#F4F6F8]">Roda Custom Kamu</h3>
            <span className="text-xs text-[#9AA5B1] font-mono">({customWheels.length})</span>
          </div>
        </div>

        {customWheels.length === 0 ? (
          <div className="p-8 text-center bg-[#191D21] border border-[#242C35] rounded-2xl">
            <Layers className="w-8 h-8 text-[#9AA5B1] mx-auto mb-2" />
            <p className="text-sm font-semibold text-[#F4F6F8]">Belum ada roda buatan sendiri</p>
            <p className="text-xs text-[#9AA5B1] mt-1 mb-4">
              Buat roda baru atau duplikasi dari preset olahraga di bawah untuk menyesuaikannya.
            </p>
            <button
              onClick={handleOpenCreate}
              className="px-4 py-2 bg-[#22282E] hover:bg-[#2C353D] text-[#C6F36A] font-bold text-xs rounded-xl border border-[#2D3844] transition inline-flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Mulai Buat Sekarang
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {customWheels.map((w) => (
              <WheelCard
                key={w.id}
                wheel={w}
                isActive={w.id === activeWheelId}
                onPlay={() => onSelectAndPlay(w.id)}
                onEdit={() => handleOpenEdit(w)}
                onDuplicate={() => handleDuplicate(w)}
                onExport={() => exportSingleWheel(w)}
                onShare={() => handleShare(w)}
                onDelete={() => setDeletingWheelId(w.id)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Section 2: Built-in Presets */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#0EA5E9]" />
            <h3 className="text-base font-bold text-[#F4F6F8]">Preset Olahraga Siap Pakai</h3>
            <span className="text-xs text-[#9AA5B1] font-mono">({builtinWheels.length})</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {builtinWheels.map((w) => (
            <WheelCard
              key={w.id}
              wheel={w}
              isActive={w.id === activeWheelId}
              onPlay={() => onSelectAndPlay(w.id)}
              onEdit={() => handleOpenEdit(w)}
              onDuplicate={() => handleDuplicate(w)}
              onExport={() => exportSingleWheel(w)}
              onShare={() => handleShare(w)}
            />
          ))}
        </div>
      </div>

      {/* Editor Modal */}
      {isEditorOpen && (
        <WheelEditorModal
          wheel={editingWheel}
          onSave={handleSaveWheel}
          onClose={() => setIsEditorOpen(false)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deletingWheelId && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div className="w-full max-w-sm bg-[#191D21] border border-[#2D3844] rounded-2xl p-6 text-center shadow-2xl">
            <AlertCircle className="w-10 h-10 text-[#E11D48] mx-auto mb-2" />
            <h4 className="text-base font-bold text-[#F4F6F8]">Hapus Roda Ini?</h4>
            <p className="text-xs text-[#9AA5B1] mt-1 mb-5">
              Roda ini akan dihapus dari koleksi kamu. Riwayat latihan yang pernah diselesaikan tetap aman.
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setDeletingWheelId(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#22282E] text-[#F4F6F8]"
              >
                Batal
              </button>
              <button
                onClick={() => handleDelete(deletingWheelId)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#E11D48] hover:bg-[#BE123C] text-white"
              >
                Ya, Hapus Roda
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Subcomponent: Wheel Card
const WheelCard: React.FC<{
  wheel: Wheel;
  isActive: boolean;
  onPlay: () => void;
  onEdit: () => void;
  onDuplicate: () => void;
  onExport: () => void;
  onShare: () => void;
  onDelete?: () => void;
}> = ({
  wheel,
  isActive,
  onPlay,
  onEdit,
  onDuplicate,
  onExport,
  onShare,
  onDelete,
}) => {
  return (
    <div
      className={`bg-[#191D21] rounded-2xl p-4 border transition-all flex flex-col justify-between ${
        isActive
          ? 'border-[#C6F36A] shadow-lg shadow-[#C6F36A]/5'
          : 'border-[#242C35] hover:border-[#374350]'
      }`}
    >
      <div>
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="min-w-0">
            <h4 className="text-sm font-bold text-[#F4F6F8] truncate">{wheel.name}</h4>
            <p className="text-xs text-[#9AA5B1] mt-0.5 line-clamp-2">
              {wheel.description || 'Tidak ada deskripsi'}
            </p>
          </div>

          {isActive && (
            <span className="flex-shrink-0 text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[#C6F36A]/10 text-[#C6F36A] border border-[#C6F36A]/30">
              Aktif
            </span>
          )}
        </div>

        {/* Item tags sneak preview */}
        <div className="flex flex-wrap gap-1.5 my-3">
          {wheel.items.slice(0, 4).map((it) => (
            <span
              key={it.id}
              className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-[#121518] text-[#9AA5B1] border border-[#242C35] truncate max-w-[120px]"
            >
              {it.label}
            </span>
          ))}
          {wheel.items.length > 4 && (
            <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-[#121518] text-[#9AA5B1]">
              +{wheel.items.length - 4} lagi
            </span>
          )}
        </div>
      </div>

      {/* Card Actions */}
      <div className="pt-3 border-t border-[#242C35] flex items-center justify-between gap-2">
        <button
          onClick={onPlay}
          className="flex-1 py-2 px-3 bg-[#C6F36A] hover:bg-[#B8EB54] text-[#101214] font-black text-xs rounded-xl flex items-center justify-center gap-1.5 transition shadow-sm"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          Putar Roda
        </button>

        <div className="flex items-center gap-1">
          <button
            onClick={onEdit}
            className="p-2 rounded-lg bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#2C353D] transition"
            title={wheel.source === 'builtin' ? 'Duplikasi & Kustomisasi' : 'Edit Roda'}
            aria-label="Edit roda"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onDuplicate}
            className="p-2 rounded-lg bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#2C353D] transition"
            title="Duplikasi Roda"
            aria-label="Duplikasi roda"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onShare}
            className="p-2 rounded-lg bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#2C353D] transition"
            title="Bagikan Tautan Roda"
            aria-label="Bagikan roda"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onExport}
            className="p-2 rounded-lg bg-[#22282E] text-[#9AA5B1] hover:text-[#F4F6F8] hover:bg-[#2C353D] transition"
            title="Ekspor JSON"
            aria-label="Ekspor JSON roda"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
          {onDelete && (
            <button
              onClick={onDelete}
              className="p-2 rounded-lg bg-[#22282E] text-[#E11D48] hover:bg-[#E11D48]/20 transition"
              title="Hapus Roda"
              aria-label="Hapus roda"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
