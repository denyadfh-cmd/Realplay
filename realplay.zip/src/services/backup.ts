import { db } from './db';
import { Wheel, WheelExportFormat, FullBackupFormat } from '../types/index';
import { validateImportedWheelConfig, validateFullBackup } from '../domain/validation';

/**
 * Exports complete application database to JSON file download
 */
export async function exportFullBackup(): Promise<void> {
  const wheels = await db.wheels.toArray();
  const sessions = await db.sessions.toArray();
  const challenges = await db.challenges.toArray();
  const completions = await db.completions.toArray();
  const goals = await db.goals.toArray();
  const achievements = await db.achievements.toArray();
  const settings = await db.getUserSettings();

  const backupData: FullBackupFormat = {
    schemaVersion: 1,
    exportedAt: Date.now(),
    appVersion: '1.0.0',
    wheels,
    sessions,
    challenges,
    completions,
    goals,
    achievements,
    settings,
  };

  const jsonStr = JSON.stringify(backupData, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const dateTag = new Date().toISOString().split('T')[0];

  const a = document.createElement('a');
  a.href = url;
  a.download = `realplay-backup-${dateTag}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Restores full backup JSON data
 */
export async function restoreFullBackup(jsonContent: string): Promise<{ success: boolean; message: string }> {
  try {
    const parsed = JSON.parse(jsonContent);
    const validation = validateFullBackup(parsed);

    if (!validation.valid || !validation.backup) {
      return { success: false, message: validation.error || 'Format file cadangan tidak valid.' };
    }

    const { backup } = validation;

    await db.transaction('rw', [db.wheels, db.sessions, db.challenges, db.completions, db.goals, db.achievements, db.settings], async () => {
      // Clear current data
      await db.wheels.clear();
      await db.sessions.clear();
      await db.challenges.clear();
      await db.completions.clear();
      await db.goals.clear();
      await db.achievements.clear();

      // Restore items safely
      if (backup.wheels?.length) await db.wheels.bulkAdd(backup.wheels);
      if (backup.sessions?.length) await db.sessions.bulkAdd(backup.sessions);
      if (backup.challenges?.length) await db.challenges.bulkAdd(backup.challenges);
      if (backup.completions?.length) await db.completions.bulkAdd(backup.completions);
      if (backup.goals?.length) await db.goals.bulkAdd(backup.goals);
      if (backup.achievements?.length) await db.achievements.bulkAdd(backup.achievements);
      if (backup.settings) await db.settings.put({ key: 'user_settings', value: backup.settings });
    });

    return { success: true, message: 'Data cadangan berhasil dipulihkan secara penuh!' };
  } catch (err) {
    return { success: false, message: `Gagal memproses file cadangan: ${(err as Error).message}` };
  }
}

/**
 * Exports a single Wheel to downloadable JSON file
 */
export function exportSingleWheel(wheel: Wheel): void {
  const exportData: WheelExportFormat = {
    schemaVersion: 1,
    exportedAt: Date.now(),
    wheel: {
      name: wheel.name,
      description: wheel.description,
      selectionMode: wheel.selectionMode,
      items: wheel.items,
      createdAt: wheel.createdAt,
      updatedAt: wheel.updatedAt,
      schemaVersion: wheel.schemaVersion,
    },
  };

  const jsonStr = JSON.stringify(exportData, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const sanitizedName = wheel.name.toLowerCase().replace(/[^a-z0-9]/g, '-');

  const a = document.createElement('a');
  a.href = url;
  a.download = `wheel-${sanitizedName}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Encodes wheel into URL-safe shareable string
 */
export function encodeWheelToShareUrl(wheel: Wheel): string {
  const payload = {
    n: wheel.name,
    d: wheel.description,
    m: wheel.selectionMode,
    i: wheel.items.map((it) => ({
      l: it.label,
      t: it.type,
      v: it.value,
      u: it.unit,
      c: it.category,
      cl: it.color,
      w: it.weight,
    })),
  };
  const json = JSON.stringify(payload);
  const encoded = encodeURIComponent(btoa(unescape(encodeURIComponent(json))));
  const baseUrl = window.location.origin + window.location.pathname;
  return `${baseUrl}?import_wheel=${encoded}`;
}

/**
 * Decodes wheel from URL share parameter
 */
export function decodeWheelFromShareUrl(param: string): Omit<Wheel, 'id' | 'source'> | null {
  try {
    const json = decodeURIComponent(escape(atob(decodeURIComponent(param))));
    const p = JSON.parse(json);
    if (!p.n || !Array.isArray(p.i)) return null;

    return {
      name: p.n,
      description: p.d || '',
      selectionMode: p.m === 'weighted' ? 'weighted' : 'equal',
      schemaVersion: 1,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      items: p.i.map((it: { l: string; t?: string; v?: number; u?: string; c?: string; cl?: string; w?: number }, idx: number) => ({
        id: `shared-${Date.now()}-${idx}`,
        label: it.l || `Item ${idx + 1}`,
        type: (it.t as Wheel['items'][0]['type']) || 'activity',
        value: it.v,
        unit: it.u,
        category: it.c || 'general',
        color: it.cl || '#C6F36A',
        weight: it.w || 1,
        trackingMode: it.t === 'duration' ? 'duration' : it.t === 'repetition' ? 'repetition' : 'completion',
        isWorkout: true,
      })),
    };
  } catch {
    return null;
  }
}

/**
 * Shares wheel via Web Share API or copies link to clipboard
 */
export async function shareWheel(wheel: Wheel): Promise<{ shared: boolean; message: string }> {
  const url = encodeWheelToShareUrl(wheel);

  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: `Roda REALPLAY: ${wheel.name}`,
        text: `Coba roda latihan "${wheel.name}" di REALPLAY!`,
        url,
      });
      return { shared: true, message: 'Roda berhasil dibagikan!' };
    } catch (err) {
      if ((err as Error).name === 'AbortError') {
        return { shared: false, message: 'Berbagi dibatalkan.' };
      }
    }
  }

  // Fallback: Copy to clipboard
  try {
    await navigator.clipboard.writeText(url);
    return { shared: true, message: 'Tautan roda disalin ke clipboard!' };
  } catch {
    return { shared: false, message: 'Gagal menyalin tautan. Gunakan fitur ekspor JSON.' };
  }
}
