import Dexie, { Table } from 'dexie';
import {
  Wheel,
  WorkoutSession,
  Challenge,
  CompletionRecord,
  UserGoal,
  Achievement,
  UserSettings,
} from '../types/index';
import { BUILTIN_PRESETS } from '../domain/presets';
import {
  INITIAL_ACHIEVEMENTS,
  calculateCompletionXP,
  calculateLevelFromXP,
  evaluateAchievements,
} from '../domain/gamification';

export const DEFAULT_USER_SETTINGS: UserSettings = {
  soundEnabled: true,
  vibrationEnabled: true,
  reducedMotion: false,
  defaultWarmupMinutes: 3,
  difficultyLevel: 'intermediate',
  maxRepsLimit: 100,
  maxDurationSecondsLimit: 300,
  maxDistanceMetersLimit: 5000,
  userXp: 0,
  userLevel: 1,
};

export class RealPlayDatabase extends Dexie {
  wheels!: Table<Wheel, string>;
  sessions!: Table<WorkoutSession, string>;
  challenges!: Table<Challenge, string>;
  completions!: Table<CompletionRecord, string>;
  goals!: Table<UserGoal, string>;
  achievements!: Table<Achievement, string>;
  settings!: Table<{ key: string; value: unknown }, string>;

  constructor() {
    super('RealPlayDB');
    this.version(1).stores({
      wheels: 'id, name, source, selectionMode, updatedAt',
      sessions: 'id, status, startedAt',
      challenges: 'id, sessionId, status, createdAt, isWorkout',
      completions: 'id, challengeId, sessionId, completedAt, isWorkout, activityNameSnapshot, category',
      goals: 'id, type, enabled, period',
      achievements: 'id, code, unlockedAt',
      settings: 'key',
    });
  }

  /**
   * Initializes default data and presets on first launch
   */
  async initializeDefaults(): Promise<void> {
    const wheelCount = await this.wheels.count();
    if (wheelCount === 0) {
      await this.wheels.bulkAdd(BUILTIN_PRESETS);
    }

    const achCount = await this.achievements.count();
    if (achCount === 0) {
      await this.achievements.bulkAdd(INITIAL_ACHIEVEMENTS);
    }

    const settingsObj = await this.settings.get('user_settings');
    if (!settingsObj) {
      await this.settings.put({ key: 'user_settings', value: DEFAULT_USER_SETTINGS });
    }

    // Default goals if none exist
    const goalCount = await this.goals.count();
    if (goalCount === 0) {
      await this.goals.bulkAdd([
        {
          id: 'goal-weekly-sessions',
          title: '3 Sesi Latihan Seminggu',
          type: 'sessions_per_week',
          target: 3,
          current: 0,
          unit: 'sesi',
          enabled: true,
          period: 'weekly',
          createdAt: Date.now(),
        },
        {
          id: 'goal-weekly-reps',
          title: '150 Total Repetisi Seminggu',
          type: 'reps_total',
          target: 150,
          current: 0,
          unit: 'reps',
          enabled: true,
          period: 'weekly',
          createdAt: Date.now(),
        },
      ]);
    }
  }

  // --- Wheel Operations ---
  async getAllWheels(): Promise<Wheel[]> {
    return this.wheels.toArray();
  }

  async getWheel(id: string): Promise<Wheel | undefined> {
    return this.wheels.get(id);
  }

  async saveWheel(wheel: Wheel): Promise<string> {
    await this.wheels.put(wheel);
    // Trigger wheel creator achievement evaluation
    await this.checkAchievementsAfterWheelCreated();
    return wheel.id;
  }

  async deleteWheel(id: string): Promise<void> {
    // Only custom wheels can be deleted
    const target = await this.wheels.get(id);
    if (target && target.source === 'custom') {
      await this.wheels.delete(id);
    }
  }

  // --- Session Operations ---
  async getActiveSession(): Promise<WorkoutSession | null> {
    const session = await this.sessions.where('status').equals('active').first();
    return session || null;
  }

  async startNewSession(name?: string): Promise<WorkoutSession> {
    // Close any previous active session
    const existing = await this.getActiveSession();
    if (existing) {
      await this.sessions.update(existing.id, {
        status: 'completed',
        endedAt: Date.now(),
      });
    }

    const newSession: WorkoutSession = {
      id: `sess-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: name || `Sesi Latihan #${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}`,
      status: 'active',
      startedAt: Date.now(),
      challengeIds: [],
    };

    await this.sessions.add(newSession);
    return newSession;
  }

  async finishSession(sessionId: string): Promise<void> {
    await this.sessions.update(sessionId, {
      status: 'completed',
      endedAt: Date.now(),
    });
  }

  // --- Queue & Challenge Operations ---
  async getSessionChallenges(sessionId: string): Promise<Challenge[]> {
    return this.challenges.where('sessionId').equals(sessionId).toArray();
  }

  async getActiveQueue(sessionId: string): Promise<Challenge[]> {
    return this.challenges
      .where('sessionId')
      .equals(sessionId)
      .filter((c) => c.status === 'queued' || c.status === 'in_progress')
      .sortBy('createdAt');
  }

  async addChallenge(challenge: Challenge): Promise<void> {
    await this.challenges.add(challenge);
    // update session challengeIds
    const session = await this.sessions.get(challenge.sessionId);
    if (session) {
      const updatedIds = Array.from(new Set([...session.challengeIds, challenge.id]));
      await this.sessions.update(session.id, { challengeIds: updatedIds });
    }
  }

  async updateChallengeStatus(challengeId: string, status: Challenge['status']): Promise<void> {
    await this.challenges.update(challengeId, {
      status,
      ...(status === 'in_progress' ? { startedAt: Date.now() } : {}),
    });
  }

  async removeChallengeFromQueue(challengeId: string): Promise<void> {
    await this.challenges.update(challengeId, { status: 'cancelled' });
  }

  // --- Atomic Challenge Completion ---
  async recordChallengeCompletion(params: {
    challengeId: string;
    sessionId: string;
    activityNameSnapshot: string;
    category?: string;
    targetValue?: number;
    actualValue?: number;
    unit?: string;
    durationSeconds?: number;
    isWorkout: boolean;
    source: 'spin' | 'queue' | 'manual';
    startedAt?: number;
  }): Promise<{ record: CompletionRecord; xpEarned: number; newLevel?: number; newAchievements: Achievement[] }> {
    return this.transaction('rw', [this.challenges, this.completions, this.settings, this.achievements, this.wheels], async () => {
      // 1. Check idempotency: avoid duplicate completion record for same challengeId
      const existing = await this.completions.where('challengeId').equals(params.challengeId).first();
      if (existing) {
        return {
          record: existing,
          xpEarned: 0,
          newAchievements: [],
        };
      }

      // 2. Mark challenge completed
      await this.challenges.update(params.challengeId, {
        status: 'completed',
        actualValue: params.actualValue ?? params.targetValue,
        completedAt: Date.now(),
        durationSeconds: params.durationSeconds,
      });

      // 3. Create completion record
      const record: CompletionRecord = {
        id: `comp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        challengeId: params.challengeId,
        sessionId: params.sessionId,
        activityNameSnapshot: params.activityNameSnapshot,
        category: params.category,
        targetValue: params.targetValue,
        actualValue: params.actualValue ?? params.targetValue,
        unit: params.unit,
        startedAt: params.startedAt,
        completedAt: Date.now(),
        durationSeconds: params.durationSeconds,
        isWorkout: params.isWorkout,
        source: params.source,
      };

      await this.completions.add(record);

      // 4. Calculate XP
      const xpEarned = calculateCompletionXP({
        isWorkout: params.isWorkout,
        actualValue: record.actualValue,
        unit: record.unit,
        durationSeconds: record.durationSeconds,
      });

      // 5. Update user settings XP and Level
      const settingsWrapper = await this.settings.get('user_settings');
      const settings = (settingsWrapper?.value as UserSettings) || DEFAULT_USER_SETTINGS;
      const updatedXp = (settings.userXp || 0) + xpEarned;
      const { level } = calculateLevelFromXP(updatedXp);

      const updatedSettings: UserSettings = {
        ...settings,
        userXp: updatedXp,
        userLevel: level,
      };
      await this.settings.put({ key: 'user_settings', value: updatedSettings });

      // 6. Check and award achievements
      const allCompletions = await this.completions.toArray();
      const currentAchievements = await this.achievements.toArray();
      const customWheelsCount = await this.wheels.where('source').equals('custom').count();

      const { updatedAchievements, newlyUnlocked, totalXpGained } = evaluateAchievements(
        currentAchievements,
        allCompletions,
        customWheelsCount > 0,
        true
      );

      if (newlyUnlocked.length > 0) {
        for (const ach of updatedAchievements) {
          await this.achievements.put(ach);
        }
        if (totalXpGained > 0) {
          updatedSettings.userXp += totalXpGained;
          updatedSettings.userLevel = calculateLevelFromXP(updatedSettings.userXp).level;
          await this.settings.put({ key: 'user_settings', value: updatedSettings });
        }
      }

      return {
        record,
        xpEarned: xpEarned + totalXpGained,
        newLevel: level !== settings.userLevel ? level : undefined,
        newAchievements: newlyUnlocked,
      };
    });
  }

  /**
   * Undo a completion record safely with level and XP recalculation
   */
  async undoCompletionRecord(completionId: string): Promise<void> {
    const comp = await this.completions.get(completionId);
    if (!comp) return;

    await this.transaction('rw', [this.challenges, this.completions, this.settings], async () => {
      // Revert challenge status if it exists
      await this.challenges.update(comp.challengeId, {
        status: 'pending',
        completedAt: undefined,
      });

      // Remove completion record
      await this.completions.delete(completionId);

      // Deduct XP safely and recalculate level
      const xpToDeduct = calculateCompletionXP({
        isWorkout: comp.isWorkout,
        actualValue: comp.actualValue,
        unit: comp.unit,
        durationSeconds: comp.durationSeconds,
      });

      const settingsWrapper = await this.settings.get('user_settings');
      if (settingsWrapper) {
        const settings = settingsWrapper.value as UserSettings;
        const newXp = Math.max(0, (settings.userXp || 0) - xpToDeduct);
        const { level: newLevel } = calculateLevelFromXP(newXp);
        await this.settings.put({
          key: 'user_settings',
          value: { ...settings, userXp: newXp, userLevel: newLevel },
        });
      }
    });
  }

  // --- Achievement checks ---
  async checkAchievementsAfterWheelCreated(): Promise<void> {
    const achs = await this.achievements.toArray();
    const target = achs.find((a) => a.code === 'wheel_creator');
    if (target && !target.unlockedAt) {
      await this.achievements.update(target.id, {
        progress: 1,
        unlockedAt: Date.now(),
      });
      const settingsWrapper = await this.settings.get('user_settings');
      if (settingsWrapper) {
        const s = settingsWrapper.value as UserSettings;
        await this.settings.put({
          key: 'user_settings',
          value: { ...s, userXp: (s.userXp || 0) + target.xpReward },
        });
      }
    }
  }

  async checkAchievementsAfterSpin(): Promise<Achievement | null> {
    const achs = await this.achievements.toArray();
    const target = achs.find((a) => a.code === 'first_spin');
    if (target && !target.unlockedAt) {
      const updated: Achievement = {
        ...target,
        progress: 1,
        unlockedAt: Date.now(),
      };
      await this.achievements.put(updated);
      const settingsWrapper = await this.settings.get('user_settings');
      if (settingsWrapper) {
        const s = settingsWrapper.value as UserSettings;
        await this.settings.put({
          key: 'user_settings',
          value: { ...s, userXp: (s.userXp || 0) + target.xpReward },
        });
      }
      return updated;
    }
    return null;
  }

  // --- Settings & Preferences ---
  async getUserSettings(): Promise<UserSettings> {
    const wrapper = await this.settings.get('user_settings');
    if (wrapper && wrapper.value) {
      return { ...DEFAULT_USER_SETTINGS, ...(wrapper.value as UserSettings) };
    }
    return DEFAULT_USER_SETTINGS;
  }

  async updateUserSettings(newSettings: Partial<UserSettings>): Promise<UserSettings> {
    const current = await this.getUserSettings();
    const merged = { ...current, ...newSettings };
    await this.settings.put({ key: 'user_settings', value: merged });
    return merged;
  }

  // --- Reset All Data ---
  async clearAllData(): Promise<void> {
    await this.transaction('rw', [this.wheels, this.sessions, this.challenges, this.completions, this.goals, this.achievements, this.settings], async () => {
      await this.wheels.clear();
      await this.sessions.clear();
      await this.challenges.clear();
      await this.completions.clear();
      await this.goals.clear();
      await this.achievements.clear();
      await this.settings.clear();

      // re-seed presets & defaults
      await this.wheels.bulkAdd(BUILTIN_PRESETS);
      await this.achievements.bulkAdd(INITIAL_ACHIEVEMENTS);
      await this.settings.put({ key: 'user_settings', value: DEFAULT_USER_SETTINGS });
    });
  }
}

export const db = new RealPlayDatabase();
