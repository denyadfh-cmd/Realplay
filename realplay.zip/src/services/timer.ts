import { soundService } from './audio';

export type TimerState = 'idle' | 'running' | 'paused' | 'finished';

export interface TimerListener {
  (timeRemainingSeconds: number, progressRatio: number, state: TimerState): void;
}

export class DriftProofTimer {
  private targetDurationSec = 60;
  private remainingSec = 60;
  private state: TimerState = 'idle';
  private startTimestamp: number | null = null;
  private pausedRemainingSec = 60;
  private intervalId: ReturnType<typeof setInterval> | null = null;
  private listeners: Set<TimerListener> = new Set();

  public subscribe(listener: TimerListener): () => void {
    this.listeners.add(listener);
    listener(this.remainingSec, this.getProgressRatio(), this.state);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const ratio = this.getProgressRatio();
    this.listeners.forEach((l) => l(this.remainingSec, ratio, this.state));
  }

  public getProgressRatio(): number {
    if (this.targetDurationSec <= 0) return 0;
    return Math.max(0, Math.min(1, 1 - this.remainingSec / this.targetDurationSec));
  }

  public setDuration(seconds: number) {
    this.reset();
    this.targetDurationSec = Math.max(1, Math.round(seconds));
    this.remainingSec = this.targetDurationSec;
    this.pausedRemainingSec = this.targetDurationSec;
    this.notify();
  }

  public start() {
    if (this.state === 'running') return;

    this.state = 'running';
    this.startTimestamp = performance.now();
    this.pausedRemainingSec = this.remainingSec;

    if (this.intervalId) clearInterval(this.intervalId);

    this.intervalId = setInterval(() => {
      if (this.state !== 'running' || this.startTimestamp === null) return;
      const elapsedMs = performance.now() - this.startTimestamp;
      const elapsedSec = elapsedMs / 1000;
      const newRemaining = Math.max(0, this.pausedRemainingSec - elapsedSec);

      this.remainingSec = Math.ceil(newRemaining);

      if (newRemaining <= 0) {
        this.remainingSec = 0;
        this.state = 'finished';
        this.stopInterval();
        soundService.playTimerBell();
        this.notify();
      } else {
        this.notify();
      }
    }, 100);

    this.notify();
  }

  public pause() {
    if (this.state !== 'running') return;
    this.state = 'paused';
    if (this.startTimestamp !== null) {
      const elapsedSec = (performance.now() - this.startTimestamp) / 1000;
      this.remainingSec = Math.max(0, Math.ceil(this.pausedRemainingSec - elapsedSec));
      this.pausedRemainingSec = this.remainingSec;
    }
    this.stopInterval();
    this.notify();
  }

  public resume() {
    if (this.state !== 'paused') return;
    this.start();
  }

  public reset() {
    this.stopInterval();
    this.state = 'idle';
    this.remainingSec = this.targetDurationSec;
    this.pausedRemainingSec = this.targetDurationSec;
    this.startTimestamp = null;
    this.notify();
  }

  private stopInterval() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  public getState() {
    return {
      state: this.state,
      remainingSec: this.remainingSec,
      targetDurationSec: this.targetDurationSec,
    };
  }
}

export class DriftProofStopwatch {
  private elapsedSeconds = 0;
  private state: TimerState = 'idle';
  private startTimestamp: number | null = null;
  private baseElapsed = 0;
  private intervalId: ReturnType<typeof setInterval> | null = null;
  private listeners: Set<(seconds: number, state: TimerState) => void> = new Set();

  public subscribe(listener: (seconds: number, state: TimerState) => void): () => void {
    this.listeners.add(listener);
    listener(this.elapsedSeconds, this.state);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l(this.elapsedSeconds, this.state));
  }

  public start() {
    if (this.state === 'running') return;
    this.state = 'running';
    this.startTimestamp = performance.now();
    this.baseElapsed = this.elapsedSeconds;

    if (this.intervalId) clearInterval(this.intervalId);

    this.intervalId = setInterval(() => {
      if (this.state !== 'running' || this.startTimestamp === null) return;
      const deltaSec = (performance.now() - this.startTimestamp) / 1000;
      this.elapsedSeconds = Math.floor(this.baseElapsed + deltaSec);
      this.notify();
    }, 100);

    this.notify();
  }

  public pause() {
    if (this.state !== 'running') return;
    this.state = 'paused';
    if (this.startTimestamp !== null) {
      const deltaSec = (performance.now() - this.startTimestamp) / 1000;
      this.elapsedSeconds = Math.floor(this.baseElapsed + deltaSec);
      this.baseElapsed = this.elapsedSeconds;
    }
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.notify();
  }

  public resume() {
    if (this.state !== 'paused') return;
    this.start();
  }

  public reset() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.state = 'idle';
    this.elapsedSeconds = 0;
    this.baseElapsed = 0;
    this.startTimestamp = null;
    this.notify();
  }

  public getElapsed(): number {
    return this.elapsedSeconds;
  }
}
