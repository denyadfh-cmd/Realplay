import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getCryptoRandomInt,
  selectEqualWeightItem,
  selectWeightedItem,
  computeSegmentAngles,
  calculateTargetRotation,
  resolveItemIndexAtRotation,
} from '../domain/random';
import {
  calculateCompletionXP,
  calculateLevelFromXP,
  evaluateAchievements,
  INITIAL_ACHIEVEMENTS,
} from '../domain/gamification';
import {
  validateWheel,
  validateWheelItem,
  parseMultilineItems,
} from '../domain/validation';
import { WheelItem, Wheel } from '../types/index';

// Sample wheel items for testing
const mockItems: WheelItem[] = [
  { id: '1', label: 'Push-up × 10', type: 'repetition', value: 10, unit: 'reps', trackingMode: 'repetition', isWorkout: true },
  { id: '2', label: 'Squat × 15', type: 'repetition', value: 15, unit: 'reps', trackingMode: 'repetition', isWorkout: true },
  { id: '3', label: 'Plank 30s', type: 'duration', value: 30, unit: 'detik', trackingMode: 'duration', isWorkout: true },
  { id: '4', label: 'Istirahat 30s', type: 'rest', value: 30, unit: 'detik', trackingMode: 'duration', isWorkout: false },
];

test('getCryptoRandomInt produces numbers strictly within bounds [0, max)', () => {
  for (let i = 0; i < 50; i++) {
    const val = getCryptoRandomInt(4);
    assert.ok(val >= 0 && val < 4, `Value ${val} should be in [0, 4)`);
  }
});

test('selectEqualWeightItem returns valid element and index', () => {
  const selection = selectEqualWeightItem(mockItems);
  assert.ok(selection !== null);
  assert.ok(selection.index >= 0 && selection.index < mockItems.length);
  assert.equal(selection.item.id, mockItems[selection.index].id);
});

test('selectWeightedItem respects item weights and skips zero/negative weights', () => {
  const weightedItems: WheelItem[] = [
    { ...mockItems[0], weight: 100 },
    { ...mockItems[1], weight: 0.0001 },
  ];
  // 100 vs 0.0001: Item 0 should be selected almost exclusively
  const selection = selectWeightedItem(weightedItems);
  assert.ok(selection !== null);
  assert.equal(selection.index, 0);
});

test('computeSegmentAngles divides 360 degrees equally for equal mode', () => {
  const segments = computeSegmentAngles(mockItems, 'equal');
  assert.equal(segments.length, 4);
  assert.equal(segments[0].startAngle, 0);
  assert.equal(segments[0].endAngle, 90);
  assert.equal(segments[1].startAngle, 90);
  assert.equal(segments[1].endAngle, 180);
  assert.equal(segments[2].startAngle, 180);
  assert.equal(segments[2].endAngle, 270);
  assert.equal(segments[3].startAngle, 270);
  assert.equal(segments[3].endAngle, 360);
});

test('calculateTargetRotation and resolveItemIndexAtRotation resolve to the exact target item', () => {
  // Test every single item index
  for (let i = 0; i < mockItems.length; i++) {
    const { targetRotation } = calculateTargetRotation(0, i, mockItems, 'equal', 2, 2);
    const resolvedIndex = resolveItemIndexAtRotation(targetRotation, mockItems, 'equal');
    assert.equal(
      resolvedIndex,
      i,
      `Calculated rotation for index ${i} should resolve back to ${i}, got ${resolvedIndex}`
    );
  }
});

test('parseMultilineItems correctly detects reps, duration, distance, and rest', () => {
  const input = `
    Push-up x 12
    Squat 20 reps
    Plank 45 detik
    Jalan kaki 500 meter
    Istirahat 30s
    10
  `;
  const parsed = parseMultilineItems(input);
  assert.equal(parsed.length, 6);

  // 1. Push-up x 12
  assert.equal(parsed[0].type, 'repetition');
  assert.equal(parsed[0].value, 12);
  assert.equal(parsed[0].unit, 'reps');

  // 2. Squat 20 reps
  assert.equal(parsed[1].type, 'repetition');
  assert.equal(parsed[1].value, 20);

  // 3. Plank 45 detik
  assert.equal(parsed[2].type, 'duration');
  assert.equal(parsed[2].value, 45);
  assert.equal(parsed[2].unit, 'detik');

  // 4. Jalan kaki 500 meter
  assert.equal(parsed[3].type, 'distance');
  assert.equal(parsed[3].value, 500);
  assert.equal(parsed[3].unit, 'meter');

  // 5. Istirahat 30s
  assert.equal(parsed[4].type, 'rest');
  assert.equal(parsed[4].isWorkout, false);

  // 6. "10" number challenge
  assert.equal(parsed[5].type, 'number');
  assert.equal(parsed[5].value, 10);
});

test('validateWheel requires valid name and at least 2 items', () => {
  const invalidWheel: Partial<Wheel> = {
    name: '',
    items: [],
  };
  const errors = validateWheel(invalidWheel);
  assert.ok(errors.some((e) => e.field === 'name'));
  assert.ok(errors.some((e) => e.field === 'items'));

  const validWheel: Partial<Wheel> = {
    name: 'Roda Bagus',
    items: mockItems,
  };
  assert.equal(validateWheel(validWheel).length, 0);
});

test('calculateCompletionXP grants valid XP without exceeding safety caps', () => {
  // 10 reps of workout: 15 base + 30 = 45 XP
  const xpReps = calculateCompletionXP({ isWorkout: true, actualValue: 10, unit: 'reps' });
  assert.equal(xpReps, 45);

  // Rest: 10 XP
  const xpRest = calculateCompletionXP({ isWorkout: false });
  assert.equal(xpRest, 10);
});

test('calculateLevelFromXP advances levels smoothly', () => {
  const l1 = calculateLevelFromXP(0);
  assert.equal(l1.level, 1);
  assert.equal(l1.progressPercent, 0);

  const l2 = calculateLevelFromXP(105);
  assert.equal(l2.level, 2);
  assert.ok(l2.progressPercent > 0);
});

test('evaluateAchievements unlocks First Move when workout completion occurs and prevents double unlock', () => {
  const mockCompletions = [
    {
      id: 'c1',
      challengeId: 'ch1',
      sessionId: 's1',
      activityNameSnapshot: 'Push-up × 10',
      category: 'upper_body',
      targetValue: 10,
      actualValue: 10,
      unit: 'reps',
      completedAt: Date.now(),
      isWorkout: true,
      source: 'spin' as const,
    },
  ];

  const res1 = evaluateAchievements(INITIAL_ACHIEVEMENTS, mockCompletions, false, true);
  const firstMoveAch = res1.updatedAchievements.find((a) => a.code === 'first_move');
  assert.ok(firstMoveAch?.unlockedAt);
  assert.ok(res1.newlyUnlocked.some((a) => a.code === 'first_move'));

  // Evaluating again with the already unlocked achievement must not award XP twice
  const res2 = evaluateAchievements(res1.updatedAchievements, mockCompletions, false, true);
  assert.equal(res2.newlyUnlocked.length, 0);
  assert.equal(res2.totalXpGained, 0);
});

test('calculateTargetRotation and resolveItemIndexAtRotation work across 2, 3, 7, 20, 50 segments and weighted modes', () => {
  const segmentCounts = [2, 3, 7, 20, 50];
  const initialRotations = [0, 45, 120, 270, 720, 1085.5];

  for (const count of segmentCounts) {
    const testItems: WheelItem[] = Array.from({ length: count }, (_, idx) => ({
      id: `it-${count}-${idx}`,
      label: `Item ${idx + 1}`,
      type: 'activity',
      category: 'general',
      color: '#C6F36A',
      weight: 1 + (idx % 3), // varying weights
      trackingMode: 'completion',
      isWorkout: true,
    }));

    for (const mode of ['equal', 'weighted'] as const) {
      for (const curRot of initialRotations) {
        // Test resolving every single item in this wheel configuration
        for (let targetIdx = 0; targetIdx < count; targetIdx++) {
          const { targetRotation } = calculateTargetRotation(curRot, targetIdx, testItems, mode, 3, 5);
          const resolvedIdx = resolveItemIndexAtRotation(targetRotation, testItems, mode);
          assert.equal(
            resolvedIdx,
            targetIdx,
            `Failed for count=${count}, mode=${mode}, curRot=${curRot}, targetIdx=${targetIdx}. Resolved to ${resolvedIdx}`
          );
        }
      }
    }
  }
});

test('parseMultilineItems correctly identifies non-workout and recovery activities', () => {
  const input = `
    Baca 5 halaman
    Minum 1 gelas
    Meditasi 10 menit
    Istirahat 45 detik
    Jeda 1 menit
  `;
  const items = parseMultilineItems(input);
  assert.equal(items.length, 5);

  // Baca 5 halaman
  assert.equal(items[0].isWorkout, false);
  assert.equal(items[0].value, 5);
  assert.equal(items[0].unit, 'halaman');

  // Minum 1 gelas
  assert.equal(items[1].isWorkout, false);
  assert.equal(items[1].value, 1);
  assert.equal(items[1].unit, 'gelas');

  // Meditasi 10 menit
  assert.equal(items[2].isWorkout, false);
  assert.equal(items[2].value, 10);
  assert.equal(items[2].unit, 'menit');
  assert.equal(items[2].type, 'duration');

  // Istirahat 45 detik
  assert.equal(items[3].type, 'rest');
  assert.equal(items[3].isWorkout, false);
  assert.equal(items[3].value, 45);

  // Jeda 1 menit
  assert.equal(items[4].type, 'rest');
  assert.equal(items[4].isWorkout, false);
  assert.equal(items[4].value, 1);
  assert.equal(items[4].unit, 'menit');
});

