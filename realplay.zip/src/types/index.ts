export type ItemType =
  | 'number'
  | 'activity'
  | 'repetition'
  | 'duration'
  | 'distance'
  | 'rest'
  | 'custom';

export type TrackingMode = 'repetition' | 'duration' | 'distance' | 'completion' | 'none';

export type ChallengeStatus =
  | 'pending'
  | 'queued'
  | 'in_progress'
  | 'completed'
  | 'skipped'
  | 'cancelled';

export type ActivityCategory =
  | 'upper_body'
  | 'lower_body'
  | 'core'
  | 'cardio'
  | 'mobility_rest'
  | 'general';

export interface WheelItem {
  id: string;
  label: string;
  description?: string;
  type: ItemType;
  value?: number;
  unit?: string;
  category?: ActivityCategory | string;
  color?: string;
  weight?: number; // for weighted mode, defaults to 1
  trackingMode: TrackingMode;
  isWorkout: boolean;
}

export interface Wheel {
  id: string;
  name: string;
  description: string;
  source: 'builtin' | 'custom';
  items: WheelItem[];
  selectionMode: 'equal' | 'weighted';
  createdAt: number;
  updatedAt: number;
  schemaVersion: number;
}

export interface Challenge {
  id: string;
  sessionId: string;
  wheelId?: string;
  wheelItemId?: string;
  labelSnapshot: string;
  type: ItemType;
  category?: string;
  targetValue?: number;
  actualValue?: number;
  unit?: string;
  status: ChallengeStatus;
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  durationSeconds?: number;
  isWorkout: boolean;
  notes?: string;
}

export interface WorkoutSession {
  id: string;
  name: string;
  status: 'active' | 'completed' | 'cancelled';
  startedAt: number;
  endedAt?: number;
  challengeIds: string[];
}

export interface CompletionRecord {
  id: string;
  challengeId: string;
  sessionId: string;
  activityNameSnapshot: string;
  category?: string;
  targetValue?: number;
  actualValue?: number;
  unit?: string;
  startedAt?: number;
  completedAt: number;
  durationSeconds?: number;
  isWorkout: boolean;
  source: 'spin' | 'queue' | 'manual';
}

export type GoalType = 'sessions_per_week' | 'reps_total' | 'duration_total' | 'active_days_per_week';

export interface UserGoal {
  id: string;
  title: string;
  type: GoalType;
  target: number;
  current: number;
  unit: string;
  activityName?: string; // for specific activity reps
  enabled: boolean;
  period: 'weekly' | 'daily';
  createdAt: number;
}

export interface Achievement {
  id: string;
  code: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: number;
  progress: number;
  maxProgress: number;
  xpReward: number;
}

export interface UserSettings {
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  reducedMotion: boolean;
  defaultWarmupMinutes: number;
  difficultyLevel: 'beginner' | 'intermediate' | 'advanced';
  maxRepsLimit: number; // e.g. 100
  maxDurationSecondsLimit: number; // e.g. 300
  maxDistanceMetersLimit: number; // e.g. 5000
  userXp: number;
  userLevel: number;
}

export interface WheelExportFormat {
  schemaVersion: number;
  exportedAt: number;
  wheel: Omit<Wheel, 'id' | 'source'>;
}

export interface FullBackupFormat {
  schemaVersion: number;
  exportedAt: number;
  appVersion: string;
  wheels: Wheel[];
  sessions: WorkoutSession[];
  challenges: Challenge[];
  completions: CompletionRecord[];
  goals: UserGoal[];
  achievements: Achievement[];
  settings: UserSettings;
}
